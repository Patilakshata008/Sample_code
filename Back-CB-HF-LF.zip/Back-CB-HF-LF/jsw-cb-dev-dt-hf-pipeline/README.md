HF Flow
---

# Azure Function App: Sensor Algorithm Mapping and Fault Detection

This Azure Function App processes sensor data to detect faults in various machinery components such as gearboxes, impellers, and bearings. It uses ServiceBus triggers and outputs to Event Hubs. The application integrates with multiple services such as Azure Blob Storage, CosmosDB, and custom algorithms for feature extraction and fault detection.

## Overview

The application consists of several Azure Functions, each designed to handle a specific type of sensor data and execute corresponding fault detection algorithms. The functions are triggered by ServiceBus messages and interact with Azure Blob Storage to fetch raw sensor data, process it, and send the results (features and faults) to specified Event Hubs.

## 1. **Sensor to Algorithm Mapping (`HFSensorAlgMap`)**

**Trigger:**  
- ServiceBus Topic: `%RAW_DATA_TOPIC_NAME%`  
- Subscription: `%RAW_NOTIFY_SUBSCRIPTION_NAME%`  

**Description:**  
This function is triggered by a ServiceBus topic message containing raw sensor data. It processes the data using the `MsgCreation` class and sends the extracted features to an Event Hub for further analysis.

- **Parameters:**
  - `message`: A ServiceBus topic message that contains raw sensor data.
  - `msgCreate`: An instance of `MsgCreation`, which handles the feature extraction and message creation.
  
- **Output:**  
  Sends the extracted features to the Event Hub specified by the environment variable `%INSIGHT_ENGINE_TOPIC_NAME%`.

## 2. **Gearbox Fault Detection (`gearboxFaultDetector`)**

**Trigger:**  
- ServiceBus Topic: `%INSIGHT_ENGINE_TOPIC_NAME%`  
- Subscription: `%SUBSCRIPTION_NAME_GEARBOX%`

**Output:**  
- Sends gearbox features to Event Hub: `%HF_FEATURES_EVENTHUB_NAME%`  
- Sends fault information to Event Hub: `%HF_FAULTS_EVENTHUB_NAME%`

**Description:**  
This function processes the command to run the gearbox fault detection algorithm. It fetches sensor data from Azure Blob Storage, extracts features using `gearbox.get_gearbox_features()`, and sends the processed features and detected faults to respective Event Hubs.

- **Parameters:**
  - `message`: A ServiceBus message containing the command for fault detection.
  - `feature`: Output binding to send gearbox features to the Event Hub.
  - `faults`: Output binding to send fault information to the Event Hub.


## 3. **Blob Trigger**

### Description

The `blob_trigger` function is triggered whenever a new blob is created in the specified container. It extracts the base ID and timestamp from the blob filename, stores file metadata, and checks if the blob is part of a pair for further processing.

### Trigger

- **Type:** Blob Trigger
- **Path:** `impellerdataanamoly/{date}/Dataset-{epoch_time}/{blobname}`
- **Connection:** AzureWebJobsStorage

### Parameters

- `myblob`: Input blob stream representing the new blob that triggered the function.
- `faults`: Output binding to send messages to an Event Hub.

### Processing Steps

1. **Logging:** Logs the name and size of the processed blob.
2. **Extract Metadata:** Uses `helper.extract_base_id_and_timestamp` to retrieve the base ID and timestamp from the blob filename.
3. **Store Metadata:** Stores the file metadata in a designated table using `helper.AzureBlobStorage().store_file_metadata`.
4. **Check Pair Status:** Checks if the current blob is the latest in its pair using `helper.AzureBlobStorage().check_and_process_latest_pair`.
5. **Process Pairs:**
   - If the blob is part of a pair, retrieves the associated dataframes.
   - Initializes sensor components and processes each relevant column (x, y, z).
   - Collects features from both dataframes and combines them into a single list.
   - Makes predictions based on the extracted features.
6. **Send Output:** Constructs a payload message containing prediction information and sends it to the Event Hub.


---
 
# 4. **Event Hub Trigger**
### Description

The `eventhub_trigger` function is triggered by messages sent to an Azure Event Hub. It processes the message to extract ISO values, performs a prediction using the `oil_quality` model, and sends the result to an Event Hub.

### Trigger

- **Type:** Event Hub Trigger
- **Event Hub Name:** `%OIL_QUALITY%`
- **Connection:** HF_OIL_EH_CONNECTION_SETTING

### Parameters

- `events`: Incoming event data from the Event Hub.
- `faults`: Output binding to send messages to an Event Hub.

### Processing Steps

1. **Logging:** Logs the raw message received from the Event Hub.
2. **Parse Input:** Decodes the message and loads it into a JSON object.
3. **Extract ISO Values:** Extracts the required ISO values and sensor ID from the input data.
4. **NAS Prediction:** Calls the `oil_quality.predict_nas` function to perform the prediction based on the extracted ISO values.
5. **Send Output:** Constructs a payload message containing prediction information and sends it to the Event Hub.



## Helper Components

- **MsgCreation Class:**  
Handles the creation of messages that extract features from raw sensor data.
  
- **Azure Blob Storage Helper:**  
The `helper.AzureBlobStorage()` class provides methods to interact with Azure Blob Storage for reading sensor data and copying files between containers.

- **Model Scoring:**  
The `helper.score_model()` function sends sensor features to an ML model for scoring and returns the prediction.
