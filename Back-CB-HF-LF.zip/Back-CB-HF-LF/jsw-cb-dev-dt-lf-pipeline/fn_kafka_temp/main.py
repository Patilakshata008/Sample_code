import logging
import os
import typing
import json
from azure.eventhub import EventHubProducerClient, EventData
from azure.functions import KafkaEvent  # Ensure KafkaEvent is imported

def main(kevents: typing.List[KafkaEvent]):
    # Retrieve Event Hub connection details from environment variables
    event_hub_connection_str = os.getenv('EventHubConnectionString')
    event_hub_name = os.getenv('TempEventHubName')
 
    # Create an Event Hub producer client
    producer = EventHubProducerClient.from_connection_string(
        conn_str=event_hub_connection_str,
        eventhub_name=event_hub_name
    )
 
    try:
        # Iterate through each Kafka event received
        for event in kevents:
            # Extract the message body from the Kafka event
            message_body = event.get_body().decode('utf-8')  # Decode from bytes to string
            logging.info(f"Received Kafka event: {message_body}")
            
            # Parse the JSON data
            data = json.loads(message_body)
            logging.info(f"Parsed JSON data: {data}")
            
            # Extract relevant fields
            offset = data.get('Offset')
            partition = data.get('Partition')
            topic = data.get('Topic')
            timestamp = data.get('Timestamp')
            value_data = data.get('Value')
            
            # Ensure 'Value' is a JSON-encoded string representing a list
            if isinstance(value_data, str):
                try:
                    # Try to decode the JSON string to a list of dictionaries
                    value_data = json.loads(value_data)
                    logging.info("Converted 'Value' from JSON string to list of dictionaries.")
                except json.JSONDecodeError:
                    logging.error("Failed to decode 'Value' as JSON. Treating as a single-item list.")
                    value_data = [value_data]  # Treat the string as a single-item list if JSON decoding fails
            elif not isinstance(value_data, list):
                logging.error(f"Expected 'Value' to be a list or a JSON string representing a list but got: {type(value_data)}")
                continue
            
            # Process each item in the 'Value' field and add metadata
            transformed_data = []
            for item in value_data:
                if isinstance(item, dict):
                    item.update({
                        'Offset': offset,
                        'Partition': partition,
                        'Topic': topic,
                        'Timestamp': timestamp
                    })
                    transformed_data.append(item)
                else:
                    logging.error(f"Expected item in 'Value' to be a dictionary but got: {type(item)}")
            
            # Create a batch and add the event data
            if transformed_data:
                event_data_batch = producer.create_batch()
                for item in transformed_data:
                    event_data_batch.add(EventData(json.dumps(item)))
                
                # Send the batch to Event Hub
                producer.send_batch(event_data_batch)
                logging.info("Event sent to Event Hub successfully.")
            else:
                logging.warning("No valid data to send to Event Hub.")
 
    except Exception as e:
        logging.error(f"Failed to send event to Event Hub: {e}")
 
    finally:
        # Close the producer client
        producer.close()
