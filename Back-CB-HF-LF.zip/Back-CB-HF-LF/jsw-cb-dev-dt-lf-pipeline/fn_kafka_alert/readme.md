# Azure Function: Kafka Trigger to Event Hub Integration

This Azure Function listens to messages from a Kafka topic, processes the incoming messages, and forwards the transformed data to an Azure Event Hub.

## Table of Contents

- [Project Structure](#project-structure)
- [Functionality](#functionality)
- [Setup](#setup)
  - [Environment Variables](#environment-variables)
  - [Kafka Configuration](#kafka-configuration)
  - [Azure Event Hub Configuration](#azure-event-hub-configuration)
- [Usage](#usage)
- [Logging](#logging)
- [Additional Notes](#additional-notes)

## Project Structure
├── main.py # Main function code  
├── function.json # Azure Function configuration with Kafka trigger 


## Functionality
- The function is triggered by Kafka events from the specified Kafka topic `dtwin-deviation-conveyor`.
- It processes incoming messages, parses the data from the Kafka event, and transforms the data to add metadata such as `Offset`, `Partition`, `Topic`, and `Timestamp`.
- The transformed data is sent to an Azure Event Hub in a batch.

## Setup
### Environment Variables

Ensure the following environment variables are set either in the Azure Function App settings or in your local environment:

- `EventHubConnectionString`: Connection string for the Azure Event Hub namespace where the messages will be sent.
- `AlertsEventHubName`: Name of the Azure Event Hub to send messages.
- `password`: Password for Kafka connection (provided in the `function.json`).
- `BrokerList`: List of brokers for Kafka.

### Kafka Configuration
The Kafka trigger is configured to listen to the Kafka topic `dtwin-temperature-conveyor` with the following settings:
- **Protocol**: SASLSSL
- **Authentication Mode**: PLAIN
- **Cardinality**: MANY (processes multiple messages in a batch)
- **Consumer Group**: `python-producer`
- **Broker List**: Configured via the `BrokerList` environment variable.
- **Username**: `3FRTKBECHYUAWNT3`

### Azure Event Hub Configuration
- The Event Hub connection is configured using `EventHubConnectionString` and `AlertsEventHubName`.
- A new Event Hub producer client is created in the function to send transformed messages to the Event Hub in a batch.


## Usage
Once deployed, the function automatically triggers whenever new Kafka events are posted to the topic `dtwin-deviation-conveyor`. 
The function processes the events, adds necessary metadata, and forwards them to the configured Event Hub.

## Logging
Logs will be captured during function execution, providing information about the processed Kafka events and Event Hub messages.

Key log entries include:
The received Kafka event message body.
Successfully parsed JSON data.
Successful transformations of the Value field.
Success or failure messages for data sent to the Event Hub.

## Additional Notes
The function uses the json module to parse and transform the Kafka events.
The Value field of the Kafka message is expected to be either a list or a JSON string representing a list of dictionaries.
Each Kafka message is enriched with the following metadata: Offset, Partition, Topic, and Timestamp, and then sent to the Event Hub.

### Example Kafka Event
The function expects the Kafka event's `Value` field to be either a list or a JSON-encoded string that represents a list of dictionaries. Example Kafka message:

```json
{
  "Offset": 12345,
  "Partition": 0,
  "Topic": "dtwin-deviation-conveyor",
  "Timestamp": "2024-10-25T10:30:00Z",
  "Value": "[{\"field1\": \"value1\", \"field2\": \"value2\"}]"
}