# Azure Function: Event Hub to Event Hub Data Transformation
This Azure Function is triggered by events from an Event Hub and processes the incoming JSON data to extract specific fields. The transformed data is then sent to a different Event Hub for further processing.

## Table of Contents
- [Project Structure](#project-structure)
- [Functionality](#functionality)
- [Setup](#setup)
  - [Environment Variables](#environment-variables)
  - [Event Hub Configuration](#event-hub-configuration)
- [Usage](#usage)
- [Logging](#logging)

## Project Structure
├── main.py # Main function code  
├── function.json # Azure Function configuration with Event Hub bindings 

## Functionality
- The function is triggered by an Event Hub (`jsw-dev-dt-cb-ultrasonic-payload-trigger`).
- It processes incoming messages to extract the following fields:
  - `deviceId`
  - `timestamp`
  - `u1`, `u2`, and `u3` (these are lists)
- The function creates a structured payload and sends it as JSON to an output Event Hub (`jsw-dev-dt-cb-ultrasonic-data-ingestion`).

- The payload JSON is formatted as:
  ```json
  {
      "deviceId": "deviceID_value",
      "timestamp": "timestamp_value",
      "u1": ["list", "of", "u1", "values"],
      "u2": ["list", "of", "u2", "values"],
      "u3": ["list", "of", "u3", "values"]
  }


## Setup
Environment Variables
Ensure the following environment variables are set either in the Azure Function App settings or in your local environment:
connection_ultrasonic_eventhub: Connection string for both input and output Event Hubs.

## Event Hub Configuration
The Azure Function uses two Event Hub bindings:

Input Event Hub: jsw-dev-dt-cb-ultrasonic-payload-trigger
Binding Type: eventHubTrigger
Connection: connection_ultrasonic_eventhub
Consumer Group: $Default
Cardinality: many (processes multiple events in a batch)

Output Event Hub: jsw-dev-dt-cb-ultrasonic-data-ingestion
Binding Type: eventHub
Connection: connection_ultrasonic_eventhub

## Usage
Once deployed, the function automatically triggers whenever new events are posted to the input Event Hub. The function processes the events, extracts the specified fields, and forwards the transformed payload to the output Event Hub.

## Logging
Logs are captured during function execution to provide insights into the event data and processing status.
Key log entries include:
Raw data received from the input Event Hub.
Processed payload before sending to the output Event Hub.