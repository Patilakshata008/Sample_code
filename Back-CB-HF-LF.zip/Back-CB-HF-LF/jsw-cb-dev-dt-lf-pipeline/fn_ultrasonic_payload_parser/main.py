import json
import logging
from azure.functions import EventHubEvent, Out
from typing import List

def main(events: List[EventHubEvent], outputEventHub: Out[str]):
    for event in events:
        # Decode and load the JSON data from the event body
        event_data = event.get_body().decode('utf-8')
        data = json.loads(event_data)
        logging.info('Raw data from event hub: %s', data)
        
        # Extract U1, U2, U3, and timestamp directly from the data
        device_id = data.get("deviceId", "N/A")
        timestamp = data.get("timestamp", "")
        u1 = data.get("u1", [])
        u2 = data.get("u2", [])
        u3 = data.get("u3", [])
        
        # Create a single dictionary with U1, U2, U3 as lists and the timestamp
        payload = {
            "deviceId": device_id,
            "timestamp": timestamp,
            "u1": u1,
            "u2": u2,
            "u3": u3
        }
        
        # Convert the dictionary to a JSON string
        payload_json = json.dumps(payload, indent=4)
        
        # Log the payload
        logging.info('Processed payload: %s', payload_json)
        
        # Send the payload to the output Event Hub
        outputEventHub.set(payload_json)
