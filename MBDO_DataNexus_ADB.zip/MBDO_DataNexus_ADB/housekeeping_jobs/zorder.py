# Databricks notebook source
from pyspark.sql import SparkSession
from common_func.f_database_connect import DBconnection
from maintaince_configs import maintain_configs

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.retentionDurationCheck.enabled=false

# COMMAND ----------

# dbutils.widgets.text("catalog_name","mbdo_silver_dev")

# COMMAND ----------

catalog_name = "mbdo_silver_dev"

# COMMAND ----------

# Get the db connection details and build spark session
server = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-ServerName")  # noqa: F821
database = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-DBName")  # noqa: F821
spark = SparkSession.builder.appName('integrity-tests').getOrCreate()
dbasecon = DBconnection(database=database, server=server, spark1=spark)
con = dbasecon.fn_get_connection()
config_all = maintain_configs(con)
config = config_all.getall_configs()
zorder_configs = config['zorder_configs']
print(zorder_configs)

# COMMAND ----------

# catalog_name = dbutils.widgets.get("catalog_name") # Replace with your actual catalog name
# Concatenate catalog name with each element in zorder_configs
concatenated_configs = [f"{catalog_name}.{config}" for config in zorder_configs]
print(concatenated_configs)

# COMMAND ----------

# Perform zorder optimization operation on the tables
# for i in zorder_configs:
#     database = i['Sourcesystem_name']
#     filename = i['Filename_Template']
#     columns = i['zorder_columns']
#     print(columns)
#     query = f"optimize {catalog_name}.{database}.`{filename}` zorder by `{columns}`"
#     print(query)
#     spark.sql(query)


for i in zorder_configs:
    database = i['Sourcesystem_name']
    filename = i['FNT_Delta_Lake_table_Name']
    columns = i['zorder_columns']

    # Ensure columns is a list (if it's a string, convert it to a single-element list)
    if isinstance(columns, str):
        columns = [columns]

    # Format columns properly with backticks
    formatted_columns = ", ".join([f"{col}" for col in columns])
    print("Catalog_name:", catalog_name)
    query = f"OPTIMIZE {catalog_name}.{database}.{filename} ZORDER BY {formatted_columns}"
    
    print(query)  # Debugging to check the final query
    spark.sql(query)



# COMMAND ----------

# def z_col(self):
        
#     # statement = f""" """
#     statement = """ """
#     exec_statement = self.con.prepareCall(statement)
#     exec_statement.execute()
#     resultSet = exec_statement.getResultSet()
#     result_dict = []
#     while (resultSet.next()):
#         vals = {}
#         vals['File_Attribute_Name'] = resultSet.getString('File_attribute_Name')
#         vals['Validation_Needed'] = resultSet.getBoolean('Validtion_Needed')
#         vals['Validation_Type'] = resultSet.getString('Validation_Type')
#         vals['Value_DataType'] = resultSet.getString('value_datatype')
#         vals['Columnnames'] = resultSet.getString('Columnnames')
#         vals['FK_File_Schema_Attribute_Id'] = resultSet.getString('FK_File_Schema_Attribute_Id')
#         result_dict.append(vals)
#     exec_statement.close()
#     # self.con.close()
#     return result_dict

# COMMAND ----------


# import os
# # import glob


# def get_all_file_paths(root_folder):
#     list = []
#     y = []
#     print('l', list)
#     for dirpath, dirnames, filenames in os.walk(root_folder):
#         # print(dirpath.count(os.sep)-root_folder.count(os.sep))
#         # print(dirpath)
#         if dirpath.count(os.sep)-root_folder.count(os.sep) == 4:
#             y.append(dirpath[5:])
#     return y

# COMMAND ----------


# delta_table = get_all_file_paths('/dbfs/mnt/silver')
# delta_table_paths = list(set(delta_table))
# print(delta_table_paths)