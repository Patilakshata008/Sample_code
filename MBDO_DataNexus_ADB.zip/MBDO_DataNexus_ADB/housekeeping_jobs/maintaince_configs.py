class maintain_configs:
    """This is the class to maintain and optimize the configs."""

    def __init__(self, con):
        """
        Initializes the maintain_configs instance with a database connection.

        Args:
            con: A database connection object.
        """
        self.con = con 
        
    def vaccum_configs(self):
        """
        Executes a stored procedure to fetch vacuum configurations.

        The method retrieves data related to source systems and filename templates 
        by executing the stored procedure `sp_testing`.

        Returns:
            list[dict]: A list of dictionaries, each containing:
                - 'Sourcesystem_name' (str): The name of the source system.
                - 'Filename_Template' (str): The template for filenames.
        """
        statement = """EXEC sp_get_vacuum_config"""
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        result_dict = []
        while (resultSet.next()):
            vals = {}
            vals['Sourcesystem_name'] = resultSet.getString('DatalakeDbName')
            vals['Filename_Template'] = resultSet.getString('Filename_Template')
            vals['FNT_Delta_Lake_table_Name'] = resultSet.getString('FNT_Delta_Lake_table_Name')
        
            result_dict.append(vals)
            # Close connections
        exec_statement.close()
        return result_dict
    
    def zorder_configs(self):
        """
        Executes a stored procedure to fetch Z-order configurations.

        The method retrieves data related to source systems, filename templates,
        and Z-order columns by executing the stored procedure `sp_testing1`.

        Returns:
            list[dict]: A list of dictionaries, each containing:
                - 'Sourcesystem_name' (str): The name of the source system.
                - 'Filename_Template' (str): The template for filenames.
                - 'zorder_columns' (str): The columns used for Z-ordering.
        """
        statement = """EXEC sp_get_zorder_config"""
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        result_dict = []
        while (resultSet.next()):
            vals = {}
            vals['Sourcesystem_name'] = resultSet.getString('DatalakeDbName')
            vals['Filename_Template'] = resultSet.getString('Filename_Template')
            vals['zorder_columns'] = resultSet.getString('zorder_columns')
            vals['FNT_Delta_Lake_table_Name'] = resultSet.getString('FNT_Delta_Lake_table_Name')
        
            result_dict.append(vals)
            # Close connections
        exec_statement.close()
        return result_dict
    
    def getall_configs(self):
        """
        Fetches both vacuum and Z-order configurations.

        Combines the results of `vacuum_configs` and `zorder_configs` into a single dictionary.

        Returns:
            dict: A dictionary containing:
                - 'vacuum_configs' (list[dict]): The list of vacuum configurations.
                - 'zorder_configs' (list[dict]): The list of Z-order configurations.
        """
        config_dict = {}
        columnnames = []
        v_configs = self.vaccum_configs()
        z_configs = self.zorder_configs()
        config_dict['vacuum_configs'] = v_configs
        config_dict['zorder_configs'] = z_configs
        print("columnnames", columnnames)
        return config_dict