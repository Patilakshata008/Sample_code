# Databricks notebook source
from pyspark.sql import SparkSession
from common_func.f_database_connect import DBconnection
from maintaince_configs import maintain_configs

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.retentionDurationCheck.enabled=false

# COMMAND ----------

catalog_name = "mbdo_silver_dev"

# COMMAND ----------

catalog_name

# COMMAND ----------

# Get the db connection details and build spark session
server = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-ServerName")  # noqa: F821
database = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-DBName")  # noqa: F821
spark = SparkSession.builder.appName('integrity-tests').getOrCreate()
dbasecon = DBconnection(database=database, server=server, spark1=spark)
con = dbasecon.fn_get_connection()
config_all = maintain_configs(con)
config = config_all.getall_configs()
vacuum_configs = config['vacuum_configs']
print(vacuum_configs)

# COMMAND ----------

#catalog_name = dbutils.widgets.get("catalog_name")

# Concatenate catalog name with each element in vacuum_configs
concatenated_configs = [f"{catalog_name}.{config}" for config in vacuum_configs]

print(concatenated_configs)

# COMMAND ----------

# Perform vacuum operation on the tables
for i in vacuum_configs:
    database = i['Sourcesystem_name']
    filename = i['Filename_Template']
    tablename = i['FNT_Delta_Lake_table_Name']
    query = f"vacuum {catalog_name}.{database}.`{tablename}` retain 0 hours dry run"
    print(query)
    spark.sql(query)