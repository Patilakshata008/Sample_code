# Housekeeping Jobs

This repository contains the code for housekeeping jobs to maintain and optimize Delta tables. The main objective is to ensure that pipeline runs are tracked, and necessary maintenance operations such as vacuuming and optimizing Delta tables are performed regularly. Additionally, the system monitors alerts on failures and logs metadata information.

## Overview

The housekeeping jobs are divided into two primary operations:

1. **Vacuum**: Cleans the space by removing files that are no longer needed in the Delta tables.
2. **Optimize**: Optimizes the performance of the Delta tables by compacting small files and improving query performance.

These jobs are triggered to maintain the integrity and efficiency of the data pipeline.

## Components

### 1. **maintaince_configs.py**

This module defines a class `maintain_configs` that interacts with the database to execute stored procedures and retrieve configuration data for vacuuming and optimizing Delta tables.

#### Class: `maintain_configs`

- **Constructor**: Initializes the class with a database connection object.

#### Methods:

- **`vaccum_configs`**: 
  - Executes the stored procedure `sp_testing` to retrieve vacuum configuration data.
  - Extracts the `Sourcesystem_name` and `Filename_Template` from the result set.
  - Returns the list of dictionaries containing the extracted data.

- **`zorder_configs`**: 
  - Executes the stored procedure `sp_testing1` to retrieve z-order configuration data.
  - Extracts `Sourcesystem_name`, `Filename_Template`, and `zorder_columns`.
  - Returns the list of dictionaries containing the extracted data.

- **`getall_configs`**: 
  - Aggregates the results from `vaccum_configs` and `zorder_configs` into a single dictionary.
  - Stores the results under keys `vacuum_configs` and `zorder_configs`.
  - Returns the aggregated configuration dictionary.

### 2. **vacuum.py**

This module handles the vacuuming process for Delta tables by connecting to the database, retrieving configurations, and executing the vacuum SQL queries.

#### Flow:

1. **Disable Delta Retention Duration Check**: 
   - Executes a SQL command to disable the Delta retention duration check.
   
2. **Retrieve Secrets and Initialize Spark Session**: 
   - Retrieves SQL server and database secrets from the Databricks secret scope.
   - Initializes a Spark session for data processing.

3. **Establish Database Connection**: 
   - Creates an instance of `DBconnection` with the database credentials and establishes a connection.

4. **Retrieve Configuration Data**: 
   - Uses the `maintain_configs` class to retrieve vacuum configurations.

5. **Execute Vacuum Commands**: 
   - Iterates over the `vacuum_configs`.
   - Constructs and executes vacuum SQL queries for each configuration.

### 3. **zorder.py**

This module handles the optimization of Delta tables by applying z-ordering to improve query performance.

#### Flow:

1. **Retrieve Secrets and Initialize Spark Session**: 
   - Retrieves SQL server and database secrets from the Databricks secret scope.
   - Initializes a Spark session for data processing.

2. **Establish Database Connection**: 
   - Creates an instance of `DBconnection` with the database credentials and establishes a connection.

3. **Retrieve Configuration Data**: 
   - Uses the `maintain_configs` class to retrieve z-order configurations.

4. **Execute Z-Order Commands**: 
   - Iterates over the `zorder_configs`.
   - Constructs and prints optimize SQL queries for each configuration.

5. **Define Helper Functions**: 
   - **`z_col`**: Executes a SQL statement and retrieves results, constructing a result dictionary.
   - **`get_all_file_paths`**: Retrieves all file paths from a root folder.
   
6. **Retrieve Delta Table Paths**: 
   - Calls `get_all_file_paths` to retrieve Delta table paths from the root folder `/dbfs/mnt/silver`.
   - Constructs a list of unique Delta table paths.


