# Databricks notebook source
user=spark.sql("select * from cimbmain_bronze.uat2_mobile.t_user")

# COMMAND ----------

detail=spark.sql("select * from cimbmain_bronze.uat2_mobile.t_user_detail")

# COMMAND ----------

display(user)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE cimbmain_silver.modeldb_test.user_master as
# MAGIC select usr.id,det.user_id,usr.nick_name,det.real_name,det.email,concat_ws(",",usr.nick_name, det.email) as name_email from cimbmain_silver.modeldb_test.silver_user usr inner join cimbmain_silver.modeldb_test.silver_user_detail det
# MAGIC on usr.id=det.user_id
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS
# MAGIC   cimbmain_silver.modeldb_test.menu (
# MAGIC     recipe_id INT,
# MAGIC     app string,
# MAGIC     main string,
# MAGIC     dessert string
# MAGIC   );
# MAGIC
# MAGIC INSERT INTO cimbmain_silver.modeldb_test.menu
# MAGIC     (recipe_id, app, main, dessert)
# MAGIC VALUES
# MAGIC     (1,"Ceviche", "Tacos", "Flan"),
# MAGIC     (2,"Tomato Soup", "Souffle", "Creme Brulee"),
# MAGIC     (3,"Chips","Grilled Cheese","Cheesecake");
# MAGIC
# MAGIC CREATE TABLE
# MAGIC   cimbmain_silver.modeldb_test.dinner
# MAGIC AS SELECT
# MAGIC   recipe_id, concat(app," + ", main," + ",dessert)
# MAGIC AS
# MAGIC   full_menu
# MAGIC FROM
# MAGIC   cimbmain_silver.modeldb_test.menu;

# COMMAND ----------

from pyspark.sql.functions import rand, round
df = spark.range(3).withColumn("price", round(10*rand(seed=42),2)).withColumnRenamed("id","recipe_id")

df.write.mode("overwrite").saveAsTable("cimbmain_silver.modeldb_test.price")

dinner = spark.read.table("cimbmain_silver.modeldb_test.dinner")
price = spark.read.table("cimbmain_silver.modeldb_test.price")

dinner_price = dinner.join(price, on="recipe_id")
dinner_price.write.mode("overwrite").saveAsTable("cimbmain_silver.modeldb_test.dinner_price")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cimbmain_silver.modeldb_test.dinner_price

# COMMAND ----------

