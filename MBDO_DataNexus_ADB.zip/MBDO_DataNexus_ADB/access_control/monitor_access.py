# Databricks notebook source
catalogs=spark.sql("select * from system.information_schema.catalogs")

# COMMAND ----------

display(catalogs)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from system.information_schema.schemata

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC alter view access_control_catalog.access_control_schema.consolidated_objects
# MAGIC as
# MAGIC select * from (
# MAGIC select cat.catalog_name as object_name,cat.catalog_owner,cat.created,tag.tag_name,tag.tag_value,'catalog' as object_type from system.information_schema.catalogs cat left outer join system.information_schema.catalog_tags tag
# MAGIC on cat.catalog_name=tag.catalog_name
# MAGIC union all
# MAGIC select sch.schema_name,sch.schema_owner,sch.created,tag.tag_name,tag.tag_value,'schema' as object_type from system.information_schema.schemata sch left outer join system.information_schema.schema_tags tag
# MAGIC on sch.schema_name=tag.schema_name
# MAGIC union all
# MAGIC select tab.table_name,tab.table_owner,tab.created,tag.tag_name,tag.tag_value,'table' as object_type from system.information_schema.tables tab left outer join system.information_schema.table_tags tag
# MAGIC on tab.table_name=tag.table_name)m
# MAGIC where (m.object_name !='information_schema' and m.object_type!='catalog')

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC create table access_control_catalog.access_control_schema.consolidated_previliges
# MAGIC as
# MAGIC select * from (
# MAGIC select grantee,catalog_name as object_name,privilege_type,inherited_from,'catalog' object_type from system.information_schema.catalog_privileges
# MAGIC union all
# MAGIC select grantee,schema_name as object_name,privilege_type,inherited_from,'schema' object_type from system.information_schema.schema_privileges
# MAGIC union all
# MAGIC select grantee,table_name as object_name,privilege_type,inherited_from,'table' object_type from system.information_schema.table_privileges)m
# MAGIC where m.  

# COMMAND ----------

# MAGIC %sql
# MAGIC create view access_control_catalog.access_control_schema.table_access
# MAGIC as
# MAGIC select * from system.information_schema.tables tab left outer join access_control_catalog.access_control_schema.consolidated_previliges pvl
# MAGIC on tab.table_name=pvl.object_name
# MAGIC where (table_schema!='information_schema' and table_schema!='access_control_schema')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from access_control_catalog.access_control_schema.table_access

# COMMAND ----------

