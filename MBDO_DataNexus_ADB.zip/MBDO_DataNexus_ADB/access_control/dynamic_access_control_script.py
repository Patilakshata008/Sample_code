# Databricks notebook source
class access_checker:
    def __init__(self,Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,object_hierarchy,Request_type=None):
        """
            Initializes the object with the necessary details to manage access requests.

            Args:
                Requestor_type (str): The type of the requestor (e.g., 'user').
                Requestor_name (str): The name of the requestor.
                Target_object_name (str): The name of the target object (e.g., a table or schema).
                Target_object_type (str): The type of the target object (e.g., 'table', 'schema', 'catalog').
                Access_type (str): The type of access requested (e.g., 'read', 'write').
                object_hierarchy (dict): A dictionary containing the catalog, schema, and table details.
                Request_type (str, optional): The type of request (e.g., 'add', 'remove'). Defaults to None.

            Attributes:
                Requestor_type (str): The type of the requestor.
                Requestor_name (str): The name of the requestor.
                Target_object_name (str): The name of the target object.
                Target_object_type (str): The type of the target object.
                Access_type (str): The type of access being requested.
                catalog (str): The catalog of the target object.
                schema (str): The schema of the target object.
                table (str): The table of the target object.
                Request_type (str, optional): The type of request being made.
        """

        self.Requestor_type=Requestor_type
        self.Requestor_name=Requestor_name
        self.Target_object_name=Target_object_name
        self.Target_object_type=Target_object_type
        self.Access_type=Access_type
        self.catalog=object_hierarchy['catalog']
        self.schema=object_hierarchy['schema']
        self.table=object_hierarchy['table']


    def fn_get_group(self):
        """
            Retrieves the groups associated with the requestor if the requestor type is 'user'. If the requestor type is not 'user', it returns the requestor name directly.

            Returns:
                list or str: A list of group names if the requestor type is 'user', otherwise the requestor name.

            Raises:
                Exception: If an error occurs while querying the database for user groups.
        """        
        if self.Requestor_type=='user':
            sql=f"select * from access_control_catalog.access_control_schema.user_groups where username='{self.Requestor_name}'"
            print(sql)
            df=spark.sql(sql)            
            ls = list(df.select('groupname').toPandas()['groupname'])
            return ls
        else:
            ls=self.Requestor_name
            return ls


    def fn_check_parent_access_table(self,Requestor_name,catalogname=None,schemaname=None,tablename=None):
        """
            Checks the access privileges of a requestor on a specific table in a given catalog and schema.

            Args:
                Requestor_name (str): The name of the requestor (user or group).
                catalogname (str, optional): The catalog name where the table is located.
                schemaname (str, optional): The schema name where the table is located.
                tablename (str, optional): The name of the table to check access for.

            Returns:
                list: A list of privilege types (e.g., SELECT, INSERT) granted to the requestor on the table.
        """

        sql=f"select * from {catalogname}.information_schema.table_privileges where table_name='{tablename}' and table_schema='{schemaname}' and grantee='{Requestor_name}'"
        print(sql)
        df=spark.sql(sql)
        display(df)
        ls=list(df.select('privilege_type').toPandas()['privilege_type'])
        return ls
    
    def fn_check_parent_access_schema(self,Requestor_name,catalogname,schemaname,tablename=None):
        """
                Checks the access privileges of a requestor on a specific schema in a given catalog.

                Args:
                    Requestor_name (str): The name of the requestor (user or group).
                    catalogname (str): The catalog name where the schema is located.
                    schemaname (str): The schema name to check access for.
                    tablename (str, optional): The name of the table, if applicable (default is None).

                Returns:
                    list: A list of privilege types (e.g., USAGE, ALTER) granted to the requestor on the schema.
        """

        sql=f"select * from {catalogname}.information_schema.schema_privileges where schema_name='{schemaname}' and grantee='{Requestor_name}'"
        print(sql)
        df=spark.sql(sql)
        display(df)
        ls=list(df.select('privilege_type').toPandas()['privilege_type'])
        return ls
        
    def fn_check_parent_access_catalog(self,Requestor_name,catalogname,schemaname=None,tablename=None):
        """
            Checks the access privileges of a requestor on a specific catalog.

            Args:
                Requestor_name (str): The name of the requestor (user or group).
                catalogname (str): The catalog name to check access for.
                schemaname (str, optional): The schema name, if applicable (default is None).
                tablename (str, optional): The name of the table, if applicable (default is None).

            Returns:
                list: A list of privilege types (e.g., CREATE, USAGE) granted to the requestor on the catalog.
        """

        sql=f"select * from {catalogname}.information_schema.catalog_privileges where catalog_name='{catalogname}' and grantee='{Requestor_name}'"
        print(sql)
        df=spark.sql(sql)
        display(df)
        ls=list(df.select('privilege_type').toPandas()['privilege_type'])
        return ls
       
    
    def fn_check_existing_access(self,requestor):  
        """
            Checks the existing access privileges for a requestor on the specified target object (catalog, schema, or table).

            Args:
                requestor (str): The name of the requestor (user or group).

            Returns:
                dict: A dictionary containing access privileges for each object type ('catalog', 'schema', 'table'). 
                    The value for each key is a list of privilege types the requestor has on the respective object.
        """

        access_check_dict={'catalog':None,'schema':None,'table':None}
        print('checking for ',requestor  )
        if self.Target_object_type=='table':
            print('tab')
            access_check_dict['table']=self.fn_check_parent_access_table(requestor, self.catalog,self.schema,self.table)
            access_check_dict['schema']=self.fn_check_parent_access_schema(requestor,self.catalog,self.schema,None)
            access_check_dict['catalog']=self.fn_check_parent_access_catalog(requestor,self.catalog,None,None)
           
        if self.Target_object_type=='schema':
            print('sch')
            access_check_dict['schema']=self.fn_check_parent_access_schema(requestor,self.catalog,self.schema,None)
            access_check_dict['catalog']=self.fn_check_parent_access_catalog(requestor,self.catalog,None,None)
           
        if self.Target_object_type=='catalog':
            print('cat')
            access_check_dict['catalog']=self.fn_check_parent_access_catalog(requestor,self.catalog,None,None)
           
        return access_check_dict
    
    def fn_main(self):
        """
            Main function to check the access privileges for a list of groups (or a single group) of a requestor.

            This function retrieves the groups associated with a requestor and checks their existing access privileges on the target object (catalog, schema, or table). It returns a dictionary mapping each group to its respective access privileges on the target object.

            Returns:
                dict: A dictionary where keys are group names and values are dictionaries of access privileges for each object type (catalog, schema, or table).
        """

        ls_grp=[]
        master_access_check_dict={}
        #master_access_check_list=[]
        groups=self.fn_get_group()
        if isinstance(groups, list):   
            print('is list')             
            ls_grp=groups
        else:            
            print(' is not list')
            ls_grp.append(groups)
        print(ls_grp)
        for a in ls_grp:
            #master_access_check_list.append(self.fn_check_existing_access(a))
            master_access_check_dict[a]=self.fn_check_existing_access(a)
        print(master_access_check_dict)    
        return master_access_check_dict    

# COMMAND ----------

class access_grantor:
    def __init__(self,Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,object_hierarchy,Request_type,dict_permission_model):
        """
                Constructor to initialize the class with necessary parameters for access control.

                Parameters:
                    Requestor_type (str): The type of the requestor (e.g., 'user', 'group').
                    Requestor_name (str): The name of the requestor (e.g., username or group name).
                    Target_object_name (str): The name of the target object (catalog, schema, or table).
                    Target_object_type (str): The type of the target object (e.g., 'catalog', 'schema', 'table').
                    Access_type (str): The type of access being requested (e.g., 'read', 'write', 'modify').
                    object_hierarchy (dict): A dictionary containing the hierarchy of the object (e.g., catalog, schema, table).
                    Request_type (str): The type of request (optional).
                    dict_permission_model (dict): A dictionary mapping access types to permissions for different object types (catalog, schema, table).
        """

        self.Requestor_type=Requestor_type
        self.Requestor_name=Requestor_name
        self.Target_object_name=Target_object_name
        self.Target_object_type=Target_object_type
        self.Access_type=Access_type
        
        self.object_hierarchy=object_hierarchy
        self.dict_permission_model=dict_permission_model

    def fn_get_permission(self):
        """
                This function retrieves the necessary permissions for the requestor based on the target object type and access type.

                Parameters:
                    None

                Returns:
                    list: A list of permissions needed for the specified target object type (table, schema, or catalog).
        """

        print('inside dn')
        if self.Target_object_type=='table':
            print('inide 111')
            permission_needed=self.dict_permission_model[self.Access_type]['table']
            return permission_needed
        elif self.Target_object_type=='schema':
            print('inide 111')
            permission_needed=self.dict_permission_model[self.Access_type]['schema']
            return permission_needed
        elif self.Target_object_type=='catalog':
            print('inide 111')
            permission_needed=self.dict_permission_model[self.Access_type]['catalog']
            return permission_needed
    
        
 
    
    def fn_grant(self,Object_type,privilege,Requestor,object_hierarchy):   
        """
            This function grants a specified privilege on the target object (schema, table, or catalog) to a requestor.

            Parameters:
                Object_type (str): The type of the object (either 'schema', 'table', or 'catalog').
                privilege (str): The privilege to be granted.
                Requestor (str): The name of the requestor (user or group).
                object_hierarchy (dict): A dictionary containing the hierarchy information for the target object (catalog, schema, and table).

            Returns:
                bool: True if the privilege was successfully granted, False otherwise.
        """

        if Object_type=='schema':
            print('a')
            obj=f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}"
        elif Object_type=='table':
           print('b')
           obj= f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}.{object_hierarchy['table']}"
        else:
           print('c')
           obj=f"{object_hierarchy['catalog']}"
        print(obj)

        try:
            sql=f"GRANT {privilege} ON {Object_type} {obj} TO `{Requestor}`"
            print(sql)
            spark.sql(sql)
        except:
            return False
        else:
            return True
        

    def fn_main(self):
        """
            This function executes the permission granting process for each required object type and privilege.

            It retrieves the necessary permissions and iterates over each object type (schema, table, catalog) to grant the required privileges to the requestor. 

            Parameters:
                None

            Returns:
                None
        """

        permissions=self.fn_get_permission()
        print(permissions)
        for obj_type_perm in permissions:
            print(obj_type_perm)
            for obj_type,perm_needed in obj_type_perm.items():
                print(obj_type)
                print(perm_needed)
                for perm in perm_needed:
                    result=self.fn_grant(obj_type,perm,self.Requestor_name,self.object_hierarchy)
                print(result)
            #print(perm_needed)


            


# COMMAND ----------

class access_revoker:
    def __init__(self,Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,object_hierarchy,Request_type,dict_permission_model):
        """
            This function initializes an instance of the access control request handler.

            It sets up the requestor's details, target object information, access type, and the permission model for access control operations.

            Parameters:
                Requestor_type (str): The type of the requestor (e.g., user, group).
                Requestor_name (str): The name of the requestor (e.g., specific user or group).
                Target_object_name (str): The name of the target object (e.g., table, schema, catalog).
                Target_object_type (str): The type of the target object (e.g., 'table', 'schema', 'catalog').
                Access_type (str): The type of access being requested (e.g., 'read', 'write').
                object_hierarchy (dict): A dictionary that holds the hierarchical details of the object (catalog, schema, table).
                Request_type (str): The type of the request (e.g., 'grant', 'revoke').
                dict_permission_model (dict): A dictionary representing the permission model for the access types.

            Returns:
                None
        """

        self.Requestor_type=Requestor_type
        self.Requestor_name=Requestor_name
        self.Target_object_name=Target_object_name
        self.Target_object_type=Target_object_type
        self.Access_type=Access_type
        self.dict_permission_model=dict_permission_model
        self.object_hierarchy=object_hierarchy

    def fn_get_permission(self):
        """
            This function retrieves the permissions required for the given target object type based on the access type.

            It checks the target object type (table, schema, or catalog) and fetches the corresponding permissions from the permission model.

            Parameters:
                None

            Returns:
                permission_needed (list): A list of permissions needed for the target object type based on the access type.
        """

        print('inside dn')
        if self.Target_object_type=='table':
            print('inide 111')
            permission_needed=self.dict_permission_model[self.Access_type]['table']
            return permission_needed
        elif self.Target_object_type=='schema':
            print('inide 111')
            permission_needed=self.dict_permission_model[self.Access_type]['schema']
            return permission_needed
        elif self.Target_object_type=='catalog':
            print('inide 111')
            permission_needed=self.dict_permission_model[self.Access_type]['catalog']
            return permission_needed
    
        
 
    
    def fn_revoke(self,Object_type,privilege,Requestor,object_hierarchy):   
        """
            This function revokes a specific privilege from a given requestor for a target object type (schema, table, or catalog).

            It constructs the object reference based on the object hierarchy and executes the SQL command to revoke the specified privilege.

            Parameters:
                Object_type (str): The type of the object (schema, table, or catalog).
                privilege (str): The privilege to be revoked.
                Requestor (str): The name of the requestor from whom the privilege will be revoked.
                object_hierarchy (dict): A dictionary containing the object hierarchy with keys for catalog, schema, and table.

            Returns:
                bool: Returns True if the privilege was successfully revoked, False otherwise.
        """

        if Object_type=='schema':
            print('a')
            obj=f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}"
        elif Object_type=='table':
           print('b')
           obj= f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}.{object_hierarchy['table']}"
        else:
           print('c')
           obj=f"{object_hierarchy['catalog']}"
        print(obj)

        try:
            sql=f"REVOKE {privilege} ON {Object_type} {obj} FROM `{Requestor}`"
            print(sql)
            spark.sql(sql)
            print('revoked')
        except:
            print('failed')
            return False
        else:
            return True
        

    def fn_main(self):
        """
            This function handles the main process of checking and revoking permissions for a given requestor.

            It retrieves the necessary permissions based on the requestor's access type and target object type. Then, for each permission needed, it calls the `fn_revoke` function to revoke the specified privileges from the requestor.

            Parameters:
                None

            Returns:
                None
        """

        permissions=self.fn_get_permission()
        print(permissions)
        for obj_type_perm in permissions:
            print(obj_type_perm)
            for obj_type,perm_needed in obj_type_perm.items():
                print(obj_type)
                if obj_type==self.Target_object_type:                                
                    print("perm needed is",perm_needed)
                    for perm in perm_needed:
                        result=self.fn_revoke(obj_type,perm,self.Requestor_name,self.object_hierarchy)
                    print(result)
            #print(perm_needed)         


# COMMAND ----------

