# Databricks notebook source
# MAGIC %sql
# MAGIC create catalog mytestcatalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema mytestcatalog.mytestschema;

# COMMAND ----------

# MAGIC %sql
# MAGIC create table mytestcatalog.mytestschema.country_details(id int,country string,value string);

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC insert into mytestcatalog.mytestschema.country_details 
# MAGIC select 1,'india',123232 union all
# MAGIC select 2,'vietnam',5454 union all
# MAGIC select 3,'us',999 union all
# MAGIC select 4,'india',6454 union all
# MAGIC select 5,'germany',1818
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create table mytestcatalog.mytestschema.user_details(id int,username string,Dept string,salary int);

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC insert into mytestcatalog.mytestschema.user_details 
# MAGIC select 1,'Raja','finance',13232 union all
# MAGIC select 2,'user2','IT',5454 union all
# MAGIC select 3,'user3','sales',87878 union all
# MAGIC select 4,'user4','finance',1212 union all
# MAGIC select 5,'user5','sales',8844

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table access_control_catalog.access_control_schema.user_column_encryption

# COMMAND ----------

# MAGIC %sql
# MAGIC create table access_control_catalog.access_control_schema.user_column_encryption(group_name string,column_name string,viewname string)

# COMMAND ----------

# MAGIC %sql
# MAGIC create table access_control_catalog.access_control_schema.user_Row_filter(group_name string,column_name string,viewname string)

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into access_control_catalog.access_control_schema.user_column_encryption
# MAGIC select 'MIS_grp','Dept','vw_user_details' union all
# MAGIC select 'Tech_Dev_grp','salary','vw_user_details' union all
# MAGIC select 'Tester_grp','salary','vw_user_details'

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into access_control_catalog.access_control_schema.user_Row_filter
# MAGIC select 'vietnam_group','Dept','vw_user_details'

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from access_control_catalog.access_control_schema.user_column_encryption where group_name='Tech_Dev_grp'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from access_control_catalog.access_control_schema.user_column_encryption

# COMMAND ----------

# MAGIC %sql
# MAGIC create view mytestcatalog.mytestschema.vw_country_details
# MAGIC as
# MAGIC select  * from mytestcatalog.mytestschema.country_details  where country =(case when is_account_group_member('india_grp') then 'india' when is_account_group_member('viertnam_group') then 'vietnam' end)

# COMMAND ----------

#table_name='mytestcatalog.mytestschema.user_details'
#columns=['username','dept','salary']
def fn_create_view(vw_name,catalog,schema,columns,table_name):    
    df=spark.sql(f"select * from access_control_catalog.access_control_schema.user_column_encryption where viewname='{vw_name}'")
    display(df)
    df_p=df.toPandas()
    df_p_dct=df_p.groupby('column_name')['group_name'].apply(list).to_dict()
    all_conds=[]
    redacted_cols=set()
    for col,grps in df_p_dct.items():    
        redacted_cols.add(col)
        ls1=[]
        print(col,grps)
        for grp in grps:
            print(grp)
            sql=f" is_account_group_member('{grp}') "
            ls1.append(sql)
        print('ls1',"or".join(ls1))
        temp_ls="or".join(ls1)
        per_col_cond="case when "+temp_ls+ f" THEN 'REDACTED' ELSE {col} END as {col}"
        print(per_col_cond)
        all_conds.append(per_col_cond)
    print(all_conds)
    print(redacted_cols)
    global_cols=[a for a in columns if a not in redacted_cols]
    all_cols=global_cols+all_conds
    print(",".join(all_cols))
    select_cols=",".join(all_cols)
    final_qry=f"create or replace view {catalog}.{schema}.{vw_name} as select {select_cols} from {table_name} where is_account_group_member(Dept)"
    print(final_qry)
    spark.sql(final_qry)
    print('view created')



# COMMAND ----------

#table_name='mytestcatalog.mytestschema.user_details'
#columns=['username','dept','salary']
def fn_create_view_row_filter(vw_name,catalog,schema,columns,table_name):    
    df=spark.sql(f"select * from access_control_catalog.access_control_schema.user_Row_filter where viewname='{vw_name}'")
    display(df)
    df_p=df.toPandas()
    df_p_dct=df_p.groupby('column_name')['group_name'].apply(list).to_dict()
    all_conds=[]
    redacted_cols=set()
    for col,grps in df_p_dct.items():    
        redacted_cols.add(col)
        ls1=[]
        print(col,grps)
        for grp in grps:
            print(grp)
            sql=f" is_account_group_member('{grp}') "
            ls1.append(sql)
        print('ls1',"or".join(ls1))
        temp_ls="or".join(ls1)
        per_col_cond="case when "+temp_ls+ f" THEN 'REDACTED' ELSE {col} END as {col}"
        print(per_col_cond)
        all_conds.append(per_col_cond)
    print(all_conds)
    print(redacted_cols)
    global_cols=[a for a in columns if a not in redacted_cols]
    all_cols=global_cols+all_conds
    print(",".join(all_cols))
    select_cols=",".join(all_cols)
    final_qry=f"create or replace view {catalog}.{schema}.{vw_name} as select {select_cols} from {table_name}"
    print(final_qry)
    spark.sql(final_qry)
    print('view created')



# COMMAND ----------

row_filter_dict={"finance_group":"finance","sales_group":"sales"}

select * from from access_control_catalog.access_control_schema.user_Row_filter

# COMMAND ----------

table_name='mytestcatalog.mytestschema.user_details'
columns=['username','Dept','salary']
vw_name='vw_user_details'
df=spark.sql(f"select * from access_control_catalog.access_control_schema.user_Row_filter where viewname='{vw_name}'")
display(df)
df_p=df.toPandas()
df_p_dct=df_p.groupby('column_name')['group_name'].apply(list).to_dict()
all_conds=[]
redacted_cols=set()
for col,grps in df_p_dct.items():    
    redacted_cols.add(col)
    ls1=[]
    print(col,grps)
    for grp in grps:
        print(grp)
        sql=f" is_account_group_member('{grp}') "
        ls1.append(sql)
    print('ls1',"or".join(ls1))
    temp_ls="or".join(ls1)
    per_col_cond="case when "+temp_ls+ f" THEN 'REDACTED' ELSE {col} END as {col}"
    print(per_col_cond)
    all_conds.append(per_col_cond)
print(all_conds)
print(redacted_cols)

# COMMAND ----------

table_name='mytestcatalog.mytestschema.user_details'
columns=['username','Dept','salary']
vw_name='vw_user_details'
fn_create_view(vw_name,'mytestcatalog','mytestschema',columns,table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace view mytestcatalog.mytestschema.vw_user_details as select username,case when  is_account_group_member('MIS_grp')  THEN 'REDACTED' ELSE Dept END as Dept,case when  is_account_group_member('Tech_Dev_grp') or is_account_group_member('Tester_grp')  THEN 'REDACTED' ELSE salary END as salary from mytestcatalog.mytestschema.user_details

# COMMAND ----------

# MAGIC %sql
# MAGIC select username,case when  is_account_group_member('MIS_grp')  THEN 'REDACTED' ELSE Dept END as Dept,case when  is_account_group_member('Tech_Dev_grp') or is_account_group_member('Tester_grp')  THEN 'REDACTED' ELSE salary END as salary,is_account_group_member(Dept)
# MAGIC  from mytestcatalog.mytestschema.user_details where is_account_group_member(Dept)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from mytestcatalog.mytestschema.vw_user_details

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from mytestcatalog.mytestschema.

# COMMAND ----------

