# Access Control and Security Management

This repository contains various Databricks notebooks and scripts aimed at managing access control, security configurations, and operations related to Row-Level Security (RLS), Column-Level Security (CLS), and user/group management. The notebooks demonstrate the use of Databricks SDK, APIs, and SQL queries for implementing security measures and access controls.

## Contents

### 1. access_control

### group_creator.py
This script performs operations related to Databricks account and workspace management using the Databricks SDK and API.
- **List Account-Level Groups**: Lists all available groups within the Databricks account.
- **API Request to Get User Information**: Sends a GET request to retrieve information about the authenticated user.
- **API Request to Create a Group**: Sends a POST request to create a new group in Databricks.
- **Network Connectivity Check**: Uses `nc` (netcat) and `telnet` to check connectivity to Databricks API endpoints.
- **Install Databricks SDK**: Installs or upgrades the Databricks SDK for Python.
- **List Clusters in Workspace**: Lists all clusters in the workspace using the Databricks CLI SDK.

### tag_check.py
Manages tags for tables in Unity Catalog.
- **Class `managetags`**: Initializes with catalog name, schema name, table name, and tags dictionary.
  - **add_tags Method**: Adds tags to a specified table.
  - **check_tags Method**: Checks for tables without tags.
  - **remove_tags Method**: Removes tags from a specified table (incomplete method).
- **Define Catalogs**: Defines catalogs to check for tables without tags.
- **Add Tags**: Adds tags to tables through the `managetags` class.

### monitor_access.py
Retrieves and displays a list of catalogs from the `system.information_schema.catalogs` table.
- **Retrieve Catalogs**: Executes SQL queries to fetch all catalogs and displays them.

### table_access_control_executor.py
Manages access control requests for tables, schemas, and catalogs.
- **Define Permission Model**: Maps access levels to corresponding permissions.
- **Class `AccessExecutor`**: Manages access requests.
  - **fn_fetch_pending_requests**: Fetches approved access requests.
  - **fn_check_if_access_already_satisfied**: Checks if access is already granted.
  - **fn_update_status**: Updates the request status.
  - **fn_execute**: Processes requests and grants or revokes access.

### rls_cls_access_control_sql_executor.py
Sets up and manages Row-Level Security (RLS) and Column-Level Security (CLS) for tables.
- **Create Widget**: Creates a widget to input the type of security (RLS or CLS).
- **Class `dynamic_rls_cls`**:
  - **fn_create_rls_rules**: Creates RLS rules by applying row filters.
  - **fn_create_cls_rules**: Creates CLS rules by applying masks.
  - **fn_execute_rls_main**: Applies RLS rules.
  - **fn_execute_cls_main**: Applies CLS rules.

### admin_config_and_demo.sql
Demonstrates how to manage table access control, RLS, and CLS configurations in Databricks.
- **Check Current Access**: Queries current access for tables.
- **Grant Access**: Grants read, edit, and create access.
- **Execute Access Control Script**: Executes the script to apply changes.
- **Set Up RLS/CLS**: Inserts and configures RLS and CLS rules.
- **Check User Access Requests**: Verifies access request statuses.

### dynamic_views.py
Demonstrates creating views with RLS and CLS.
- **fn_create_view**: Creates views with column-level security.
- **fn_create_view_row_filter**: Creates views with row-level security.
- **Query User Row Filter**: Checks the row-level security configuration.

### dynamic_access_control_script.py
Manages access control for tables, schemas, and catalogs.
- **Access Checker**: Checks access privileges for requestors.
- **Access Grantor**: Grants necessary permissions to requestors.
- **Access Revoker**: Revokes specified privileges from requestors.

### lineage.py
Handles data reading, joining, and creating DataFrames for lineage tracking.
- **Read Data from `t_user` Table**: Reads data into a DataFrame.
- **Create and Write Price DataFrame**: Creates a new DataFrame and writes it to a table.
- **Read Dinner and Price Tables**: Joins data from various tables and processes it for lineage tracking.

### Requirements
- Databricks workspace and catalog configurations
- Permissions for managing groups, tables, and security in Databricks

### Usage

- Run `group_creator.py` to manage groups and API connections.
- Use `tag_check.py` to manage tags for Unity Catalog tables.
- Run `monitor_access.py` to monitor catalogs in Databricks.
- Execute `table_access_control_executor.py` to process access requests.
- Use `rls_cls_access_control_sql_executor.py` for RLS and CLS security management.
- Apply access control with `dynamic_access_control_script.py` and monitor with `dynamic_access_control_script_backup.py`.
- Query and configure tables with SQL using `exploration.sql`.


