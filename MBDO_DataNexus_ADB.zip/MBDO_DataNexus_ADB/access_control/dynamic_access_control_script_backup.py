# Databricks notebook source
df=spark.sql("select * from access_control_catalog.access_control_schema.user_access_requests where status='in-progress'")

# COMMAND ----------

display(df)

# COMMAND ----------

class access_checker:
    def __init__(self,Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,catalog=None,schema=None,table=None):
        """
            Initializes an instance of the access request class.

            This constructor initializes the details for a user access request, including the requestor's information, target object details, access type, and optional catalog, schema, and table information.

            Parameters:
                Requestor_type (str): The type of the requestor (e.g., user, admin).
                Requestor_name (str): The name of the requestor.
                Target_object_name (str): The name of the target object being requested for access.
                Target_object_type (str): The type of the target object (e.g., table, schema, catalog).
                Access_type (str): The type of access being requested (e.g., read, write).
                catalog (str, optional): The catalog where the target object resides (default is None).
                schema (str, optional): The schema where the target object resides (default is None).
                table (str, optional): The table where the target object resides (default is None).
        """

        self.Requestor_type=Requestor_type
        self.Requestor_name=Requestor_name
        self.Target_object_name=Target_object_name
        self.Target_object_type=Target_object_type
        self.Access_type=Access_type
        self.catalog=catalog
        self.schema=schema
        self.table=table


    def fn_get_group(self):
        """
            Fetches the group(s) associated with the requestor.

            This function retrieves the group(s) associated with a user based on their requestor type. If the requestor is a user, the function queries the `user_groups` table to find the groups associated with the username. If the requestor is not a user (i.e., an admin or another type), the function returns the requestor's name as the group.

            Parameters:
                None

            Returns:
                list or str: A list of group names if the requestor is a user, or a string (requestor's name) if the requestor is not a user.
        """

        if self.Requestor_type=='user':
            sql=f"select * from access_control_catalog.access_control_schema.user_groups where username='{self.Requestor_name}'"
            print(sql)
            df=spark.sql(sql)            
            ls = list(df.select('groupname').toPandas()['groupname'])
            return ls
        else:
            ls=self.Requestor_name
            return ls


    def fn_check_parent_access_table(self,Requestor_name,catalogname=None,schemaname=None,tablename=None):
        """
            Checks the access privileges of a requestor on a specified table.

            This function queries the `table_privileges` table to check the privileges granted to a requestor on a specified table within a specific catalog and schema. It returns a list of the privilege types associated with the table, such as SELECT, INSERT, UPDATE, etc.

            Parameters:
                Requestor_name (str): The name of the requestor whose access privileges are being checked.
                catalogname (str, optional): The name of the catalog where the table is located. Defaults to None.
                schemaname (str, optional): The name of the schema where the table is located. Defaults to None.
                tablename (str, optional): The name of the table for which the access is being checked. Defaults to None.

            Returns:
                list: A list of privilege types granted to the requestor on the specified table.
        """

        sql=f"select * from {catalogname}.information_schema.table_privileges where table_name='{tablename}' and schema_name= '{schemaname}'  and grantee='{Requestor_name}'"
        print(sql)
        df=spark.sql(sql)
        display(df)
        ls=list(df.select('privilege_type').toPandas()['privilege_type'])
        return ls
    
    def fn_check_parent_access_schema(self,Requestor_name,catalogname,schemaname,tablename=None):
        """
            Checks the access privileges of a requestor on a specified schema.

            This function queries the `schema_privileges` table to check the privileges granted to a requestor on a specified schema within a specific catalog. It returns a list of the privilege types associated with the schema, such as USAGE, CREATE, etc.

            Parameters:
                Requestor_name (str): The name of the requestor whose access privileges are being checked.
                catalogname (str): The name of the catalog where the schema is located.
                schemaname (str): The name of the schema for which the access is being checked.
                tablename (str, optional): The name of the table for which access is being checked (not used in this function). Defaults to None.

            Returns:
                list: A list of privilege types granted to the requestor on the specified schema.
        """
        sql=f"select * from {catalogname}.information_schema.schema_privileges where schema_name='{schemaname}' and grantee='{Requestor_name}'"
        print(sql)
        df=spark.sql(sql)
        display(df)
        ls=list(df.select('privilege_type').toPandas()['privilege_type'])
        return ls
        
    def fn_check_parent_access_catalog(self,Requestor_name,catalogname,schemaname=None,tablename=None):
        """
Checks the access privileges of a requestor on a specified catalog.

This function queries the `catalog_privileges` table to check the privileges granted to a requestor on a specified catalog. It returns a list of privilege types associated with the catalog, such as USAGE, CREATE, etc.

Parameters:
    Requestor_name (str): The name of the requestor whose access privileges are being checked.
    catalogname (str): The name of the catalog for which the access is being checked.
    schemaname (str, optional): The name of the schema for which access is being checked (not used in this function). Defaults to None.
    tablename (str, optional): The name of the table for which access is being checked (not used in this function). Defaults to None.

Returns:
    list: A list of privilege types granted to the requestor on the specified catalog.
"""

        sql=f"select * from {catalogname}.information_schema.catalog_privileges where catalog_name='{catalogname}' and grantee='{Requestor_name}'"
        print(sql)
        df=spark.sql(sql)
        display(df)
        ls=list(df.select('privilege_type').toPandas()['privilege_type'])
        return ls
       
    
    def fn_check_existing_access(self,requestor):  
        """
            Checks the existing access privileges of a requestor on a target object (catalog, schema, or table).

            This function determines the access privileges a requestor has on a specified target object type, which could be a catalog, schema, or table. The function calls the corresponding methods to check access to the catalog, schema, and table based on the target object type.

            Parameters:
                requestor (str): The name of the requestor whose access privileges are being checked.

            Returns:
                dict: A dictionary with keys 'catalog', 'schema', and 'table' (if applicable), each containing a list of privilege types the requestor has on the respective objects.
        """

        access_check_dict={'catalog':None,'schema':None,'table':None}
        print('checking for ',requestor  )
        if self.Target_object_type=='table':
            print('tab')
            access_check_dict['table']=self.fn_check_parent_access_table(requestor, self.catalog,self.schema,self.table)
            access_check_dict['schema']=self.fn_check_parent_access_schema(requestor,self.catalog,self.schema,None)
            access_check_dict['catalog']=self.fn_check_parent_access_catalog(requestor,self.catalog,None,None)
           
        if self.Target_object_type=='schema':
            print('sch')
            access_check_dict['schema']=self.fn_check_parent_access_schema(requestor,self.catalog,self.schema,None)
            access_check_dict['catalog']=self.fn_check_parent_access_catalog(requestor,self.catalog,None,None)
           
        if self.Target_object_type=='catalog':
            print('cat')
            access_check_dict['catalog']=self.fn_check_parent_access_catalog(requestor,self.catalog,None,None)
           
        return access_check_dict
        
            
    
    def fn_main(self):
        """
            Main function to check the access privileges for a list of groups (or a single group) of a requestor.

            This function retrieves the groups associated with a requestor and checks their existing access privileges on the target object (catalog, schema, or table). It returns a dictionary mapping each group to its respective access privileges on the target object.

            Returns:
                dict: A dictionary where keys are group names and values are dictionaries of access privileges for each object type (catalog, schema, or table).
        """

        ls_grp=[]
        master_access_check_dict={}
        #master_access_check_list=[]
        groups=self.fn_get_group()
        if isinstance(groups, list):   
            print('is list')             
            ls_grp=groups
        else:            
            print(' is not list')
            ls_grp.append(groups)
        print(ls_grp)
        for a in ls_grp:
            #master_access_check_list.append(self.fn_check_existing_access(a))
            master_access_check_dict[a]=self.fn_check_existing_access(a)
        print(master_access_check_dict)    
        return master_access_check_dict    

# COMMAND ----------

acc=access_checker(Requestor_type='group',Requestor_name='MIS_grp',Target_object_name='vw_user_details',Target_object_type='table',Access_type='read',catalog='mytestcatalog',schema='mytestschema',table='vw_user_details')

# COMMAND ----------

access_details=acc.fn_main()

# COMMAND ----------

dict_permission_model={
    'read':
        {
            'table':[{'catalog':['USE CATALOG',]},{'schema':['USE SCHEMA']},{'table':['SELECT']}],
            'schema':[{'catalog':['USE CATALOG','SELECT']},{'schema':['USE SCHEMA','SELECT']}],
            'catalog':[{'catalog':['USE CATALOG','SELECT']}]
            
        },
    'edit':
         {
            'table':[{'catalog':['USE CATALOG','SELECT']},{'schema':['USE SCHEMA','SELECT']},{'table':['MODIFY']}],
            'schema':[{'catalog':['USE CATALOG','SELECT']},{'schema':['USE SCHEMA','MODIFY']}],
            'catalog':[{'catalog':['USE CATALOG','MODIFY']}]
            
        },
    'create':
         {
            
            'schema':[{'catalog':['USE CATALOG','USE SCHEMA','SELECT']},{'schema':['USE SCHEMA','MODIFY','CREATE TABLE']}],
            'catalog':[{'catalog':['USE CATALOG','USE SCHEMA','MODIFY','CREATE SCHEMA']}]
            
        }
    
    }

# COMMAND ----------

dict_permission_model['read']['table']

# COMMAND ----------

class access_grantor:
    def __init__(self,Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,access_details,object_hierarchy):
        """
            Initializes an instance of the class with the provided parameters.

            Args:
                Requestor_type (str): The type of the requestor (e.g., 'user', 'group').
                Requestor_name (str): The name of the requestor.
                Target_object_name (str): The name of the target object (e.g., table, schema, or catalog).
                Target_object_type (str): The type of the target object (e.g., 'table', 'schema', 'catalog').
                Access_type (str): The type of access (e.g., 'read', 'write').
                access_details (dict): Details about the access being requested.
                object_hierarchy (dict): A dictionary representing the hierarchy of the object (e.g., catalog, schema, table).
        """

        self.Requestor_type=Requestor_type
        self.Requestor_name=Requestor_name
        self.Target_object_name=Target_object_name
        self.Target_object_type=Target_object_type
        self.Access_type=Access_type
        self.access_details=access_details
        self.object_hierarchy=object_hierarchy

    def fn_get_permission(self):
        """
            Main function to retrieve the required permissions based on the requestor's access type and the target object type (catalog, schema, or table).

            This function checks the `Target_object_type` (either 'table', 'schema', or 'catalog') and retrieves the corresponding permissions 
            from the `dict_permission_model` based on the `Access_type`. It returns the necessary permissions for the target object.

            Args:
                None

            Returns:
                dict: The permissions required for the specified access type and target object.
        """

        print('inside dn')
        if self.Target_object_type=='table':
            print('inide 111')
            permission_needed=dict_permission_model[self.Access_type]['table']
            return permission_needed
        elif self.Target_object_type=='schema':
            print('inide 111')
            permission_needed=dict_permission_model[self.Access_type]['schema']
            return permission_needed
        elif self.Target_object_type=='catalog':
            print('inide 111')
            permission_needed=dict_permission_model[self.Access_type]['catalog']
            return permission_needed
    
        
 
    
    def fn_grant(self,Object_type,privilege,Requestor,object_hierarchy):   
        """
            Main function to grant privileges on a specified object (schema, table, or catalog) to a requestor.

            This function checks the `Object_type` (either 'schema', 'table', or 'catalog') and constructs the appropriate object reference using 
            the `object_hierarchy` dictionary. It then generates and executes the SQL query to grant the specified privilege to the `Requestor`.

            Args:
                Object_type (str): The type of the object ('schema', 'table', or 'catalog').
                privilege (str): The privilege to be granted (e.g., 'SELECT', 'INSERT').
                Requestor (str): The name of the requestor to whom the privilege will be granted.
                object_hierarchy (dict): A dictionary containing 'catalog', 'schema', and 'table' information to construct the object reference.

            Returns:
                bool: True if the privilege was successfully granted, False otherwise.
        """

        if Object_type=='schema':
            print('a')
            obj=f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}"
        elif Object_type=='table':
           print('b')
           obj= f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}.{object_hierarchy['table']}"
        else:
           print('c')
           obj=f"{object_hierarchy['catalog']}"
        print(obj)

        try:
            sql=f"GRANT {privilege} ON {Object_type} {obj} TO `{Requestor}`"
            print(sql)
            spark.sql(sql)
        except:
            return False
        else:
            return True
        

    def fn_main(self):
        """
                Main function to retrieve required permissions and grant them to the requestor.

                This function first retrieves the permissions needed by the requestor using the `fn_get_permission` method. It then iterates through each permission and grants the appropriate privileges to the requestor for the specified object types (catalog, schema, or table) by calling the `fn_grant` method.

                Args:
                    None

                Returns:
                    None

                Notes:
                    - This function prints the permissions and grants associated with the requestor.
                    - The `fn_grant` method is called for each permission needed for the specified object types (catalog, schema, or table).
                    - The function iterates through the permissions and prints the result of each grant operation.
        """

        permissions=self.fn_get_permission()
        print(permissions)
        for obj_type_perm in permissions:
            print(obj_type_perm)
            for obj_type,perm_needed in obj_type_perm.items():
                print(obj_type)
                print(perm_needed)
                for perm in perm_needed:
                    result=self.fn_grant(obj_type,perm,self.Requestor_name,self.object_hierarchy)
                print(result)
            #print(perm_needed)


            


# COMMAND ----------

grnt=access_grantor(Requestor_type='group',Requestor_name='MIS_grp',Target_object_name='vw_user_details',Target_object_type='table',Access_type='read',access_details=None,object_hierarchy={'catalog':'mytestcatalog','schema':'mytestschema','table':'vw_user_details'})

# COMMAND ----------

grnt.fn_main()

# COMMAND ----------

class access_revoker:
    def __init__(self,Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,access_details,object_hierarchy):
        """
            Initializer for the access requestor class.

            This constructor initializes an instance of the access requestor class by accepting various parameters related to the requestor's details, the target object they are requesting access to, and the type of access they require. The object hierarchy provides information about the catalog, schema, and table associated with the request.

            Args:
                Requestor_type (str): The type of the requestor (e.g., user, group).
                Requestor_name (str): The name of the requestor.
                Target_object_name (str): The name of the target object (e.g., table, schema, catalog).
                Target_object_type (str): The type of the target object (e.g., table, schema, catalog).
                Access_type (str): The type of access being requested (e.g., read, write, admin).
                access_details (dict): Additional details regarding the access request (e.g., specific permissions).
                object_hierarchy (dict): A dictionary representing the object hierarchy, containing keys for catalog, schema, and table.

            Returns:
                None
        """

        self.Requestor_type=Requestor_type
        self.Requestor_name=Requestor_name
        self.Target_object_name=Target_object_name
        self.Target_object_type=Target_object_type
        self.Access_type=Access_type
        self.access_details=access_details
        self.object_hierarchy=object_hierarchy

    def fn_get_permission(self):
            """
            Retrieves the necessary permissions for a given access type and target object type.

            The function looks up the required permissions for a specified `Access_type` (e.g., 'read', 'write', etc.)
            based on the `Target_object_type` (i.e., 'table', 'schema', or 'catalog'). It uses a predefined dictionary
            (`dict_permission_model`) to return the permissions associated with the access type and object type.

            Returns:
                list: A list of required permissions for the specified object type (table, schema, or catalog) based on
                    the access type.
            """
        print('inside dn')
        if self.Target_object_type=='table':
            print('inide 111')
            permission_needed=dict_permission_model[self.Access_type]['table']
            return permission_needed
        elif self.Target_object_type=='schema':
            print('inide 111')
            permission_needed=dict_permission_model[self.Access_type]['schema']
            return permission_needed
        elif self.Target_object_type=='catalog':
            print('inide 111')
            permission_needed=dict_permission_model[self.Access_type]['catalog']
            return permission_needed
    
        
 
    
    def fn_revoke(self,Object_type,privilege,Requestor,object_hierarchy):  
            """
                Revokes a specific privilege from a requestor on a given object type (catalog, schema, or table).

                The function constructs an SQL `REVOKE` statement based on the provided `Object_type`, `privilege`, and `Requestor`.
                It then attempts to execute the SQL statement on the target object (catalog, schema, or table) using the object hierarchy.

                Args:
                    Object_type (str): The type of object (catalog, schema, or table) for which the privilege is being revoked.
                    privilege (str): The specific privilege (e.g., 'SELECT', 'INSERT', etc.) to revoke.
                    Requestor (str): The name of the requestor (user or group) from whom the privilege is being revoked.
                    object_hierarchy (dict): A dictionary representing the object hierarchy containing keys like 'catalog', 'schema', and 'table'.

                Returns:
                    bool: `True` if the privilege was successfully revoked, `False` otherwise.
            """ 
        if Object_type=='schema':
            print('a')
            obj=f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}"
        elif Object_type=='table':
           print('b')
           obj= f"{object_hierarchy['catalog']}.{object_hierarchy['schema']}.{object_hierarchy['table']}"
        else:
           print('c')
           obj=f"{object_hierarchy['catalog']}"
        print(obj)

        try:
            sql=f"REVOKE {privilege} ON {Object_type} {obj} FROM `{Requestor}`"
            print(sql)
            spark.sql(sql)
            print('revoked')
        except:
            print('failed')
            return False
        else:
            return True
        

    def fn_main(self):
            """
    Main function to process permissions and revoke the necessary privileges for a requestor.

    This function retrieves the permissions required for a specific target object (catalog, schema, or table)
    and attempts to revoke those privileges from the requestor. It checks if the object type matches the target
    object type and then calls the `fn_revoke` function to revoke the required permissions.

    Args:
        None

    Returns:
        None
        """

        permissions=self.fn_get_permission()
        print(permissions)
        for obj_type_perm in permissions:
            print(obj_type_perm)
            for obj_type,perm_needed in obj_type_perm.items():
                print(obj_type)
                if obj_type==self.Target_object_type:                                
                    print("perm needed is",perm_needed)
                    for perm in perm_needed:
                        result=self.fn_revoke(obj_type,perm,self.Requestor_name,self.object_hierarchy)
                    print(result)
            #print(perm_needed)


            


# COMMAND ----------

revok=access_revoker(Requestor_type='group',Requestor_name='MIS_grp',Target_object_name='vw_user_details',Target_object_type='table',Access_type='read',access_details=None,object_hierarchy={'catalog':'mytestcatalog','schema':'mytestschema','table':'vw_user_details'})

# COMMAND ----------

revok.fn_main()

# COMMAND ----------

# MAGIC %sql
# MAGIC GRANT USE CATALOG ON catalog mytestcatalog TO `Tester2@fofdlm.onmicrosoft.com`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from access_control_catalog.access_control_schema.user_groups where username='Risk_Business_developer_1@fofdlm.onmicrosoft.com'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from access_control_catalog.access_control_schema.user_groups where username='Tester2@fofdlm.onmicrosoft.com'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  access_control_catalog.access_control_schema.rlsconfig

# COMMAND ----------

