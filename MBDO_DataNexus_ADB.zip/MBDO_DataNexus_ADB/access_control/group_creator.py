# Databricks notebook source
from databricks.sdk import AccountClient

"""
This script uses the Databricks SDK to list and display the names of all groups in the Databricks account.

Modules and Classes:
- `databricks.sdk`: A library that allows interaction with the Databricks platform.
- `AccountClient`: A client class to interact with Databricks account-level resources.

Steps:
1. Instantiate the `AccountClient` to connect to the Databricks account.
2. Use the `groups.list()` method to retrieve a list of all groups in the account.
3. Iterate through the list of groups and print their `display_name` attribute.

Usage:
Ensure that the Databricks SDK is properly configured with the required credentials before running this script.
"""

a = AccountClient()

for g in a.groups.list():
  print(g.display_name)

# COMMAND ----------

""" This script demonstrates how to interact with the Databricks SCIM API to list all groups associated with a Databricks account. """

https://5028705210016768.8.gcp.databricks.com/api/2.0/accounts/b2d8bebf-664d-46a1-91f0-02886541aa7e/scim/v2/Groups

dapib371ea7f7dcc721a4bfcbd5b1543fc91

# COMMAND ----------

""" This script demonstrates how to use the Databricks SCIM API to retrieve information about the current authenticated user. """

import requests
response = requests.get('https://5028705210016768.8.gcp.databricks.com/api/2.0/preview/scim/v2/Me',
    headers={'Authorization':'Bearer dapib371ea7f7dcc721a4bfcbd5b1543fc91'},
  
  )

# COMMAND ----------

print(response.content)

# COMMAND ----------

import requests
response = requests.post('https://accounts.gcp.databricks.com/api/2.0/accounts/b2d8bebf-664d-46a1-91f0-02886541aa7e/scim/v2/Groups',
    headers={'Authorization':'Bearer 3c6e1dbb0672a451b5e164226605a2b96d834523'},
  
  )

# COMMAND ----------

# MAGIC %sh
# MAGIC nc -vz https://accounts.gcp.databricks.com/api/2.0/accounts/b2d8bebf-664d-46a1-91f0-02886541aa7e/scim/v2/Groups 443

# COMMAND ----------

# MAGIC %sh
# MAGIC nc -vz https://5028705210016768.8.gcp.databricks.com/api/2.0/preview/scim/v2/Me

# COMMAND ----------

# MAGIC %pip install databricks-sdk --upgrade

# COMMAND ----------

from databricks_cli.sdk.api_client import ApiClient
from databricks_cli.configure.provider import DatabricksConfig, update_profile
from databricks_sdk.v1 import client
from requests import Session

""" 
This script demonstrates how to use the Databricks CLI SDK and API client to list all clusters in a Databricks workspace.

Purpose:
The script connects to a Databricks workspace using a username and password for authentication. It saves the configuration 
in a profile, creates an API client, and retrieves the list of clusters in the workspace.

Key Components:
1. **DatabricksConfig**: Used to define and manage Databricks connection details.
2. **update_profile**: Saves the configuration to a specific profile for reuse.
3. **ApiClient**: A wrapper for the API session, used to interact with Databricks REST APIs.
4. **WorkspaceClient**: Provides access to Databricks workspace resources like clusters.

Steps:
1. Define the Databricks workspace URL and user credentials.
2. Create a `DatabricksConfig` object and save it to a profile.
3. Initialize an `ApiClient` with the configuration.
4. Create a `WorkspaceClient` to access workspace resources.
5. Fetch and print the names of all clusters in the workspace. """

host = "https://5028705210016768.8.gcp.databricks.com"
username = "databrick02@gcp.cimb-bank.com.vn"
password = "Cimb@2024"

config = DatabricksConfig(host=host, username=username, password=password)

# Save configuration in a file
update_profile("temp", config)
session = Session()
ac = ApiClient(session, config)
 
workspace = client.WorkspaceClient(ac)
for cluster in workspace.clusters.list():
    print(cluster.cluster_name)

# COMMAND ----------

telnet accounts.gcp.databricks.com:443

# COMMAND ----------

