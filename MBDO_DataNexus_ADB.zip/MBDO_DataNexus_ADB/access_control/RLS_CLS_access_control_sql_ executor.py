# Databricks notebook source
dbutils.widgets.text("type","")

# COMMAND ----------

typeval=dbutils.widgets.get("type")

# COMMAND ----------

print(typeval)

# COMMAND ----------

class dynamic_rls_cls:
    def __inti__(self):
        """
            Initializes an instance of the class.

            This constructor method is currently a placeholder and does not perform any operations. It can be used to initialize any attributes or setup required for the class instance.

            Parameters:
                None
        """

        pass


    def fn_create_rls_rules(self,sql_fn_name,tablename,columnname):
        """
            Creates and applies Row-Level Security (RLS) rules to a table.

            This function constructs and executes two SQL queries:
            1. It creates or replaces a function that checks if the current user is part of a specified group and if the group contains a specific region value.
            2. It alters the specified table to set the created function as the row filter for the given column.

            Parameters:
                sql_fn_name (str): The name of the SQL function to be created.
                tablename (str): The name of the table for which the RLS rule will be applied.
                columnname (str): The name of the column to which the RLS rule will be applied.

            Returns:
                bool: Returns `True` if the operation is successful, `False` otherwise.
        """
        try:
                
            sql=f"""CREATE OR REPLACE FUNCTION access_control_catalog.access_control_schema.{sql_fn_name} (param STRING) RETURN  is_account_group_member('admin') or  exists (
            -- current user is in a group and the group array contains the region. You could also do it with more advanced control, joins etc.
                SELECT 1 FROM access_control_catalog.access_control_Schema.rlsconfig WHERE tablename='{tablename}' and is_account_group_member(groupname) AND array_contains(filtervalues, param)
            )"""
            print(sql)
            spark.sql(sql)

            sql2=f"""ALTER TABLE {tablename} SET ROW FILTER access_control_catalog.access_control_schema.{sql_fn_name} ON ({columnname});"""

            print(sql2)
            spark.sql(sql2)
        except:
            print('error')
            return False
        else:
            print('success')
            return True
        

    def fn_create_cls_rules(self,sql_fn_name_cls,tablename,columnname):
        """
            Creates and applies Column-Level Security (CLS) rules to a table.

            This function constructs and executes two SQL queries:
            1. It creates or replaces a function that checks if the current user is part of a specified group and applies masking to the column based on the user’s group membership.
            2. It alters the specified table to set the created function as the column mask for the given column.

            Parameters:
                sql_fn_name_cls (str): The name of the SQL function to be created.
                tablename (str): The name of the table for which the CLS rule will be applied.
                columnname (str): The name of the column to which the CLS rule will be applied.

            Returns:
                bool: Returns `True` if the operation is successful, `False` otherwise.
        """

        try:
                
            sql=f"""CREATE OR REPLACE FUNCTION access_control_catalog.access_control_schema.{sql_fn_name_cls} (param STRING) RETURN  IF( exists (
            -- current user is in a group and the group array contains the region. You could also do it with more advanced control, joins etc.
                SELECT 1 FROM access_control_catalog.access_control_Schema.clsconfig WHERE tablename='{tablename}' and columnname='{columnname}' and is_account_group_member(groupname)),"****",param)"""
            print(sql)
            spark.sql(sql)

            sql2=f"""ALTER TABLE {tablename} alter Column {columnname} set MASK access_control_catalog.access_control_Schema.{sql_fn_name_cls};"""

            print(sql2)
            spark.sql(sql2)
        except:
            print('error')
            return False
        else:
            print('success')
            return True
        

    def fn_execute_rls_main(self):
        """
            Executes the Row-Level Security (RLS) rules for multiple tables.

            This function retrieves the RLS configuration from the `rlsconfig` table, iterates through each record, and calls the `fn_create_rls_rules` function to create and apply RLS rules for each table and column combination. It stores the results of each rule creation attempt in a dictionary and returns a list of results.

            Parameters:
                None

            Returns:
                list: A list of dictionaries, each containing the `tablename`, `columnname`, and the result (`True` or `False`) of the rule creation for that table and column.
        """
        approved_requests=spark.sql("select * from access_control_catalog.access_control_Schema.rlsconfig")
        pd_approved_requests=approved_requests.select('tablename','columnname','groupname','filtervalues').toPandas()        
        request_dict=pd_approved_requests.to_dict('records')
        print(request_dict)
        ls_results=[]
        for request in request_dict: 
            result_dict={}
            print('reu is ',request)
            tablename=request['tablename']
            columnname=request['columnname']
            sql_fn_name=columnname+"_filter"
            result=self.fn_create_rls_rules(sql_fn_name,tablename,columnname)
            result_dict['tablename']=tablename
            result_dict['columnname']=columnname
            result_dict['result']=result
            ls_results.append(result_dict)
        return ls_results
    
    def fn_execute_cls_main(self):
        """
            Executes the Column-Level Security (CLS) rules for multiple tables.

            This function retrieves the CLS configuration from the `clsconfig` table, iterates through each record, and calls the `fn_create_cls_rules` function to create and apply CLS rules for each table and column combination. It stores the results of each rule creation attempt in a dictionary and returns a list of results.

            Parameters:
                None

            Returns:
                list: A list of dictionaries, each containing the `tablename`, `columnname`, and the result (`True` or `False`) of the rule creation for that table and column.
        """

        approved_requests=spark.sql("select * from access_control_catalog.access_control_Schema.clsconfig")
        pd_approved_requests=approved_requests.select('tablename','columnname','groupname').toPandas()        
        request_dict=pd_approved_requests.to_dict('records')

        print(request_dict)
        ls_results=[]
        for request in request_dict: 
            result_dict={}
            print('reu is ',request)
            tablename=request['tablename']
            columnname=request['columnname']
            sql_fn_name=columnname+"mask"
            result=self.fn_create_cls_rules(sql_fn_name,tablename,columnname)
            result_dict['tablename']=tablename
            result_dict['columnname']=columnname
            result_dict['result']=result
            ls_results.append(result_dict)
        return ls_results

# COMMAND ----------

clsrls=dynamic_rls_cls()

# COMMAND ----------

if typeval=='CLS':
    clsrls.fn_execute_cls_main()
else:
    clsrls.fn_execute_rls_main()


# COMMAND ----------

