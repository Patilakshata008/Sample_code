# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog mytestcatalog;
# MAGIC
# MAGIC use schema mytestschema;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from mytestcatalog.mytestschema.country_details

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  TABLE  access_control_catalog.access_control_Schema.CIMB_rlsconfig (
# MAGIC   Tablename string,
# MAGIC   columnname string,
# MAGIC   groupname string,
# MAGIC   filtervalues ARRAY<STRING>
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  TABLE  access_control_catalog.access_control_Schema.CIMB_clsconfig (
# MAGIC   Tablename string,
# MAGIC   columnname string,
# MAGIC   groupname string
# MAGIC   );

# COMMAND ----------

# MAGIC %sql
# MAGIC Insert into access_control_catalog.access_control_Schema.clsconfig 
# MAGIC select 'mytestcatalog.mytestschema.country_details','value','Asia'
# MAGIC union all
# MAGIC select 'mytestcatalog.mytestschema.department_details','salary','HR'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from access_control_catalog.access_control_Schema.CIMB_rlsconfig 

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from  access_control_catalog.access_control_Schema.CIMB_clsconfig 

# COMMAND ----------

# MAGIC %sql
# MAGIC Insert into access_control_catalog.access_control_Schema.rlsconfig 
# MAGIC select 'mytestcatalog.mytestschema.country_details','country','Europe',Array("italy",'germany')
# MAGIC --union all
# MAGIC --select 'mytestcatalog.mytestschema.department_details','deptname','HR',Array("Tech", "finance")

# COMMAND ----------

# MAGIC %sql
# MAGIC update access_control_catalog.access_control_Schema.rlsconfig  set filtervalues=Array("sales",'finance')  where tablename='mytestcatalog.mytestschema.department_details'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS mytestcatalog.mytestschema.map_country_group (
# MAGIC   identity_group STRING,
# MAGIC   countries ARRAY<STRING>
# MAGIC );
# MAGIC INSERT OVERWRITE mytestcatalog.mytestschema.map_country_group (identity_group, countries) VALUES
# MAGIC   ('Asia', Array("india", "vietnam")),
# MAGIC   ('Europe',  Array("italy","germany"));

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from access_control_catalog.access_control_Schema.rlsconfig 

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION mytestcatalog.mytestschema.region_filter(region_param STRING)
# MAGIC
# MAGIC  RETURN 
# MAGIC  is_account_group_member('admin') or 
# MAGIC  exists (
# MAGIC   -- current user is in a group and the group array contains the region. You could also do it with more advanced control, joins etc.
# MAGIC      SELECT 1 FROM mytestcatalog.mytestschema.map_country_group WHERE is_account_group_member(group_name) AND array_contains(filter_values, region_param)
# MAGIC  );

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE mytestcatalog.mytestschema.country_details SET ROW FILTER mytestcatalog.mytestschema.region_filter ON (country);

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 1 FROM access_control_catalog.access_control_Schema.rlsconfig WHERE tablename={} and is_account_group_member(identity_group) AND array_contains(countries, region_param)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION mytestcatalog.mytestschema.dynamic_row_filter(param STRING)
# MAGIC
# MAGIC  RETURN 
# MAGIC  is_account_group_member('admin') or 
# MAGIC  exists (
# MAGIC   -- current user is in a group and the group array contains the region. You could also do it with more advanced control, joins etc.
# MAGIC      SELECT 1 FROM access_control_catalog.access_control_Schema.rlsconfig WHERE is_account_group_member(groupname) AND array_contains(filtervalues, param)
# MAGIC  );

# COMMAND ----------

# MAGIC %sql
# MAGIC --ALTER TABLE mytestcatalog.mytestschema.country_details Remove ROW FILTER mytestcatalog.mytestschema.dynamic_row_filter ON (country);
# MAGIC ALTER TABLE mytestcatalog.mytestschema.country_details DROP ROW FILTER;

# COMMAND ----------

def fn_create_rls_rules(sql_fn_name,tablename,columnname):
    sql=f"""CREATE OR REPLACE FUNCTION access_control_catalog.access_control_schema.{sql_fn_name} (param STRING) RETURN  is_account_group_member('admin') or  exists (
    -- current user is in a group and the group array contains the region. You could also do it with more advanced control, joins etc.
        SELECT 1 FROM access_control_catalog.access_control_Schema.rlsconfig WHERE tablename='{tablename}' and is_account_group_member(groupname) AND array_contains(filtervalues, param)
    )"""
    print(sql)
    spark.sql(sql)

    sql2=f"""ALTER TABLE {tablename} SET ROW FILTER access_control_catalog.access_control_schema.{sql_fn_name} ON ({columnname});"""

    print(sql2)
    spark.sql(sql2)


# COMMAND ----------

approved_requests=spark.sql("select * from access_control_catalog.access_control_Schema.rlsconfig")
pd_approved_requests=approved_requests.select('tablename','columnname','groupname','filtervalues').toPandas()        
request_dict=pd_approved_requests.to_dict('records')

print(request_dict)
for request in request_dict: 
    print('reu is ',request)
    tablename=request['tablename']
    columnname=request['columnname']
    sql_fn_name=columnname+"_filter"
    fn_create_rls_rules(sql_fn_name,tablename,columnname)



# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION access_control_catalog.access_control_schema.country_details_country_filter (param STRING) RETURN  is_account_group_member('admin') or  exists (
# MAGIC   -- current user is in a group and the group array contains the region. You could also do it with more advanced control, joins etc.
# MAGIC      SELECT 1 FROM access_control_catalog.access_control_Schema.rlsconfig WHERE tablename='mytestcatalog.mytestschema.country_details' and is_account_group_member(groupname) AND array_contains(filtervalues, param)
# MAGIC  );
# MAGIC ALTER TABLE mytestcatalog.mytestschema.country_details SET ROW FILTER access_control_catalog.access_control_schema.country_details_country_filter ON (country);

# COMMAND ----------

