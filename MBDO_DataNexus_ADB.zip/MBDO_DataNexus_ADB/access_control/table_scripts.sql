-- Databricks notebook source
create catalog access_control_catalog;

-- COMMAND ----------

create schema access_control_catalog.access_control_schema;

-- COMMAND ----------

use access_control_catalog.access_control_schema;

-- COMMAND ----------

drop table access_control_catalog.access_control_schema.user_access_requests;

-- COMMAND ----------

create table access_control_catalog.access_control_schema.cimb_user_access_requests(id bigint generated always as identity,Requestor_type string,Requestor_name string,Target_object_name string,Target_object_type string,Access_type string,create_time timestamp,is_approved int,Remarks string,decision_time timestamp,status string,catalog string,schema string,table string,Request_type string,access_granted_time timestamp)

-- COMMAND ----------

alter table  access_control_catalog.access_control_schema.user_access_requests add column access_granted_time timestamp;

-- COMMAND ----------

select * from user_access_requests

-- COMMAND ----------



-- COMMAND ----------

create catalog RISK_Dev_catalog;

-- COMMAND ----------

drop table access_control_catalog.access_control_schema.user_groups

-- COMMAND ----------

create table access_control_catalog.access_control_schema.user_groups(username string,groupname string)

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_groups
select  'Tech_developer_1@fofdlm.onmicrosoft.com','Tech_Dev_grp' union all 
select  'Tech_developer_2@fofdlm.onmicrosoft.com','Tech_Dev_grp' union all 
select  'Tester1@fofdlm.onmicrosoft.com','Tester_grp' union all 
select  'Tester2@fofdlm.onmicrosoft.com','Tester_grp' union all 
select  'Risk_Business_developer_1@fofdlm.onmicrosoft.com','RISK_Business_dev_grp' union all 
select  'Risk_Business_developer_1@fofdlm.onmicrosoft.com','testgrp' union all 
select  'Risk_Business_developer_2@fofdlm.onmicrosoft.com','RISK_Business_dev_grp' union all 
select  'RISK_Business_user_1@fofdlm.onmicrosoft.com','RISK_Business_user_grp' union all 
select  'RISK_Business_user_2@fofdlm.onmicrosoft.com','RISK_Business_user_grp' union all 
select  'MIS_user_1@fofdlm.onmicrosoft.com','MIS_grp' union all 
select  'MIS_user_2@fofdlm.onmicrosoft.com','MIS_grp' union all 
select  'Data_scientist_1@fofdlm.onmicrosoft.com','Data_science_grp' union all 
select  'Data_scientist_2@fofdlm.onmicrosoft.com','Data_science_grp' union all
select 'rajasankar.radhakrishnan@gcp.cimb-bank.com.vn','Tech_Dev_grp' union all
select 'pavankumar.vendluru@gcp.cimb-bank.com.vn','MIS_grp'

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
select 'group','RISK_Business_dev_grp','silver_test','schema','create',current_timestamp(),'approved','cimb_silver','silver_test','scd2demo','add'

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
select 'group','RISK_Business_dev_grp','RISK_Dev_catalog','table','read',current_timestamp(),'in-progress','cimb_silver','silver_test','scd2demo','remove'

-- COMMAND ----------

GRANT use catalog on catalog RISK_Dev_catalog to RISK_Business_dev_grp

-- COMMAND ----------

select ('Tech_developer_2@fofdlm.onmicrosoft.com','Tech_Dev_grp')

-- COMMAND ----------

select * from mytestcatalog.information_schema.table_privileges 

-- COMMAND ----------

insert into mytestcatalog.mytestschema.testtable(id,name)
select 1,'raja'

-- COMMAND ----------

create table  mytestcatalog.mytestschema.department_details(id int,deptname string,empname string,salary int);

-- COMMAND ----------

INSERT OVERWRITE mytestcatalog.mytestschema.department_details (id,deptname,empname,salary) VALUES
(1,'Tech','raja',22),
(2,'sales','john',33),
(3,'finance','ken',44),
(4,'Tech','pavan',55),
(5,'sales','kan',66),
(6,'finance','peter',77)

-- COMMAND ----------

select * from mytestcatalog.information_schema.row_filters

-- COMMAND ----------

