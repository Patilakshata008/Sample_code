# Databricks notebook source
class managetags:
    def __init__(self,catalog_name,schema_name,table_name,tags={}):
        """
                Initializes an instance to manage metadata for a database table.

                This function sets up the necessary attributes to represent a table within a catalog and schema structure. It also supports optional tagging for metadata purposes.

                Parameters:
                    catalog_name (str): The name of the catalog containing the table.
                    schema_name (str): The name of the schema under the catalog.
                    table_name (str): The name of the table to reference.
                    tags (dict, optional): A dictionary of tags to associate with the table. Defaults to an empty dictionary.

                Attributes:
                    table_name (str): Stores the name of the table.
                    schema_name (str): Stores the name of the schema.
                    catalog_name (str): Stores the name of the catalog.
                    tags (dict): Stores the associated tags for the table.
        """

        self.table_name=table_name
        self.schema_name=schema_name
        self.catalog_name=catalog_name
        self.tags=tags

    def add_tags(self):
        """
            Adds tags to a database table as table properties.

            This function constructs a SQL query to set table properties based on the provided tags. It iterates over the `tags` dictionary, formats each tag as a key-value pair, and executes an `ALTER TABLE` statement using the Spark SQL interface.

            Parameters:
                None

            Attributes Used:
                catalog_name (str): The catalog name where the table resides.
                schema_name (str): The schema name under the catalog.
                table_name (str): The name of the table to which tags will be added.
                tags (dict): A dictionary of tags to be added as table properties.
        """
        keys=""
        for tag,value in self.tags.items():
            keys=keys+f"'{tag}'='{value}'"
        print(keys)
        sql=f"alter table {self.catalog_name}.{self.schema_name}.{self.table_name} SET TBLPROPERTIES ({keys});"
        print(sql)
        spark.sql(sql)

    def check_tags(self):
        """
            Checks for tables missing tags in the catalog and schema.

            This function constructs a SQL query to identify tables within a catalog that do not have associated tags. It performs a left outer join between the `tables` and `table_tags` information schema views and filters out tables that have no tags. The results are displayed in a DataFrame.

            Parameters:
                None

            Attributes Used:
                catalogs (list): A list of catalog names to query.
        """

        for cat in catalogs:
            sql=f"select * from {cat}.information_schema.tables t left outer join {cat}.information_schema.table_tags tt on t.table_name=tt.table_name where tt.table_name is null and t.table_schema!='information_schema'"
            print(sql)
            df=spark.sql(sql)
            display(df)

    def remove_tags(self):
        """
                Removes tags from a database table's properties.

                This function constructs a SQL query to remove table properties based on the provided tags. It iterates over the `tags` dictionary and formats each tag as a key-value pair, then constructs and executes an `ALTER TABLE` statement to unset those properties.

                Parameters:
                    None

                Attributes Used:
                    catalog_name (str): The catalog name where the table resides.
                    schema_name (str): The schema name under the catalog.
                    table_name (str): The name of the table from which tags will be removed.
                    tags (dict): A dictionary of tags to be removed from the table properties.
        """
        keys=""
        for tag,value in self.tags:
            keys=keys+f"'{tag}'='{value}'"
        print(keys)
        sql=f"alter table {self.catalog_name}.{self.schema_name}.{self.table_name} UNSET TBLPROPERTIES ({keys});"
        



# COMMAND ----------

catalogs=['cimbmain_bronze']

# COMMAND ----------

for cat in catalogs:
    sql=f"select * from {cat}.information_schema.tables t left outer join {cat}.information_schema.table_tags tt on t.table_name=tt.table_name where tt.table_name is null and t.table_schema!='information_schema'"
    print(sql)
    df=spark.sql(sql)
    display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table cimbmain_bronze.uat2_card.vcb_voucher SET TBLPROPERTIES ('name'='nrew table');

# COMMAND ----------

mn=managetags('cimbmain_bronze','uat2_card','vcb_voucher',{'type':'new table1'})

# COMMAND ----------

mn.add_tags()

# COMMAND ----------

