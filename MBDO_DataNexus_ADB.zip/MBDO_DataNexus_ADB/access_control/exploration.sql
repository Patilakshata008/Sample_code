-- Databricks notebook source
SHOW GRANTS on schema mytestcatalog.mytestschema

-- COMMAND ----------

GRANT SELECT on TABLE mytestcatalog.mytestschema.testtable to Tech_Dev_grp

-- COMMAND ----------

create table cimb_access_control_catalog.cimb_access_control_schema.test_c(id int)

-- COMMAND ----------

SHOW catalogs;

-- COMMAND ----------

drop table loan

-- COMMAND ----------

create table loan(loan_no string,value int,created_time timestamp)

-- COMMAND ----------

create table repayment(loan_no string,period_no string,repay_value int,created_time timestamp)

-- COMMAND ----------

create table loan_key(loan_no string,period_no string)

-- COMMAND ----------

insert into loan

select 1,1000,current_timestamp() union all
select 2,2000,current_timestamp()

-- COMMAND ----------

insert into repayment
select 1,2,1000,current_timestamp()
--select 1,1,1000,current_timestamp() union all
--select 2,1,2000,current_timestamp()

-- COMMAND ----------

drop table loan_key

-- COMMAND ----------

insert into loan_key
select 1,1 union all
select 2,1 union all
select 1,2

-- COMMAND ----------

update loan_key set period_no =2 where loan_no =1

-- COMMAND ----------

select * from loan_key

-- COMMAND ----------

select * from loan

-- COMMAND ----------

select * from repayment

-- COMMAND ----------

select loan.loan_no,lk.period_no,rp.period_no,* from loan_key lk left outer join loan loan
on lk.loan_no=loan.loan_no
left outer join repayment rp
on lk.loan_no=rp.loan_no
and ifnull(lk.period_no,1)=case when lk.period_no is null then 1 else rp.period_no end

-- COMMAND ----------

select * from cimbmain_bronze.uat2_cbs.lna_repayment_schedule

-- COMMAND ----------

CREATE OR REPLACE FUNCTION access_control_catalog.access_control_schema.lna_repayment_schedule_period_interest_mask (param STRING) RETURN  IF( exists (
            -- current user is in a group and the group array contains the region. You could also do it with more advanced control, joins etc.
                SELECT 1 FROM access_control_catalog.access_control_Schema.clsconfig WHERE tablename='cimbmain_bronze.uat2_cbs.lna_repayment_schedule' and columnname='period_interest' and is_account_group_member(groupname)),"****",param)


-- COMMAND ----------

ALTER TABLE cimbmain_bronze.uat2_cbs.lna_repayment_schedule alter Column period_interest set MASK access_control_catalog.access_control_Schema.lna_repayment_schedule_period_interest_mask;

-- COMMAND ----------

ALTER TABLE cimbmain_bronze.uat2_cbs.lna_repayment_schedule alter Column period_interest drop mask

-- COMMAND ----------

select * from access_control_catalog.access_control_Schema.clsconfig

-- COMMAND ----------

update access_control_catalog.access_control_Schema.clsconfig set columnname='period_interest' where columnname='principal' and groupname='FIN_grp'

-- COMMAND ----------

insert  into access_control_catalog.access_control_Schema.clsconfig
select 'cimbmain_bronze.uat2_cbs.lna_repayment_schedule','period_interest','HR'

-- COMMAND ----------

delete from access_control_catalog.access_control_Schema.clsconfig where groupname='FIN_grp'

-- COMMAND ----------

select distinct loan_type from cimbmain_bronze.uat2_cbs.lna_loan

-- COMMAND ----------

select * from access_control_catalog.access_control_schema.clsconfig

-- COMMAND ----------

create table access_control_catalog.access_control_schema.test(id int)

-- COMMAND ----------

select * from access_control_catalog.access_control_schema.user_access_requests

-- COMMAND ----------

