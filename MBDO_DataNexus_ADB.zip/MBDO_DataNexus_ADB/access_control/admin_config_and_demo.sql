-- Databricks notebook source
-- MAGIC %md #Table access control

-- COMMAND ----------


select pvl.privilege_type,pvl.grantee,pvl.grantor,t.* from system.information_schema.tables t left outer join system.information_schema.table_privileges pvl
on t.table_name=pvl.table_name  where t.table_catalog='mytestcatalog' and t.table_Schema='mytestschema' and t.table_name in ('country_details','user_details')

-- COMMAND ----------

-- MAGIC %md
-- MAGIC The user (rajasankar.radhakrishnan@gcp.cimb-bank.com.vn) does not have access to teh above tables
-- MAGIC The user is part of "Csb_grp"

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Lets grant access:

-- COMMAND ----------

-- MAGIC %md
-- MAGIC add entry to the user_access_requests table

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
select 'group','FIN_grp','uat2_cbs','schema','read',current_timestamp(),'approved','cimbmain_bronze','uat2_cbs','None','add'

-- COMMAND ----------

use catalog access_control_catalog;

-- COMMAND ----------

use schema access_control_schema

-- COMMAND ----------

show tables;

-- COMMAND ----------

select current_schema()

-- COMMAND ----------

select * from user_access_requests

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Execute the Access control script to provide access

-- COMMAND ----------

-- MAGIC %md Now user is able to read records but not able to edit records in the table

-- COMMAND ----------

-- MAGIC %md Provide edit access to the user

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
select 'group','Csb_grp','user_details','table','edit',current_timestamp(),'approved','mytestcatalog','mytestschema','user_details','add'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Execute the Access control script to provide access

-- COMMAND ----------

-- MAGIC %md Now user is able to delete records

-- COMMAND ----------

-- MAGIC %md But user cannot crearte new tables

-- COMMAND ----------

-- MAGIC %md Provide user access to create tables

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
select 'group','Csb_grp','my_test_schema','schema','create',current_timestamp(),'approved','mytestcatalog','mytestschema','None','add'

-- COMMAND ----------

-- MAGIC %md Now execute access control script

-- COMMAND ----------

-- MAGIC %md lets revoke the edit access on user_details table

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
select 'group','Csb_grp','user_details','table','edit',current_timestamp(),'approved','mytestcatalog','mytestschema','user_details','remove'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC user is unable to edit the table now

-- COMMAND ----------

-- MAGIC %md #Row Level security

-- COMMAND ----------

-- MAGIC %md now the user has access to read the table.Lets set up RLS

-- COMMAND ----------

select * from access_control_catalog.access_control_Schema.rlsconfig

-- COMMAND ----------

-- MAGIC %md add RLS to user_details tables.members of MIS_grp can read finance,slaes data

-- COMMAND ----------

Insert into access_control_catalog.access_control_Schema.rlsconfig 
select 'cimbmain_bronze.uat2_cbs.lna_loan','loan_type','ML_grp',Array("SIMPLE")

-- COMMAND ----------

select * from access_control_catalog.access_control_Schema.rlsconfig

-- COMMAND ----------

-- MAGIC %md execute the RLS executor

-- COMMAND ----------

-- MAGIC %md
-- MAGIC user only sees the finance and sales data

-- COMMAND ----------

-- MAGIC %md
-- MAGIC lets do the same for other table

-- COMMAND ----------

-- MAGIC %md provide the user access to "country_details" table

-- COMMAND ----------

insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
select 'group','Csb_grp','country_details','table','read',current_timestamp(),'approved','mytestcatalog','mytestschema','country_details','add'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC use can access country_details data

-- COMMAND ----------

-- MAGIC %md
-- MAGIC add RLS to country details table

-- COMMAND ----------

Insert into access_control_catalog.access_control_Schema.rlsconfig 
select 'mytestcatalog.mytestschema.country_details','country','Asia',Array("india","vietnam")
union all
select 'mytestcatalog.mytestschema.country_details','country','Europe',Array("germany","italy")

-- COMMAND ----------

-- MAGIC %md check user is added to continent group

-- COMMAND ----------

select * from access_control_catalog.access_control_Schema.rlsconfig

-- COMMAND ----------

-- MAGIC %md run the dynamic RLS script once

-- COMMAND ----------

-- MAGIC %md user can only see Asian continents as he is part of Asia group
-- MAGIC

-- COMMAND ----------

-- MAGIC %md add the user to Europe group

-- COMMAND ----------

-- MAGIC %md user can now can see couintries of europe and asia

-- COMMAND ----------

-- MAGIC %md #Column level security

-- COMMAND ----------

select * from access_control_catalog.access_control_schema.user_row_filter

-- COMMAND ----------

-- MAGIC %md user is now able to see all columns of user_details and country_details tables

-- COMMAND ----------

-- MAGIC %md lets add some cls on both the tables

-- COMMAND ----------

describe table access_control_catalog.access_control_schema.cimb_clsconfig

-- COMMAND ----------

Insert into access_control_catalog.access_control_Schema.clsconfig 
select 'cimbmain_bronze.uat2_cbs.lna_repayment_schedule','principal','FIN_grp'
--union all
--select 'cimbmain_bronze.uat2_cbs.lna_loan','salary','HR'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC change CLS for country_details from FIN_grp to MIS_grp

-- COMMAND ----------

-- MAGIC %md check if user is part of HR and Asia group

-- COMMAND ----------

update access_control_catalog.access_control_Schema.clsconfig set groupname='MIS_grp' where groupname='FIN_grp'

-- COMMAND ----------

select * from access_control_catalog.access_control_Schema.user_access_requests

-- COMMAND ----------

