-- Databricks notebook source
-- MAGIC %md #REVOKE access

-- COMMAND ----------

-- MAGIC %md REVOKE ALL access for the tables

-- COMMAND ----------

-- MAGIC %md remove user from csb_grp,Asia,Europe ,FIN_grp,HR

-- COMMAND ----------

-- MAGIC  %md #Create objects

-- COMMAND ----------

delete from access_control_catalog.access_control_schema.user_access_requests;

-- COMMAND ----------

drop table if exists mytestcatalog.mytestschema.tab1

-- COMMAND ----------

drop table if exists mytestcatalog.mytestschema.tab2

-- COMMAND ----------

delete from mytestcatalog.mytestschema.country_details

-- COMMAND ----------



insert into mytestcatalog.mytestschema.country_details 
select 1,'india',123232 union all
select 2,'vietnam',5454 union all
select 3,'us',999 union all
select 4,'india',6454 union all
select 5,'germany',1818

-- COMMAND ----------

delete from mytestcatalog.mytestschema.user_details

-- COMMAND ----------



insert into mytestcatalog.mytestschema.user_details 
select 1,'Raja','finance',13232 union all
select 2,'user2','IT',5454 union all
select 3,'user3','sales',87878 union all
select 4,'user4','finance',1212 union all
select 5,'user5','sales',8844

-- COMMAND ----------

delete from access_control_catalog.access_control_Schema.rlsconfig

-- COMMAND ----------

delete from access_control_catalog.access_control_Schema.clsconfig

-- COMMAND ----------

alter table mytestcatalog.mytestschema.country_details DROP ROW FILTER;

-- COMMAND ----------

alter table cimbmain_bronze.uat2_cbs.lna_loan DROP ROW FILTER;

-- COMMAND ----------

drop function access_control_catalog.access_control_schema.loan_type_filter

-- COMMAND ----------

alter table cimbmain_bronze.uat2_cbs.lna_repayment_schedule alter column period_interest DROP  MASK;

-- COMMAND ----------

alter table mytestcatalog.mytestschema.user_details alter column salary DROP  MASK;

-- COMMAND ----------

 create table mytestcatalog.mytestschema.test_user_country(id int,username string,country string,salary bigint)

-- COMMAND ----------

select distinct loan_type from cimbmain_bronze.uat2_cbs.lna_loan

-- COMMAND ----------

