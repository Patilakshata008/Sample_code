# Databricks notebook source
# MAGIC %run "/Repos/access_control/access_control/access_control/dynamic_access_control_script"

# COMMAND ----------

dict_permission_model={
    'read':
        {
            'table':[{'catalog':['USE CATALOG',]},{'schema':['USE SCHEMA']},{'table':['SELECT']}],
            'schema':[{'catalog':['USE CATALOG','SELECT']},{'schema':['USE SCHEMA','SELECT']}],
            'catalog':[{'catalog':['USE CATALOG','SELECT']}]
            
        },
    'edit':
         {
            'table':[{'catalog':['USE CATALOG']},{'schema':['USE SCHEMA']},{'table':['MODIFY']}],
            'schema':[{'catalog':['USE CATALOG']},{'schema':['USE SCHEMA','MODIFY']}],
            'catalog':[{'catalog':['USE CATALOG','MODIFY']}]
            
        },
    'create':
         {
            
            'schema':[{'catalog':['USE CATALOG']},{'schema':['USE SCHEMA','CREATE TABLE']}],
            'catalog':[{'catalog':['USE CATALOG','MODIFY','CREATE SCHEMA']}]
            
        }
    
    }

# COMMAND ----------

# MAGIC %md
# MAGIC statuses:
# MAGIC         submitted
# MAGIC             approved
# MAGIC                 fulfilled
# MAGIC             rejected
# MAGIC         

# COMMAND ----------

class AccessExecutor:
    def __init__(self):
        """
            Initializes an instance of the class.

            This constructor method is currently a placeholder and does not perform any operations. It can be used to initialize any attributes or setup required for the class instance.

            Parameters:
                None
        """

        pass



    def fn_fetch_pending_requests(self):
        """
            Fetches and returns pending approved user access requests.

            This function retrieves the user access requests that are marked as 'approved' from the `user_access_requests` table. It then converts the relevant columns into a Pandas DataFrame and returns the data as a list of dictionaries, with each dictionary representing a single request.

            Parameters:
                None

            Returns:
                list: A list of dictionaries, each containing the details of an approved user access request.
        """

        approved_requests=spark.sql("select * from access_control_catalog.access_control_schema.user_access_requests where status='approved'")
        pd_approved_requests=approved_requests.select('id','Requestor_type','Requestor_name','Target_object_name','Target_object_type','Access_type','catalog','schema','table','Request_type').toPandas()        
        return pd_approved_requests.to_dict('records')
    

    def fn_check_if_access_already_satisfied(self,request_param):
        """
            Checks if access has already been granted for a specific request.

            This function receives a `request_param` and prints it for inspection. The logic for checking if access is already satisfied can be added to this method.

            Parameters:
                request_param (dict): A dictionary containing the details of the access request to be checked.

            Returns:
                None
        """

        print('request_param',request_param)

    def fn_update_status(self,iden,status):
        """
            Updates the status of a user access request.

            This function updates the status of a user access request in the `user_access_requests` table. It also records the current timestamp as the `access_granted_time` when the status is updated.

            Parameters:
                iden (int): The ID of the access request to be updated.
                status (str): The new status to set for the access request.

            Returns:
                None
        """

        sql=f"update access_control_catalog.access_control_schema.user_access_requests set status='{status}',access_granted_time=current_timestamp() where id={iden}"
        spark.sql(sql)
        
    

    def fn_execute(self):
        """
            Executes the process for fetching and processing pending user access requests.

            This function fetches the list of pending approved user access requests and processes them based on the `Request_type`. It handles both 'add' and 'remove' types of requests. For each request, it processes the required actions (e.g., granting or revoking access), updates the status of the request, and prints relevant details.

            Parameters:
                None

            Returns:
                None
        """

        requests_to_be_processed=self.fn_fetch_pending_requests()
        for request in requests_to_be_processed:          
            id=request['id']  
            request['object_hierarchy']={'catalog':request['catalog'],'schema':request['schema'],'table':request['table']}  
            del request['catalog']          
            del request['table']
            del request['schema']
            del request['id']
            print('post processed',request)
            ac=access_checker(**request)
            details=ac.fn_main()
            if request['Request_type']=='add':                
                pass
                print('add')
                #self.fn_check_if_access_already_satisfied(request)
                request['dict_permission_model']=dict_permission_model
                ac=access_grantor(**request)
                details=ac.fn_main()

                self.fn_update_status(id,'granted')

            elif request['Request_type']=='remove':                
                pass
                print('remove')
                #self.fn_check_if_access_already_satisfied(request)
                request['dict_permission_model']=dict_permission_model
                ac=access_revoker(**request)
                details=ac.fn_main()

                self.fn_update_status(id,'granted')
            print(request)

        #calling the access checker module to check if user already has access to the requested object
        
        print(details)

# COMMAND ----------

ac=AccessExecutor()
ac.fn_execute()

# COMMAND ----------

