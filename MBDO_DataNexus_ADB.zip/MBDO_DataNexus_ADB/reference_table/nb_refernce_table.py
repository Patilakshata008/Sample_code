# Databricks notebook source
#Import statements
import re
from datetime import datetime

# Function to rename columns by replacing special characters
def renameColumns(df):
    characters = r"[\[\].;:(){}\n\t=]"
    for col in df.columns:
        if re.search(characters, col):
            new_col = re.sub(characters, '_', col)  
            df = df.withColumnRenamed(col, new_col)
    return df

# Function to sanitize sheet names and column names
def sanitizeName(name):
    return re.sub(r'[ ,;{}()\n\t=]', '_', name.lower())

# Function to process Excel file from Bronze volume and store in Silver layer (External Table)
def processExcel(bronze_volume_path, silver_catalog, silver_schema, sheet_names, external_location):
    if not sheet_names:
        print("No sheet names provided.")
        return

    for sheet in sheet_names:
        sanitized_sheet_name = sanitizeName(sheet)

        # Read the specified sheet from the Bronze layer
        df = spark.read.format("com.crealytics.spark.excel") \
            .option("dataAddress", f"'{sheet}'!") \
            .option("header", "true") \
            .option("treatEmptyValuesAsNulls", "true") \
            .option("inferSchema", "true") \
            .load(bronze_volume_path)

        # Rename columns to replace special characters
        df = renameColumns(df)

        # Sanitize the column names
        sanitized_column_names = [sanitizeName(col) for col in df.columns]
        for old_col, new_col in zip(df.columns, sanitized_column_names):
            df = df.withColumnRenamed(old_col, new_col)

        # Define the external table path in Unity Catalog with a unique timestamp
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        table_name = f"{silver_catalog}.{silver_schema}.{sanitized_sheet_name}"
        table_path = f"{external_location}/{sanitized_sheet_name}_{timestamp}"

        # Save the DataFrame as a Delta table at the external location
        df.write.format("delta") \
            .mode("overwrite") \
            .option("path", table_path) \
            .save()  

        # Use SQL to register the external table in Unity Catalog
        spark.sql(f"""
            CREATE EXTERNAL TABLE IF NOT EXISTS {table_name}
            USING DELTA
            LOCATION '{table_path}'
        """)

        print(f"External table {table_name} created at {table_path} using Unity Catalog!")

# Define paths and schema for Unity Catalog
bronze_volume_path = "/Volumes/mbdo_bronze_dev/reference_table/raw/reference_table.xlsx"
silver_catalog = "mbdo_silver_dev"
silver_schema = "t_reference_table"
external_location = "abfss://silver@mbdodlsdevgwc001.dfs.core.windows.net/reference_table"

# Specify the sheet names to process
sheet_names = [
    "t_capacity_mapping", "t_plant_master", "t_supplier_mapping",
    "t_currency_rate_mapping", "t_supplier_code_mapping", "t_capacity_mapping",
    "t_supplier_info_mapping", "t_plant_supplier_mapping", "t_price_diff_mapping",
    "t_currency_exchange_mapping", "t_supplier_price_comparsion", "t_price_difference_mapping",
    "t_info_record_category_mapping", "t_pcb_stackup_mapping", "t_laminate_supplier_mapping",
    "t_buyer_mapping"
]

# Process Excel file
processExcel(bronze_volume_path, silver_catalog, silver_schema, sheet_names, external_location)


# COMMAND ----------

