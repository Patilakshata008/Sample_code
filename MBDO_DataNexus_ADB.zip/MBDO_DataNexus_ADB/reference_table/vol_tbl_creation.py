# Databricks notebook source
########### define paths and source system ##################
Sourcesystem='reference_table'
bronze_path = "abfss://bronze@mbdodlsdevgwc001.dfs.core.windows.net/" + "reference_table"
silver_path = "abfss://silver@mbdodlsdevgwc001.dfs.core.windows.net/" + "reference_table"

# COMMAND ----------

##### create volume and schema for bronze #############

full_qry = f"CREATE SCHEMA  IF NOT EXISTS  mbdo_bronze_dev.{Sourcesystem} MANAGED  LOCATION '{bronze_path}';"
print(full_qry)
spark.sql(full_qry)
full_qry = f"CREATE EXTERNAL VOLUME IF NOT EXISTS  mbdo_bronze_dev.{Sourcesystem}.Raw   LOCATION '{bronze_path}/Raw';"
print(full_qry)
spark.sql(full_qry)


########### create schema for silver layer ###############

silver_layer = f"CREATE SCHEMA  IF NOT EXISTS  mbdo_silver_dev.t_reference_table  MANAGED  LOCATION '{silver_path}';"
print(silver_layer)
spark.sql(silver_layer)