# Pre-deployment Scripts UC

This repository contains pre-deployment scripts to automate the setup of Azure Databricks resources, including external locations, catalogs, tables, and user groups for configuring the data pipeline environment.

## Table of Contents

1. [Catalogs_creation.sql](#catalogs_creation_sql)
2. [db_configreader.py](#dbconfigreaderpy)
3. [Main.py](#mainpy)
4. [table_folder_creation.py](#table_folder_creationpy)
5. [usergroup_access_API.py](#usergroup_access_apipy)

---

## Catalogs_creation.sql

### Overview

The `Catalogs_creation.sql` script automates the creation of external locations and catalogs in Azure Databricks. It sets up external locations for the Landing, Bronze, Silver, and Gold zones and creates the corresponding catalogs to manage data within these locations.

### Steps:

#### External Location Creation:
- Defines the external location name and path for each data zone: Landing, Bronze, Silver, and Gold.
- Constructs and executes a SQL query to create the external location if it doesn't already exist.

#### Catalog Creation:
- Constructs and executes a SQL query to create the Landing, Bronze, Silver, and Gold catalogs with the respective managed locations.

---

## db_configreader.py

### Overview

The `db_configreader.py` script defines a `Dbconfigreaders` class used to interact with a database and retrieve various configuration details necessary for the pipeline. It includes methods for fetching schema details, Delta Lake configurations, and database-table information.

### Methods:
- **`__init__`**: Initializes the class with a database connection and `fnt_id`.
- **`fn_get_schema`**: Executes a stored procedure to retrieve schema details and returns them as a list of dictionaries.
- **`fn_get_deltaLake_configs`**: Executes a stored procedure to retrieve Delta Lake configurations and returns them as a dictionary.
- **`fn_get_db_tb_ss_fnt`**: Executes a SQL query to retrieve database, table, and source system details and returns them as a dictionary.
- **`getall_configs`**: Combines all methods to retrieve configurations and returns them in a dictionary.

---

## Main.py

### Overview

The `Main.py` script sets up configurations, creates external locations, and manages schemas and volumes in Azure Data Lake Storage. It connects to the database, retrieves configurations using `db_configreader`, and creates external locations and schemas.

### Steps:
1. **Import and Initialization**:
   - Imports necessary classes and modules.
   - Retrieves secrets for storage account key and database connection details.
   - Initializes a Spark session and sets configuration parameters.
   - Establishes a database connection and retrieves configuration details using `Dbconfigreaders`.

2. **Define Paths and Create Directories**:
   - Defines paths for landing, bronze, and silver schemas.
   - Sets the storage account key configuration.
   - Checks if directories exist and creates them if they do not.

3. **External Location Creation**:
   - Creates external locations for landing, bronze, and silver schemas using SQL queries.

4. **Schema and Volume Creation**:
   - Creates schemas and external volumes for landing, bronze, and silver layers using SQL queries.

5. **Delta Table Configuration**:
   - Uses the `configsbuilder` class to automatically configure Delta tables based on the retrieved configurations.

---

## table_folder_creation.py

### Overview

The `table_folder_creation.py` script defines a `configsbuilder` class that builds and manages configurations for a data pipeline in Databricks. It handles folder creation, Delta table creation, and schema management.

### Methods:
- **`__init__`**: Initializes the class with configuration data and a Spark session. Sets up various paths and configurations.
- **`get_dbutils`**: Retrieves the `dbutils` object for file system operations.
- **`fn_get_schema_good`**: Constructs a schema string from a list of column definitions for good data.
- **`fn_get_schema_bad`**: Constructs a schema string from a list of column definitions for bad data.
- **`checkfolderexists`**: Checks if a folder exists in the Databricks file system.
- **`create_folder`**: Creates a folder in the Databricks file system.
- **`create_deltatable`**: Creates Delta tables for good and bad data in the specified database with the given schema.
- **`autoconfigsbuilder`**: Calls the method to create the Delta tables.

---

## usergroup_access_API.py

### Overview

The `usergroup_access_API.py` script automates the process of creating user groups and adding users to those groups in Databricks using the Databricks REST API.

### Steps:
1. **Widgets for Input**:
   - Retrieves the `group_name` and `username` from Databricks widgets.

2. **Define API Details**:
   - Imports necessary modules.
   - Defines the Databricks workspace URL for groups and users.
   - Defines the Databricks API token.
   - Splits the username string into a list of usernames.
   - Defines headers with the API token.

3. **Check and Create Group**:
   - Checks if the group exists by making a GET request to the groups API.
   - If the group does not exist, creates the group by making a POST request to the groups API.

4. **Add Users to Group**:
   - Iterates over the list of usernames.
   - Checks if each user exists by making a GET request to the users API.
   - If the user exists, adds the user to the group by making a PATCH request to the groups API.
