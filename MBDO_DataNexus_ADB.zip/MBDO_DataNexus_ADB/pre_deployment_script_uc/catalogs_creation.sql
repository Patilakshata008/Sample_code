-- Databricks notebook source
-- MAGIC %python
-- MAGIC #External location creation
-- MAGIC landing_exlocname='eda_landing'
-- MAGIC landing_path='abfss://landing@fofstrprdeusdata.dfs.core.windows.net/catalog'
-- MAGIC full_qry=f"CREATE EXTERNAL LOCATION if not EXISTS {landing_exlocname} URL '{landing_path}' WITH (STORAGE CREDENTIAL accessconnector_eda)"   
-- MAGIC #bronze
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)
-- MAGIC bronze_exlocname='eda_bronze'
-- MAGIC bronze_path='abfss://bronze@fofstrprdeusdata.dfs.core.windows.net/catalog'
-- MAGIC full_qry=f"CREATE EXTERNAL LOCATION if not EXISTS {bronze_exlocname} URL '{bronze_path}' WITH (STORAGE CREDENTIAL accessconnector_eda)"   
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)  
-- MAGIC #silver
-- MAGIC silver_exlocname='eda_silver'
-- MAGIC silver_path='abfss://silver@fofstrprdeusdata.dfs.core.windows.net/catalog'
-- MAGIC full_qry=f"CREATE EXTERNAL LOCATION if not EXISTS {silver_exlocname} URL '{silver_path}' WITH (STORAGE CREDENTIAL accessconnector_eda)"   
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)    
-- MAGIC #gold
-- MAGIC gold_exlocname='eda_gold'
-- MAGIC gold_path='abfss://gold@fofstrprdeusdata.dfs.core.windows.net/catalog'
-- MAGIC full_qry=f"CREATE EXTERNAL LOCATION if not EXISTS {gold_exlocname} URL '{gold_path}' WITH (STORAGE CREDENTIAL accessconnector_eda)"   
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)    

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #landing catalog
-- MAGIC landing_path = 'abfss://landing@mbdodlsdevgwc001.dfs.core.windows.net'
-- MAGIC full_qry=f"CREATE CATALOG IF NOT EXISTS landing MANAGED LOCATION '{landing_path}'"   
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)
-- MAGIC #bronze
-- MAGIC full_qry=f"CREATE CATALOG IF NOT EXISTS bronze MANAGED LOCATION '{bronze_path}'"   
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)  
-- MAGIC #silver
-- MAGIC full_qry=f"CREATE CATALOG IF NOT EXISTS silver MANAGED LOCATION '{silver_path}'"    
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)       
-- MAGIC full_qry=f"CREATE CATALOG IF NOT EXISTS gold MANAGED LOCATION '{gold_path}'"    
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)   

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #landing catalog
-- MAGIC landing_path = 'abfss://landing@mbdodlsdevgwc001.dfs.core.windows.net'
-- MAGIC full_qry=f"CREATE CATALOG IF NOT EXISTS landing MANAGED LOCATION '{landing_path}'"   
-- MAGIC print(full_qry)
-- MAGIC spark.sql(full_qry)

-- COMMAND ----------

