class Dbconfigreaders:
    """This is the class to retrieve the database configurations."""

    def __init__(self, dbcon, fnt_id):
        """
        Initializes the Dbconfigreaders instance with a database connection and file template ID.

        Args:
            dbcon: A database connection object.
            fnt_id (int): The file template ID used in stored procedures and queries.
        """
        self.con = dbcon
        self.fnt_id = fnt_id

    def fn_get_schema(self):
        """
        Fetches schema details for the given file template ID by executing a stored procedure.

        The method retrieves information about column names, data types, constraints, and other metadata.

        Returns:
            list[dict]: A list of dictionaries, each containing schema details such as:
                - 'Expected_Columnname'
                - 'Expected_Datatype'
                - 'Expected_Length'
                - 'Expected_Precision'
                - 'Expected_Unit'
                - 'Expected_Type'
                - 'Expected_Scale'
                - 'Is_Nullable'
                - 'Is_Unique'
                - 'operation'
                - 'Query'
                - 'Is_Mandatory_Column'
                - 'Expected_DatetimeFormat'
                - 'Expected_Regex'
                - 'Expected_startvalue'
                - 'Expected_endvalue'
        """
        statement = f"""EXEC dbo.sp_get_schema_details  @fnt_id='{self.fnt_id}'"""
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        results = []
        while resultSet.next():
            vals = {}
            vals["Expected_Columnname"] = resultSet.getString("Expected_Columnname")
            vals["Expected_Datatype"] = resultSet.getString("Expected_Datatype")
            vals["Expected_Length"] = resultSet.getString("Expected_Length")
            vals["Expected_Precision"] = resultSet.getInt("Expected_Precision")
            vals["Expected_Unit"] = resultSet.getString("Expected_Unit")
            vals["Expected_Type"] = resultSet.getString("Expected_Type")
            vals["Expected_Scale"] = resultSet.getInt("Expected_Scale")
            vals["Is_Nullable"] = resultSet.getString("Is_Nullable")
            vals["Is_Unique"] = resultSet.getString("Is_Unique")
            vals["operation"] = resultSet.getString("operation")
            vals["Query"] = resultSet.getString("Query")
            vals["Is_Mandatory_Column"] = resultSet.getString("Is_Mandatory_Column")
            vals["Expected_DatetimeFormat"] = resultSet.getString(
                "Expected_DatetimeFormat"
            )
            vals["Expected_Regex"] = resultSet.getString("Expected_Regex")
            vals["Expected_startvalue"] = resultSet.getString("Expected_startvalue")
            vals["Expected_endvalue"] = resultSet.getString("Expected_endvalue")

            results.append(vals)
        exec_statement.close()
        return results

    def fn_get_deltaLake_configs(self):
        """
        Fetches Delta Lake configuration details for the given file template ID.

        Executes a stored procedure to retrieve details like database name, table name, key columns,
        partition columns, and other metadata.

        Returns:
            dict: A dictionary containing Delta Lake configuration details such as:
                - 'DbName'
                - 'TabelName'
                - 'KeyColumns'
                - 'PartitionColumns'
                - 'WaterMarkColumns'
                - 'DbLoadType'
                - 'SCD_Column'
        """
        statement = (
            f"""EXEC dbo.[sp_get_DeltaTable_configs_new] @fnt_id={self.fnt_id}"""
        )
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        while resultSet.next():
            vals = {}
            vals["DbName"] = resultSet.getString("DbName")
            vals["TabelName"] = resultSet.getString("TabelName")
            vals["KeyColumns"] = resultSet.getString("KeyColumns")
            vals["PartitionColumns"] = resultSet.getString("PartitionColumns")
            vals["WaterMarkColumns"] = resultSet.getString("WaterMarkColumns")
            vals["DbLoadType"] = resultSet.getString("DbLoadType")
            vals["SCD_Column"] = resultSet.getString("SCD_Column")
            # Close connections
        exec_statement.close()
        return vals

    def fn_get_db_tb_ss_fnt(self):
        """
        Fetches database and table mappings for the given file template ID.

        Executes a SQL query to retrieve mappings between source systems, filename templates, and 
        database-table combinations.

        Returns:
            dict: A dictionary containing database and table mapping details such as:
                - 'Sourcesystem_name'
                - 'Filename_Template'
                - 'dbname': Prefixed with "silver."
                - 'tablename'
        """
        statement = f"""select Sourcesystem_name,Filename_Template,DatalakeDbName as dbname,FNT_Delta_Lake_table_Name as tablename from [dbo].[T_Meta_File_Standard_Schema] inner join [dbo].[T_META_Source_Systems] on FK_sourcesytem_id= PK_Sourcesystem_id where FNT_Id={self.fnt_id}"""
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        while resultSet.next():
            vals = {}
            vals["Sourcesystem_name"] = resultSet.getString("Sourcesystem_name")
            vals["Filename_Template"] = resultSet.getString("Filename_Template")
            vals["dbname"] = "mbdo_silver_dev." + resultSet.getString("dbname")
            vals["tablename"] = resultSet.getString("tablename")

            # Close connections
        exec_statement.close()
        return vals

    def getall_configs(self):
        """
        Fetches all configurations, including schema details, Delta Lake configurations,
        and database-table mappings.

        Returns:
            dict: A dictionary containing:
                - 'schema': Schema details.
                - 'deltalake_configs': Delta Lake configuration details.
                - 'allconfigs': Database and table mapping details.
        """
        config_dict = {}
        columnnames = []
        print(columnnames)
        fileschema = self.fn_get_schema()
        filedelta = self.fn_get_deltaLake_configs()
        allconfigs = self.fn_get_db_tb_ss_fnt()
        config_dict["schema"] = fileschema
        config_dict["deltalake_configs"] = filedelta
        config_dict["allconfigs"] = allconfigs
        return config_dict
