# Databricks notebook source
# imports
from db_configreader import Dbconfigreaders
from common_func.f_database_connect import DBconnection
from table_folder_creation import configsbuilder
from pyspark.sql import SparkSession
FNT_ID = 15
storage_account = "mbdodlsdevgwc001"

storage_account_key = dbutils.secrets.get(scope="datanexus-dev-scope", key="storage-account-key")  

# COMMAND ----------

# Build spark session
spark = SparkSession.builder.appName("integrity-tests").getOrCreate()
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
server = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-ServerName")  
database = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-DBName") 

# Get configurations
source_dl_layer = "Bronze"
dest_dl_layer = "Silver"
dbasecon = DBconnection(database=database, server=server, spark1=spark)
con = dbasecon.fn_get_connection()
configreader = Dbconfigreaders(con, FNT_ID)
config_dict = configreader.getall_configs()
schema1 = config_dict["schema"]
Sourcesystem = config_dict["allconfigs"]["Sourcesystem_name"]
FileTemplate = config_dict["allconfigs"]["Filename_Template"]
dbname = config_dict["allconfigs"]["dbname"]
print("dbname--->", dbname)
print("SourceSystem--->",Sourcesystem)
print("FileTemplate---",FileTemplate)
print(config_dict)

# COMMAND ----------

# Set configurations
"""
spark.conf.set(
    "fs.azure.account.key.fofstrprdeusdata.dfs.core.windows.net",
    "uFMlAoFfhS8ljTMXrIxFa76QXotavNGoy89xfkYgck5ob7M5NHkpJUpFGjiFzEDCOxQmZyA96JDW+ASthlLHEA==")
dbutils.fs.mkdirs("abfss://landing@fofstrprdeusdata.dfs.core.windows.net/AA1")
"""

# COMMAND ----------

# %sql
# CREATE CREDENTIAL accessconnector_eda
# WITH AZURE_SERVICE_PRINCIPAL (
#     CLIENT_ID '36be5a9e-5de5-44f9-99d2-82d57090c21a',
#     SECRET 'o0F8Q~m4Pm1nPN_zxlldkePNxfWngFXtytGTgaky',
#     TENANT_ID '0ae51e19-07c8-4e4b-bb6d-648ee58410f4'
# )
# COMMENT 'Credential for Azure Service Principal access';

# COMMAND ----------

# Get schema and volumes of landing, bronze and silver

landing_schema = (
    f"abfss://landing@{storage_account}.dfs.core.windows.net/" + Sourcesystem
)
landing_vol = landing_schema + "/IN" 
print(landing_vol)

bronze_schema = f"abfss://bronze@{storage_account}.dfs.core.windows.net/" + Sourcesystem
bronze_vol = bronze_schema + "/Raw"
print(bronze_schema)
silver_schema = f"abfss://silver@{storage_account}.dfs.core.windows.net/" + Sourcesystem
print(silver_schema)


# COMMAND ----------

# bronze_schema = f"abfss://bronze@{storage_account}.dfs.core.windows.net/" + "reference_table"
# bronze_vol = bronze_schema + "/Raw"
# print(bronze_schema)

# COMMAND ----------

# # Testing - Landing Volume creation
# landing_path = landing_schema #f"fs.azure.account.key.{storage_account}.dfs.core.windows.net" + Sourcesystem

# # full_qry = f"CREATE EXTERNAL VOLUME IF NOT EXISTS  mbdo_landing_dev.{Sourcesystem}.IN   LOCATION '{landing_path}/IN';"

# full_qry = "CREATE EXTERNAL VOLUME IF NOT EXISTS  mbdo_landing_dev.Test_quotationpdf.IN   LOCATION 'abfss://landing@mbdodlsdevgwc001.dfs.core.windows.net/Test_quotationpdf/IN';"

# print(full_qry)
# spark.sql(full_qry)

# COMMAND ----------

# Set configurations and mount the volumes
spark.conf.set(
    f"fs.azure.account.key.{storage_account}.dfs.core.windows.net", storage_account_key
)
try:
    if not dbutils.fs.ls(landing_schema):  # noqa: F821
        print("schema exists")
except Exception as e:
    print(e)
    dbutils.fs.mkdirs(landing_vol)  # noqa: F821
    # print(dbutils.fs.mkdirs(landing_vol))
try:
    if not dbutils.fs.ls(bronze_schema):  # noqa: F821
        print("schema exists")
except Exception as e:
    print(e)
    dbutils.fs.mkdirs(bronze_vol)  # noqa: F821
try:
    if not dbutils.fs.ls(silver_schema):  # noqa: F821
        print("schema exists")
except Exception as e:
    print(e)
    dbutils.fs.mkdirs(silver_schema)  # noqa: F821


# COMMAND ----------

# # External location creation
# landing_exlocname = "landing_" + Sourcesystem
# landing_path = "abfss://landing@mbdodlsdevgwc001.dfs.core.windows.net/" + Sourcesystem
# full_qry = f"CREATE EXTERNAL LOCATION if not EXISTS {landing_exlocname} URL '{landing_path}' WITH (STORAGE CREDENTIAL datalineageconnector)"
# print(full_qry)
# spark.sql(full_qry)
# bronze_exlocname = "bronze_" + Sourcesystem
# bronze_path = "abfss://bronze@mbdodlsdevgwc001.dfs.core.windows.net/" + Sourcesystem
# full_qry = f"CREATE EXTERNAL LOCATION if not EXISTS {bronze_exlocname} URL '{bronze_path}' WITH (STORAGE CREDENTIAL datalineageconnector)"
# print(full_qry)
# spark.sql(full_qry)
# silver_exlocname = "silver_" + Sourcesystem
# silver_path = "abfss://silver@mbdodlsdevgwc001.dfs.core.windows.net/" + Sourcesystem
# full_qry = f"CREATE EXTERNAL LOCATION if not EXISTS {silver_exlocname} URL '{silver_path}' WITH (STORAGE CREDENTIAL datalineageconnector)"
# print(full_qry)
# spark.sql(full_qry)

# COMMAND ----------

landing_path = "abfss://landing@mbdodlsdevgwc001.dfs.core.windows.net/" + Sourcesystem
bronze_path = "abfss://bronze@mbdodlsdevgwc001.dfs.core.windows.net/" + Sourcesystem
silver_path = "abfss://silver@mbdodlsdevgwc001.dfs.core.windows.net/" + Sourcesystem

# COMMAND ----------

# # External location creation
# landing_exlocname = "landing_" + Sourcesystem 
# landing_path = "abfss://landing@fofstrprdeusdata.dfs.core.windows.net/" + Sourcesystem
# full_qry = f"CREATE EXTERNAL LOCATION if not EXISTS {landing_exlocname} URL '{landing_path}' WITH (STORAGE CREDENTIAL accessconnector_eda)"
# print(full_qry)
# spark.sql(full_qry)
# bronze_exlocname = "bronze_" + Sourcesystem
# bronze_path = "abfss://bronze@fofstrprdeusdata.dfs.core.windows.net/" + Sourcesystem
# full_qry = f"CREATE EXTERNAL LOCATION if not EXISTS {bronze_exlocname} URL '{bronze_path}' WITH (STORAGE CREDENTIAL accessconnector_eda)"
# print(full_qry)
# spark.sql(full_qry)
# silver_exlocname = "silver_" + Sourcesystem
# silver_path = "abfss://silver@fofstrprdeusdata.dfs.core.windows.net/" + Sourcesystem
# full_qry = f"CREATE EXTERNAL LOCATION if not EXISTS {silver_exlocname} URL '{silver_path}' WITH (STORAGE CREDENTIAL accessconnector_eda)"
# print(full_qry)
# spark.sql(full_qry)

# COMMAND ----------

# Create schema for landing, bronze and silver
full_qry = f"CREATE SCHEMA  IF NOT EXISTS  mbdo_landing_dev.{Sourcesystem} MANAGED  LOCATION '{landing_path}';"
print(full_qry)
spark.sql(full_qry)
full_qry = f"CREATE EXTERNAL VOLUME IF NOT EXISTS  mbdo_landing_dev.{Sourcesystem}.IN   LOCATION '{landing_path}/IN';"
print(full_qry)
spark.sql(full_qry)
# bronze
full_qry = f"CREATE SCHEMA  IF NOT EXISTS  mbdo_bronze_dev.{Sourcesystem} MANAGED  LOCATION '{bronze_path}';"
print(full_qry)
spark.sql(full_qry)
full_qry = f"CREATE EXTERNAL VOLUME IF NOT EXISTS  mbdo_bronze_dev.{Sourcesystem}.Raw   LOCATION '{bronze_path}/Raw';"
print(full_qry)
spark.sql(full_qry)
#silver
full_qry = f"CREATE SCHEMA  IF NOT EXISTS  {dbname} MANAGED  LOCATION '{silver_path}';"
print(full_qry)
spark.sql(full_qry)

# COMMAND ----------

# %sql
# create Volume if not exists `mbdo_bronze_dev`.`quantity_consolidation`.`Cache` 

# COMMAND ----------

delt = configsbuilder(config_dict, spark)
delt.autoconfigsbuilder()

# COMMAND ----------

# MAGIC %md
# MAGIC --landing
# MAGIC USE CATALOG landing;
# MAGIC CREATE SCHEMA  IF NOT EXISTS  Sourcesystem MANAGED  LOCATION landing_schema;
# MAGIC use schema Sourcesystem;
# MAGIC CREATE EXTERNAL VOLUME IF NOT EXISTS  IN   LOCATION landing_schema+'/IN';

# COMMAND ----------

# MAGIC %md
# MAGIC --landing
# MAGIC CREATE EXTERNAL LOCATION if not EXISTS SAP
# MAGIC URL 'abfss://bronze@fofstrprdeusdata.dfs.core.windows.net/sap'
# MAGIC WITH (STORAGE CREDENTIAL accessconnector_eda);

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC create table if not exists ${da.db_name}.challenge
# MAGIC (id INT,name STRING ,email string,phone string )
# MAGIC comment "to do activity"
# MAGIC --location "${da.paths.working_dir}/challenge"
# MAGIC TBLPROPERTIES ('contains_pii'= false)

# COMMAND ----------

# MAGIC %md
# MAGIC --bronze
# MAGIC CREATE EXTERNAL LOCATION if not EXISTS 'bronze_' || Sourcesystem
# MAGIC URL landing_schema
# MAGIC WITH (STORAGE CREDENTIAL accessconnector_eda);
# MAGIC --silver
# MAGIC CREATE EXTERNAL LOCATION if not EXISTS 'silver_' || Sourcesystem
# MAGIC URL landing_schema
# MAGIC WITH (STORAGE CREDENTIAL accessconnector_eda);

# COMMAND ----------

# MAGIC %md
# MAGIC --landing
# MAGIC USE CATALOG landing;
# MAGIC CREATE SCHEMA  IF NOT EXISTS  Sourcesystem MANAGED  LOCATION landing_schema;
# MAGIC use schema Sourcesystem;
# MAGIC CREATE EXTERNAL VOLUME IF NOT EXISTS  IN   LOCATION landing_schema+'/IN';

# COMMAND ----------

# MAGIC %md
# MAGIC --bronze
# MAGIC USE CATALOG bronze;
# MAGIC CREATE SCHEMA  IF NOT EXISTS  Sourcesystem MANAGED  LOCATION bronze_schema;
# MAGIC use schema Sourcesystem;
# MAGIC CREATE EXTERNAL VOLUME IF NOT EXISTS  IN   LOCATION bronze_schema+'/Raw';

# COMMAND ----------

# MAGIC %md
# MAGIC --bronze
# MAGIC USE CATALOG silver;
# MAGIC CREATE SCHEMA  IF NOT EXISTS  Sourcesystem MANAGED  LOCATION silver_schema;

# COMMAND ----------

# MAGIC %md
# MAGIC spark.sql("""
# MAGIC           CREATE EXTERNAL LOCATION IF NOT EXISTS SAP
# MAGIC           URL 'abfss://bronze@fofstrprdeusdata.dfs.core.windows.net/sap'
# MAGIC           WITH (STORAGE CREDENTIAL = 'accessconnector_eda')
# MAGIC           """)

# COMMAND ----------

# MAGIC %md
# MAGIC --landing
# MAGIC CREATE EXTERNAL LOCATION if not EXISTS SAP
# MAGIC URL 'abfss://bronze@fofstrprdeusdata.dfs.core.windows.net/sap'
# MAGIC WITH (STORAGE CREDENTIAL accessconnector_eda);

# COMMAND ----------

# MAGIC %md
# MAGIC delt=configsbuilder(config_dict,spark1)
# MAGIC delt.autoconfigsbuilder()

# COMMAND ----------

# MAGIC %md
# MAGIC USE CATALOG bronze;
# MAGIC CREATE SCHEMA   IF NOT EXISTS  sap1 MANAGED  LOCATION 'abfss://bronze@fofstrprdeusdata.dfs.core.windows.net/sap';

# COMMAND ----------

# MAGIC %md
# MAGIC USE CATALOG bronze;
# MAGIC use schema sap1;
# MAGIC CREATE EXTERNAL VOLUME IF NOT EXISTS  vol1   LOCATION 'abfss://bronze@fofstrprdeusdata.dfs.core.windows.net/sap/vol1';

# COMMAND ----------

# MAGIC %md
# MAGIC FNT_ID='264'

# COMMAND ----------

# MAGIC %md
# MAGIC from db_configreader import *
# MAGIC from common_func.databaseconnect import *
# MAGIC from table_folder_creation import *