# Databricks notebook source
# MAGIC %md Final Syntax for cluster log and termination information

# COMMAND ----------

# Get groupname and username
group_name = dbutils.widgets.get("group_name")
username = dbutils.widgets.get("username")

# COMMAND ----------

# MAGIC %md
# MAGIC Syntax for creating usergroups and add users

# COMMAND ----------

# imports
import requests
import json

# Define your Databricks workspace URL
url_group = "https://adb-615732812296608.8.azuredatabricks.net/api/2.0/preview/scim/v2/Groups"
url_user = "https://adb-615732812296608.8.azuredatabricks.net/api/2.0/preview/scim/v2/Users"

# Define your Databricks API token
token = "dapi8385dd0136e9416d05d10d127b9a17f4-3"

# Define the group details
#group_name = "nav_test"
usernames = username.split(',')  # List of usernames to add

# Define headers with the API token
headers = {
    "Authorization": "Bearer {}".format(token),
    "Content-Type": "application/json"
}

# Check if the group exists
response_group = requests.get(url_group + "?filter=displayName eq '{}'".format(group_name), headers=headers)

if response_group.status_code == 200:
    group_data = response_group.json() 
    if "Resources" in group_data:
        group_exists = True
        group_id = group_data["Resources"][0]["id"]
    else:
        group_exists = False
else:
    group_exists = False

if not group_exists:
    # Create the group if it doesn't exist
    payload_group = {
        "schemas": [
            "urn:ietf:params:scim:schemas:core:2.0:Group"
        ],
        "displayName": group_name
    }

    response_create_group = requests.post(url_group, headers=headers, data=json.dumps(payload_group))
    if response_create_group.status_code == 201:
        group_data = response_create_group.json()
        if "id" in group_data:
            print("Group '{}' created successfully.".format(group_name))
            group_id = group_data["id"]
        else:
            print("Error creating group. Invalid response.")
    else:
        print("Error creating group. Status code:", response_create_group.status_code)
        print("Response:", response_create_group.text)
else:
    print("Group '{}' already exists.".format(group_name))

# Add users to the group
if group_exists or response_create_group.status_code == 201:
    for username in usernames:
        # Check if the user exists
        response_user = requests.get(url_user + "?filter=userName eq '{}'".format(username), headers=headers)

        if response_user.status_code == 200:
            user_data = response_user.json()
            if "Resources" in user_data:
                user_exists = True
                user_id = user_data["Resources"][0]["id"]
            else:
                user_exists = False
                print("User '{}' does not exist.".format(username))
        else:
            user_exists = False
            print("Error fetching user. Status code:", response_user.status_code)
            print("Response:", response_user.text)

        if user_exists:
            # Add user to the group
            payload_add_user = {
                "schemas": [
                    "urn:ietf:params:scim:api:messages:2.0:PatchOp"
                ],
                "Operations": [
                    {
                        "op": "add",
                        "path": "members",
                        "value": [
                            {
                                "value": user_id
                            }
                        ]
                    }
                ]
            }

            response_add_user = requests.patch(url_group + "/" + group_id, headers=headers, data=json.dumps(payload_add_user))
            if response_add_user.status_code == 200:
                print("User '{}' added to group '{}'.".format(username, group_name))
            else:
                print("Error adding user to group. Status code:", response_add_user.status_code)
                print("Response:", response_add_user.text)

# COMMAND ----------

