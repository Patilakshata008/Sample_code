

class configsbuilder:
    """This is the class to retrieve the database table schemas."""

    def __init__(self, config_dict, spark):
        """
        Initializes the configsbuilder instance.

        Args:
            config_dict (dict): Configuration dictionary containing schema and other metadata.
            spark (SparkSession): Active Spark session instance.
        """
        self.config = config_dict
        self.schema1 = self.config["schema"]
        self.SourceSystem = self.config["allconfigs"]["Sourcesystem_name"]
        self.FileTemplate = self.config["allconfigs"]["Filename_Template"]
        self.dbname = self.config["allconfigs"]["dbname"]
        self.tablename = self.config["allconfigs"]["tablename"]
        self.path = "dbfs:/mnt/landing/" + self.SourceSystem + "/IN"
        self.bronze_success_path = (
            "dbfs:/mnt/bronze/"
            + self.SourceSystem
            + "/Raw/Success/IN/"
            + self.FileTemplate
        )
        self.bronze_error_path = (
            "dbfs:/mnt/bronze/"
            + self.SourceSystem
            + "/Raw/Error/IN/"
            + self.FileTemplate
        )
        self.bronze_cache_path = "dbfs:/mnt/bronze/" + self.SourceSystem + "/Cache/IN"
        self.silver_error_path = (
            "dbfs:/mnt/silver/" + self.SourceSystem + "/Error/IN/" + self.FileTemplate
        )
        self.spark = spark
        self.dbutils = self.get_dbutils()
        self.lis = [
            self.path,
            self.bronze_success_path,
            self.bronze_error_path,
            self.bronze_cache_path,
            self.silver_error_path,
        ]

    def get_dbutils(self):
        """
        Retrieves the DBUtils instance.

        Returns:
            DBUtils: A DBUtils object for interacting with Databricks filesystem and other utilities.
        """
        try:
            from pyspark.dbutils import DBUtils

            dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython

            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils

    def fn_get_schema_good(self, columns):
        """
        Constructs a schema definition for valid data based on column configurations.

        Args:
            columns (list): List of dictionaries representing column configurations.

        Returns:
            str: Schema string for valid data.
        """
        schema = ""
        for i in range(len(columns)):
            if len(columns) == 1 or i == len(columns) - 1:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                )
            else:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                    + ","
                )

        return schema

    def fn_get_schema_bad(self, columns):
        """
        Constructs a schema definition for invalid data using 'string' datatype for all columns.

        Args:
            columns (list): List of dictionaries representing column configurations.

        Returns:
            str: Schema string for invalid data.
        """
        schema = ""
        for i in range(len(columns)):
            if len(columns) == 1 or i == len(columns) - 1:
                schema += columns[i]["Expected_Columnname"] + " " + "string"
            else:
                schema += columns[i]["Expected_Columnname"] + " " + "string" + ","

        return schema

    def checkfolderexists(self, path1):
        """
        Checks if a folder exists at the given path.

        Args:
            path1 (str): Path to check.

        Returns:
            bool: True if the folder exists, False otherwise.
        """
        self.path2 = path1
        try:
            if dbutils.fs.ls(self.path2): 
                return True
        except Exception as err:
            if "java.io.FileNotFoundException" in str(err):
                return False

    def create_folder(self, path1):
        """
        Creates a folder at the specified path.

        Args:
            path1 (str): Path where the folder should be created.
        """
        self.path2 = path1
        self.dbutils.fs.mkdirs(self.path2)
        print("source folder created " + self.path2)

    def create_deltatable(self):
        """
        Creates Delta tables for valid and invalid data based on the provided schema
        and configuration.
        """
        print(self.dbname)
        self.table_schema_good = self.fn_get_schema_good(self.schema1)
        self.table_schema_bad = self.fn_get_schema_bad(self.schema1)
        self.table_schema_good += (
            ",start_date timestamp,end_date timestamp, current_status int,processed_time timestamp,unq_id string"
        )
        self.table_schema_bad += (
            ",Source_file string,tracking_id string,column_success string, id string,processed_time timestamp,unq_id string"
        )

        print('table_schema_good is ',self.table_schema_good)
        query_good = f"CREATE TABLE if not exists {self.dbname}.{self.tablename}({self.table_schema_good}) TBLPROPERTIES ('delta.columnMapping.mode' = 'name') location 'abfss://silver@mbdodlsdevgwc001.dfs.core.windows.net/{self.SourceSystem}/Success/IN/{self.FileTemplate}'"
        print("complete qry_good is", query_good)
        self.spark.sql(query_good)

        print("delta table good created")
        query_bad = f"CREATE TABLE if not exists {self.dbname}.{self.tablename}_baddfdata({self.table_schema_bad}) TBLPROPERTIES ('delta.columnMapping.mode' = 'name') location 'abfss://silver@mbdodlsdevgwc001.dfs.core.windows.net/{self.SourceSystem}/Error/IN/{self.FileTemplate}'"
        print("complete qry_bad is", query_bad)
        self.spark.sql(query_bad)
        print("delta table bad created")

    def autoconfigsbuilder(self):
        """
        Automates the setup process by creating required folders and Delta tables.
        """
        self.create_deltatable()
