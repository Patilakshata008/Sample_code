# Table of Contents

## access_control

- [group_creator.py](#group_creatorpy)
- [tag_check.py](#tag_checkpy)
- [monitor_access.py](#monitor_accesspy)
- [table_access_control_executor.py](#table_access_control_executorpy)
- [rls_cls_access_control_sql_executor.py](#rls_cls_access_control_sql_executorpy)
- [access_control_sql_functions_backup.py](#access_control_sql_functions_backuppy)
- [admin_config_and_demo.sql](#admin_config_and_demosql)
- [dynamic_views.py](#dynamic_viewspy)
- [dynamic_access_control_script.py](#dynamic_access_control_scriptpy)
- [dynamic_access_control_script_backup.py](#dynamic_access_control_script_backuppy)
- [exploration.sql](#explorationsql)
- [lineage.py](#lineagepy)
- [reset_script.sql](#reset_scriptsql)
- [table_scripts.sql](#table_scriptsql)

## API to Landing

- [f_accessory_functions.py](#f_accessory_functionspy)
- [f_API_configs.py](#f_API_configspy)
- [f_authentication.py](#f_authenticationpy)
- [f_authentication_dictionary.py](#f_authenticationdictionarypy)
- [f_no_pagination.py](#f_nopaginationpy)
- [f_offset_pagination.py](#f_offsetpaginationpy)
- [f_page_pagination.py](#f_pagepaginationpy)
- [f_refresh_token.py](#f_refreshtokenpy)
- [nb_API.ipynb](#nb_apiipynb)
- [nb_API_source.py](#nb_api_sourcepy)
- [nb_get_token.py](#nb_gettokenpypy)

## Common Functions

- [f_database_connect.py](#f_databaseconnectpy)
- [f_logs.py](#f_logspy)

## DB to Landing

- [f_configs.py](#f_configspy)
- [f_dbcon.py](#f_dbconpy)
- [f_metadata_configs_updated.py](#f_metadata_configs_updatedpy)
- [f_metadata_functions.py](#f_metadata_functionspy)
- [f_mv_db_to_land_updated.py](#f_mv_db_to_land_updatedpy)
- [nb_azuredb_v1.py](#nb_azuredb_v10py)
- [nb_db_to_landing.py](#nb_db_to_landingpy)
- [nb_source_database.py](#nb_sourcedatabsepy)

## DQF Validation

- [f_attribute_validator4.py](#f_attributevalidator4py)
- [f_csvtxt_reader.py](#f_csvtxtreaderpy)
- [f_data_masking.py](#f_datamaskingpy)
- [f_data_unmasking.py](#f_dataunmaskingpy)
- [f_db_configreader.py](#f_dbconfigreaderpy)
- [f_db_reader.py](#f_dbreaderpy)
- [f_db_writers.py](#f_dbwriterspy)
- [f_delta_table_load.py](#f_delta_table_loadpy)
- [f_extract_channels.py](#f_extract_channelspy)
- [f_file_reader.py](#f_filereaderpy)
- [f_file_reader2.py](#f_filereader2py)
- [f_json_reader.py](#f_jsonreaderpy)
- [f_json_2reader.py](#f_json_2readerpy)
- [f_move_files.py](#f_movefilespy)
- [f_parquet_reader.py](#f_parquetreaderpy)
- [f_utility_functions.py](#f_utilityfunctionspy)
- [f_xml_reader.py](#f_xmlreaderpy)
- [nb_dqf_validator.ipynb](#nb_dqf_validatoripynb)

## File Validation

- [__init__.py](#__init__py)
- [f_attribute_retriever.py](#f_attributeretrieverpy)
- [f_attribute_validator.py](#f_attributevalidatorpy)
- [f_db_reader.py](#f_dbreaderpy)
- [f_log_files.py](#f_logfilespy)
- [f_retrieve_listofattributes.py](#f_retrivelistofattributespy)
- [f_retrieve_listoffiles.py](#f_retrivelistoffilespy)
- [f_utility_functions.py](#f_utilityfunctionspy)
- [get_sparkutils.py](#getsparkutilspy)
- [nb_file_validation.py](#nb_filevalidationpy)
- [use_sparkutils.py](#usesparkutilspy)

## Housekeeping Jobs

- [maintaince_configs.py](#maintaince_configspy)
- [vacuum.py](#vacuumpy)
- [zorder.py](#zorderpy)

## Pre-Deployment Script

- [auto_configs.py](#auto_configspy)
- [auto_create_delta_table.py](#auto_create_delta_tablepy)
- [db_configreader.py](#dbconfigreaderpy)
- [metadata_configuration.py](#metadata_configurationpy)
- [table_folder_creation.py](#table_folder_creationpy)

## Pre-Deployment Script UC

- [Catalogs_creation.sql](#catalogs_creationsql)
- [db_configreader.py](#dbconfigreaderpy)
- [Main.py](#mainpy)
- [table_folder_creation.py](#table_folder_creationpy)
- [usergroup_access_API.py](#usergroup_access_apipy)

## table_access_control

- [Provide_access_to_User_groups_on_Table,schema,Catalog.sql](#provide_access_to_user_groups_on_table_schemacatalogsql)
- [Providing_RLS_v1.sql](#providing_rls_v1sql)
- [Providing_CLS_v1.sql](#providing_cls_v1sql)
- [reset.py](#resetpy)
