import msal


class azdbconnection:
    """This is the class for database operation functions."""

    def __init__(self, jdbcurl, jdbcUsername, jdbcPassword, jdbcdriver, session, credentialsFile, materializationDataset, parentProject,host,warehouse, database, schema, typeof_db):
        """
        Initialize the azdbconnection with required parameters.

        Args:
            jdbcurl (str): The JDBC connection URL.
            jdbcUsername (str): The JDBC username.
            jdbcPassword (str): The JDBC password.
            jdbcdriver (str): The JDBC driver name.
            session (SparkSession): The Spark session.
            credentialsFile (str): The file containing credentials.
            materializationDataset (str): Dataset name for materialization.
            parentProject (str): The parent project name.
            host (str): The host address for the database.
            warehouse (str): The warehouse name.
            database (str): The database name.
            schema (str): The schema name.
            typeof_db (str): The type of database (e.g., SQL Server, MySQL).
        """
        self.jdbcurl = jdbcurl
        self.username = jdbcUsername
        self.password = jdbcPassword
        self.driver = jdbcdriver
        self.session = session
        self.spark = session
        self.credentialsFile = credentialsFile
        self.materializationDataset = materializationDataset
        self.parentProject = parentProject
        self.typeof_db = typeof_db
        self.host = host
        self.warehouse =warehouse
        self.database =database
        self.schema =schema

    def get_dbutils(self):
        """
        Retrieve dbutils for the Spark session.

        Returns:
            dbutils: A dbutils object for Spark session management.
        """
        try:
            from pyspark.dbutils import DBUtils

            dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython

            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils

    def fn_get_connection(self, scope="fof-prd-scope"):
        """
        Establish a connection to the database using Azure OAuth authentication.

        Args:
            scope (str): The Azure scope for secrets.

        Returns:
            tuple: A tuple containing the connection object and the authentication token.
        """
        # Set url & credentials
        dbutils = self.get_dbutils()
        tenant_id = dbutils.secrets.get(scope="fof-prd-scope", key="EDA-SPN-TenantId")
        sp_client_id = dbutils.secrets.get(
            scope="fof-prd-scope", key="EDA-SPN-ClientId"
        )
        sp_client_secret = dbutils.secrets.get(
            scope="fof-prd-scope", key="EDA-SPN-ClientSecret"
        )

        url = self.jdbcurl

        # Write your SQL statement as a string

        # Generate an OAuth2 access token for service principal
        authority = f"https://login.windows.net/{tenant_id}"
        app = msal.ConfidentialClientApplication(
            sp_client_id, sp_client_secret, authority
        )
        token = app.acquire_token_for_client(
            scopes=["https://database.windows.net/.default"]
        )["access_token"]

        # Create a spark properties object and pass the access token
        properties = self.spark._sc._gateway.jvm.java.util.Properties()
        properties.setProperty("accessToken", token)

        # Fetch the driver manager from your spark context
        driver_manager = self.spark._sc._gateway.jvm.java.sql.DriverManager

        # Create a connection object and pass the properties object
        con = driver_manager.getConnection(url, properties)
        return con, token

    def source_con_string_token(self):
        """
        Retrieve the connection and token for the source database.
        """
        self.con1, self.token = self.fn_get_connection()

    def desdb_con_string(self):
        """
        Retrieve the connection and token for the destination database.
        """
        self.con, self.token = self.fn_get_connection()

    def fn_read_parallel(
        self, sql, numberOfPartitions, partitionColumn, lowerBound, upperBound
    ):
        """
        Read data in parallel from a database table using partitioning.
        
        Args:
            sql (str): The SQL query to execute.
            numberOfPartitions (int): Number of partitions for parallel reads.
            partitionColumn (str): Column to partition data on.
            lowerBound (int/float): Lower bound for partitioning.
            upperBound (int/float): Upper bound for partitioning.
        
        Returns:
            DataFrame: The resulting DataFrame.
        """
        try:
            print(
                "no of partition,lower bound,uppre bound,partition column is",
                numberOfPartitions,
                partitionColumn,
                lowerBound,
                upperBound,
            )
            if self.typeof_db == "mysql" or self.typeof_db == "postgres" or self.typeof_db == "azuresql":
                jdbcDF = (
                    self.session.read.format("jdbc")
                    .option("url", self.jdbcurl)
                    .option("dbtable", sql)
                    .option("user", self.username)
                    .option("password", self.password)
                    .option("driver", self.driver)
                    .option("numPartitions", numberOfPartitions)
                    .option("partitionColumn", f"{partitionColumn}")
                    .option("lowerBound", lowerBound)
                    .option("upperBound", upperBound)
                    .load()
                )
            elif self.typeof_db =="snowflake":
                print('----------------------------------dbcon-----------------snowflake')
                jdbcDF = self.session.read.format("snowflake") \
                    .option("host", self.host) \
                    .option("user", self.username) \
                    .option("password", self.password) \
                    .option("sfWarehouse", self.warehouse) \
                    .option("database", self.database) \
                    .option("schema", self.schema) \
                    .option("query", sql) \
                    .load()
            else:
                jdbcDF = self.session.read.format("bigquery") \
                    .option("credentialsFile",self.credentialsFile) \
                    .option("query", sql) \
                    .option("materializationDataset", self.materializationDataset) \
                    .option("parentProject", self.parentProject) \
                    .option("numPartitions", numberOfPartitions ) \
                    .option("partitionColumn", f"{partitionColumn}" ) \
                    .option("lowerBound", lowerBound)\
                    .option("upperBound", upperBound)\
                    .load()    
            print("partitions in df", jdbcDF.rdd.getNumPartitions())
            return jdbcDF
        except Exception as e:
            print(e)

    def fn_read(self, sql):
        """
        Read data from a database table or execute a query.
        
        Args:
            sql (str): The SQL query to execute.
        
        Returns:
            DataFrame: The resulting DataFrame.
        """
        try:
            if self.typeof_db == "mysql" or self.typeof_db == "postgres" or self.typeof_db == "azuresql":          
                jdbcDF = self.session.read.format("jdbc") \
                    .option("url",self.jdbcurl) \
                    .option("dbtable", sql) \
                    .option("user", self.username) \
                    .option("password", self.password) \
                    .option("driver", self.driver) \
                    .load()
            elif self.typeof_db =="snowflake":
               jdbcDF = self.session.read.format("snowflake") \
                    .option("host", self.host) \
                    .option("user", self.username) \
                    .option("password", self.password) \
                    .option("sfWarehouse", self.warehouse) \
                    .option("database", self.database) \
                    .option("schema", self.schema) \
                    .option("query", sql) \
                    .load()
            else:
                jdbcDF = self.session.read.format("bigquery") \
                    .option("credentialsFile",self.credentialsFile) \
                    .option("query", sql) \
                    .option("materializationDataset", self.materializationDataset) \
                    .option("parentProject", self.parentProject) \
                    .load()
            return jdbcDF
        except Exception as e:
            print(e)

    def fn_read_withSp(self, sql):
        """
        Read data from a database using a stored procedure and OAuth token for authentication.
        
        Args:
            sql (str): The SQL query or stored procedure to execute.
        
        Returns:
            DataFrame: The resulting DataFrame.
        """
        try:
            jdbcDF = (
                self.session.read.format("jdbc")
                .option("url", self.jdbcurl)
                .option("dbtable", sql)
                .option("accessToken", self.token)
                .option("hostNameInCertificate", "*.database.windows.net")
                .option("driver", self.driver)
                .load()
            )
            return jdbcDF
        except Exception as e:
            print(e)

    def fn_write_parallel(
        self, sql, numberOfPartitions, partitionColumn, lowerBound, upperBound, df
    ):
        """
        Write data to a database table in parallel, partitioning the data.
        
        Args:
            sql (str): The name of the database table.
            numberOfPartitions (int): Number of partitions for parallel writing.
            partitionColumn (str): The column to partition the data on.
            lowerBound (int/float): Lower bound for partitioning.
            upperBound (int/float): Upper bound for partitioning.
            df (DataFrame): The DataFrame containing data to be written.
        """
        try:
            print(
                "no of partition,lower bound,uppre bound,partition column is",
                numberOfPartitions,
                partitionColumn,
                lowerBound,
                upperBound,
            )
            print("jdbc url is ", self.jdbcurl)
            print("tablename is", sql)
            df.repartition(numberOfPartitions).write.mode("overwrite").format(
                "jdbc"
            ).option("url", self.jdbcurl).option("dbtable", sql).option(
                "user", self.username
            ).option(
                "password", self.password
            ).option(
                "driver", self.driver
            ).save()
        except Exception as e:
            print(e)

    def fn_get_paths(self, sourcesystem_name, usecase_name, fnt_id, dllayer, pathtype):
        """
        Execute a stored procedure to retrieve paths from the database.
        
        Args:
            sourcesystem_name (str): The source system name.
            usecase_name (str): The use case name.
            fnt_id (int): The FNT ID.
            dllayer (str): The DLLayer.
            pathtype (str): The type of path to retrieve.
        
        Returns:
            dict: A dictionary containing the path.
        """
        try:
            statement = f"""EXEC dbo.sp_get_Paths  @sourcesystem='{sourcesystem_name}',@usecase='{usecase_name}',@fnt={fnt_id},@dllayer='{dllayer}',@pathtype='{pathtype}'"""
            print(statement)
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            resultSet = exec_statement.getResultSet()
            while resultSet.next():
                vals = {}
                vals["path"] = resultSet.getString("path")

            return vals
            exec_statement.close()
        except Exception as e:
            print(e)

    def fn_update_watermark(self, fnt_id, watermarkvalue):
        """
        Update the watermark value in the database.
        
        Args:
            fnt_id (int): The FNT ID.
            watermarkvalue (str): The watermark value to update.
        
        Returns:
            tuple: A tuple indicating success (True/False) and error message if any.
        """
        try:
            statement = f"""EXEC dbo.sp_update_watermark  @fntid={fnt_id},@watermarkvalue='{watermarkvalue}'"""
            print(statement)
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            exec_statement.close()
            return True, ""
        except Exception as e:
            return False, e

    def fn_update_rowcount(self, fnt_id, job_id, rowcount):
        """
        Update the row count in the database for a specific job.
        
        Args:
            fnt_id (int): The FNT ID.
            job_id (str): The job ID.
            rowcount (int): The number of rows to update.
        
        Returns:
            tuple: A tuple indicating success (True/False) and error message if any.
        """
        try:
            statement = f"""EXEC dbo.sp_update_db_delta_count  @fnt_id={fnt_id},@job_id='{job_id}',@row_count={rowcount}"""
            print(statement)
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            exec_statement.close()
            return True, ""
        except Exception as e:
            return False, e

    def fn_insert_connector_logs(self, FNT_ID, jobId):
        """
        Insert a new log entry for a connector job.
        
        Args:
            FNT_ID (int): The FNT ID.
            jobId (str): The job ID to log.
        
        Returns:
            tuple: A tuple indicating success (True/False) and error message if any.
        """
        try:
            statement = f"""EXEC dbo.sp_insert_connector_logs @fk_fnt_id={FNT_ID},@job_run_id='{jobId}'"""
            print(statement)
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            exec_statement.close()
            return True, ""
        except Exception as e:
            return False, e

    def fn_update_connector_logs(
        self, row_count, job_run_id, lastwatermark_value, final_path
    ):
        """
        Update the connector logs with job details.
        
        Args:
            row_count (int): The row count to log.
            job_run_id (str): The job run ID.
            lastwatermark_value (str): The last watermark value.
            final_path (str): The final file path.
        
        Returns:
            tuple: A tuple indicating success (True/False) and error message if any.
        """
        try:
            statement = f"""EXEC dbo.sp_update_connector_logs_db @row_count={row_count},@job_run_id='{job_run_id}',@lastwatermark_value='{lastwatermark_value}',@filepath='{final_path}'"""
            print(statement)
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            exec_statement.close()
            return True, ""
        except Exception as e:
            return False, e