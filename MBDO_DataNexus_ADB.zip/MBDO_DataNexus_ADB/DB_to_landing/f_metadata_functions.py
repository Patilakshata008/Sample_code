# Databricks notebook source
class waterMarkPreocessor:
    """This is the class for maintaining watermarks and perform delta data load."""

    def __init__(
        self,
        repDbConObj,
        schemaName,
        tableName,
        waterMarkColumns,
        lowWaterMark,
        eolDbConObj,
    ):
        """
        Initialize the waterMarkPreocessor instance.
        
        Args:
            repDbConObj: Replication database connection object.
            schemaName (str): Schema name in the database.
            tableName (str): Table name in the database.
            list_of_wm_columns (list): List of columns for watermark.
            lowWaterMark: Initial watermark value.
            eolDbConObj: End-of-life database connection object.
        """
        self.rep_db_con_obj = repDbConObj
        self.schema_name = schemaName
        self.table_name = tableName
        self.list_of_wm_columns = waterMarkColumns
        self.low_water_mark = lowWaterMark
        self.eol_db_con = eolDbConObj

        pass

    def fn_formQuery(self):
        """
        Generates the query to fetch the maximum watermark values from the specified columns.
        
        Returns:
            str: The SQL query string.
        """
        expr = ",".join(
            [
                f"CONVERT(VARCHAR(30),cast(max({a}) as datetime), 121) as '{a}'"
                for a in self.list_of_wm_columns
            ]
        )
        print(f"max({expr})n")
        sql = f"(select {expr} from {self.schema_name}.{self.table_name}) as qry  "
        print("final sql is", sql)
        return sql

    def fn_get_low_watermark(self):
        '''
        This method is intentionally left empty.
        '''
        pass

    def fn_get_high_watermark(self, sql):
        """
        Fetch the high watermark value from the database.

        Args:
            sql (str): The SQL query to execute for fetching the high watermark.

        Returns:
            data: The result of the query execution, or None if an error occurs.
        """
        data = self.eol_db_con.fn_read(sql)
        return data

    def fn_getcount_full(self):
        """
        Fetch the total row count from the table.

        Returns:
            data: The result of the query execution, or None if an error occurs.
        """
        print("inside")
        sql = f"(select count(1) as cnt from {self.schema_name}.{self.table_name}) as qry  "
        data = self.eol_db_con.fn_read(sql)
        print(sql)
        return data

    def fn_getcount_delta(self, high_wm, low_wm):
        """
        Fetch the delta row count between the given high watermark and low watermark.

        Args:
            high_wm: The high watermark value.
            low_wm: The low watermark value.

        Returns:
            data: The result of the query execution, or None if an error occurs.
        """
        print("inside")
        expr = " or ".join(
            [f"({a}>'{low_wm}' and {a}<='{high_wm}')" for a in self.list_of_wm_columns]
        )
        print(f"max({expr})n")
        sql = f"(select count(1) as cnt from {self.schema_name}.{self.table_name} where {expr}) as qry  "
        data = self.eol_db_con.fn_read(sql)
        print(sql)
        return data

    def fn_form_qry_loadfromdb_full(self, lst_columns):
        """
        Generate a SQL query to fetch columns from the specified table in the given database.

        Args:
            lst_columns: List of column names to be included in the SELECT query.

        Returns:
            sql: The generated SQL query string.
        """
        column_list = ",".join(lst_columns)
        sql = f"(select  {column_list} from {self.schema_name}.{self.table_name} ) as qry  "
        print("sql for fetrching", sql)
        return sql

    def fn_form_qry_loadfromdb_delta(self, high_wm, low_wm, lst_columns):
        """
        Generate a SQL query to load delta data from the specified table based on watermark values.

        Args:
            high_wm: The high watermark value.
            low_wm: The low watermark value.
            lst_columns: List of column names to be included in the SELECT query.

        Returns:
            sql: The generated SQL query string.
        """
        expr = " or ".join(
            [f"({a}>'{low_wm}' and {a}<='{high_wm}')" for a in self.list_of_wm_columns]
        )
        print(f"max({expr})n")
        column_list = ",".join(lst_columns)
        sql = f"(select    {column_list} from {self.schema_name}.{self.table_name} where {expr}) as qry  "
        print("sql for fetrching", sql)
        return sql

    def fn_getColumnMapping(self, processname):
        """
        Retrieve the column mappings for a given process name and table.

        Args:
            processname: The name of the process to retrieve column mappings for.

        Returns:
            data: The result set of the SQL query for column mappings.
        """
        print("table name is", self.table_name)
        sql = f"(select tab.TableName,col.columnname from T_table_configs tab inner join T_table_columns col on tab.TableId=col.TableId  inner join T_process_table_mapping  \
    tptm on tptm.tableId=tab.TableId inner join T_process_list pc on tptm.processId=pc.processId  \
    where tab.TableName='{self.table_name}' and pc.ProcessName='{processname}') as qry"
        data = self.rep_db_con_obj.fn_read(sql)
        return data