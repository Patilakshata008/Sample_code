from f_metadata_configs_updated import waterMarkPreocessor
from pyspark.sql.functions import greatest, col, to_timestamp
from datetime import datetime


class mv_db_to_lan:
    """This is the class for data movement functions from db to landing."""

    def __init__(
        self,
        FNT_ID,
        jobId,
        filtered_data,
        dbcon_obj,
        src_dbcn,
        list_wm_columns,
        columndetails,
        Folderpath,
        typeof_db,
    ):
        """
        Initializes the DataProcessor object with necessary details.

        Args:
            FNT_ID (str): The function ID.
            jobId (str): The job ID.
            filtered_data (dict): The filtered data with necessary parameters.
            dbcon_obj (object): The database connection object for logging.
            src_dbcn (object): The source database connection object.
            list_wm_columns (list): List of watermark columns.
            columndetails (object): Column details for the data processing.
            Folderpath (dict): The folder path for saving processed files.
            typeof_db (str): The type of database (e.g., 'azuresql', 'mysql', etc.).
        """
        self.FNT_ID = FNT_ID
        self.jobId = jobId
        self.filtered_data = filtered_data
        self.dbcon_obj = dbcon_obj
        self.src_dbcn = src_dbcn
        self.list_wm_columns = list_wm_columns
        self.columndetails = columndetails
        self.Folderpath = Folderpath
        self.typeof_db = typeof_db
        print("typeof_db_mv_db_to_land_updated", self.typeof_db)

    def mv_db_to_landing(self):
        """
        Moves data from the source database to the landing zone based on the specified load type.

        The function performs the following steps:
        1. Logs the process start.
        2. Calculates the high watermark value.
        3. Forms and executes queries based on load type (full, merge, or append).
        4. Writes the resulting data to a Parquet file in the landing zone.

        Raises:
            Exception: If any error occurs during data processing.
        """
        try:
            print("typeof_db_mv_db_to_landing_Func", self.typeof_db)
            self.dbcon_obj.fn_insert_connector_logs(self.FNT_ID, self.jobId)
            lowwatermarkvalue = self.filtered_data["LastWaterMarkValue"]
            print("typeof_db_before_wmprcsr", self.typeof_db)
            typeof_db = self.typeof_db
            print(typeof_db)
            wmprcsr = waterMarkPreocessor(
                repDbConObj=self.dbcon_obj,
                schemaName=self.filtered_data["DBschemaname"],
                tableName=self.filtered_data["SourceTableName"],
                waterMarkColumns=self.list_wm_columns,
                lowWaterMark=lowwatermarkvalue,
                eolDbConObj=self.src_dbcn,
                typeof_db=self.typeof_db,
            )
            print("typeof_db_after_wmprcsr", self.typeof_db)
            rowcount = 0

            if self.filtered_data["DbLoadType"] == "full":
                print("DB_lod_Type_", self.filtered_data["DbLoadType"])
                sql = wmprcsr.fn_formQuery()
                print(sql)
                pass
            elif (
                self.filtered_data["DbLoadType"] == "merge"
                or self.filtered_data["DbLoadType"] == "append"
            ):
                sql = wmprcsr.fn_formQuery()
                print(sql)
            print("print line 42 in mv_db_to_land.py")
            data = wmprcsr.fn_get_high_watermark(sql)
            print("passed")
            print("data is", data.show())
            if self.typeof_db == "azuresql":
                if len(data.columns) <= 1:
                    maxdate = data.select(
                        to_timestamp((col(data.columns[0])), "yyyy-MM-dd HH:mm:ss.SSS")
                        .cast("string")
                        .alias("greatest")
                    )
                else:
                    maxdate = data.select(
                        to_timestamp(
                            greatest(*[col(a) for a in data.columns]),
                            "yyyy-MM-dd HH:mm:ss.SSS",
                        )
                        .cast("string")
                        .alias("greatest")
                    )
            elif self.typeof_db == "mysql" or self.typeof_db == "postgres" or self.typeof_db == 'bigquery' or self.typeof_db =="snowflake":
                if len(data.columns) <= 1:
                    maxdate = data.select(
                        to_timestamp((col(data.columns[0])), "yyyy-MM-dd HH:mm:ss")
                        .cast("string")
                        .alias("greatest")
                    )
                else:
                    maxdate = data.select(
                        to_timestamp(
                            greatest(*[col(a) for a in data.columns]),
                            "yyyy-MM-dd HH:mm:ss",
                        )
                        .cast("string")
                        .alias("greatest")
                    )
            print("passed full load here")
            print("maxdate", maxdate.show())
            high_wm = maxdate.rdd.collect()[0][0]
            print("high wm ", high_wm)
            print("lowwatermarkvalue wm ", lowwatermarkvalue)
            column_list = self.columndetails.select("Expected_columnname")
            list_of_columns = [row.Expected_columnname for row in column_list.collect()]
            print(list_of_columns)
            if self.filtered_data["DbLoadType"] == "full":
                print(
                    "self.filtered_data['DbLoadType']", self.filtered_data["DbLoadType"]
                )
                cnt = wmprcsr.fn_getcount_full()
                rowcount = cnt.rdd.collect()[0][0]
                load_sql = wmprcsr.fn_form_qry_loadfromdb_full(
                    list_of_columns, self.filtered_data["Db_column_to_partition_read"]
                )
            elif (
                self.filtered_data["DbLoadType"] == "merge"
                or self.filtered_data["DbLoadType"] == "append"
            ):
                cnt = wmprcsr.fn_getcount_delta(high_wm, lowwatermarkvalue)
                rowcount = cnt.rdd.collect()[0][0]
                load_sql = wmprcsr.fn_form_qry_loadfromdb_delta(
                    high_wm,
                    lowwatermarkvalue,
                    list_of_columns,
                )
            delta_data = self.src_dbcn.fn_read_parallel(
                load_sql,
                self.filtered_data["number_of_partitions_read_from_source"],
                self.filtered_data["Db_column_to_partition_read"],
                0,
                rowcount,
            )
            print("number if partitions is", delta_data.rdd.getNumPartitions())
            now = datetime.now()
            LandingFolder = (
                self.Folderpath["path"] + self.filtered_data["Filename_Template"]

            )
            final_path = f'{LandingFolder}_{now.strftime("%Y_%m_%d_%H_%M_%S")}'
            print(final_path)
            delta_data.write.parquet(final_path)
        except Exception as e:
            print(e)
            error = True
            error_msg = e
        else:
            if (
                self.filtered_data["DbLoadType"] == "merge"
                or self.filtered_data["DbLoadType"] == "append"
            ):
                result = self.dbcon_obj.fn_update_watermark(self.FNT_ID, high_wm)
            error = False
            error_msg = ""
            print(result)
            print(error, error_msg)
        finally:
            print("calling logger", self.FNT_ID, self.jobId)
            self.dbcon_obj.fn_update_connector_logs(
                rowcount, self.jobId, high_wm, final_path
            )
