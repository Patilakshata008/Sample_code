class waterMarkPreocessor:
    """This is the class for maintaining watermarks and perform delta data load."""

    def __init__(
        self,
        repDbConObj,
        schemaName,
        tableName,
        waterMarkColumns,
        lowWaterMark,
        eolDbConObj,
        typeof_db,
    ):
        """
        Initialize the waterMarkPreocessor instance.
        
        Args:
            repDbConObj: Replication database connection object.
            schemaName (str): Schema name in the database.
            tableName (str): Table name in the database.
            waterMarkColumns (list): List of columns for watermark.
            lowWaterMark: Initial watermark value.
            eolDbConObj: End-of-life database connection object.
            typeof_db (str): Type of the database (e.g., 'azuresql', 'mysql', etc.)
        """
        self.rep_db_con_obj = repDbConObj
        self.schema_name = schemaName
        self.table_name = tableName
        self.list_of_wm_columns = waterMarkColumns
        self.low_water_mark = lowWaterMark
        self.eol_db_con = eolDbConObj
        self.typeof_db = typeof_db
        print("typeof_db_metadata_configs_updated", self.typeof_db)
        pass

    def fn_formQuery(self):
        """
        Generates the query to fetch the maximum watermark values from the specified columns.
        
        Returns:
            str: The SQL query string.
        """
        if self.typeof_db == "azuresql":
            expr = ",".join(
                [
                    f"CONVERT(VARCHAR(30),cast(max({a}) as datetime), 121) as '{a}'"
                    for a in self.list_of_wm_columns
                ]
            )
        elif self.typeof_db == "mysql":
            expr = ",".join(
                [
                    f"DATE_FORMAT(MAX({a}), '%Y-%m-%d %H:%i:%s') as '{a}'"
                    for a in self.list_of_wm_columns
                ]
            )
            print("expr", expr)
        elif self.typeof_db == "postgres":
            expr = ",".join(
                [
                    f"TO_CHAR(MAX({a}), 'YYYY-MM-DD HH24:MI:SS') as {a}"
                    for a in self.list_of_wm_columns
                ]
            )
        elif self.typeof_db == "bigquery":
            expr=",".join(
                [
                    f"FORMAT_DATETIME('%Y-%m-%d %H:%M:%S',MAX({a})) as {a}"
                     for a in self.list_of_wm_columns
                ]
            )
        elif self.typeof_db =="snowflake":
            expr=",".join(
                [
                    f"to_varchar(max(modified_date),'yyyy-mm-dd hh:mi:ss') as {a}"
                     for a in self.list_of_wm_columns
                ]
            )
        print(f"max({expr})n")
        if self.typeof_db == 'azuresql' or  self.typeof_db == 'mysql' or self.typeof_db == 'postgres':
            sql=f"(select {expr} from {self.schema_name}.{self.table_name}) as qry "
        elif self.typeof_db == "bigquery" or self.typeof_db =='snowflake':
            sql=f"(select {expr} from {self.schema_name}.{self.table_name})  "
        print("final sql is", sql)
        return sql

    def fn_get_low_watermark(self):
        """
        This method is intentionally left empty.
        """
        pass

    def fn_get_high_watermark(self, sql):
        """
        Fetch the high watermark value from the database.

        Args:
            sql (str): The SQL query to execute for fetching the high watermark.

        Returns:
            data: The result of the query execution, or None if an error occurs.
        """
        data = self.eol_db_con.fn_read(sql)
        return data

    def fn_getcount_full(self):
        """
        Fetch the total row count from the table.

        Returns:
            data: The result of the query execution, or None if an error occurs.
        """
        print("inside")
        try:
            if self.typeof_db == 'azuresql' or  self.typeof_db == 'mysql' or self.typeof_db == 'postgres':  
                sql=f"(select count(1) as cnt from {self.schema_name}.{self.table_name}) as qry "
            elif self.typeof_db == 'bigquery' or self.typeof_db =='snowflake':
                sql=f"(select count(1) as cnt from {self.schema_name}.{self.table_name})   "
            data=self.eol_db_con.fn_read(sql)
            print(sql)
            return data
        except Exception as e:
            print(e)

    def fn_getcount_delta(self, high_wm, low_wm):
        """
        Fetch the delta row count between the given high watermark and low watermark.

        Args:
            high_wm: The high watermark value.
            low_wm: The low watermark value.

        Returns:
            data: The result of the query execution, or None if an error occurs.
        """
        print("inside")
        try:
            expr = " or ".join(
                [
                    f"({a}>'{low_wm}' and {a}<='{high_wm}')"
                    for a in self.list_of_wm_columns
                ]
            )
            print(f"max({expr})n")
            if self.typeof_db == 'azuresql' or  self.typeof_db == 'mysql' or self.typeof_db == 'postgres':  
                sql=f"(select count(1) as cnt from {self.schema_name}.{self.table_name} where {expr}) as qry  "
            elif self.typeof_db == 'bigquery' or self.typeof_db =='snowflake':
                sql=f"(select count(1) as cnt from {self.schema_name}.{self.table_name} where {expr})   "
            data=self.eol_db_con.fn_read(sql)
            print(sql)
            return data
        except Exception as e:
            print(e)

    def fn_form_qry_loadfromdb_full(self, lst_columns):
        """
        Generate a SQL query to fetch columns from the specified table in the given database.

        Args:
            lst_columns: List of column names to be included in the SELECT query.

        Returns:
            sql: The generated SQL query string.
        """
        print("inside fn_form_qry_loadfromdb_full")
        try:
            column_list = ",".join(lst_columns)
            if self.typeof_db == 'azuresql' or  self.typeof_db == 'mysql' or self.typeof_db == 'postgres':
                sql=f"(select  {column_list} from {self.schema_name}.{self.table_name} )  as qry "
            elif self.typeof_db == 'bigquery' or self.typeof_db =='snowflake':
                sql=f"(select  {column_list} from {self.schema_name}.{self.table_name} )   "
            print('sql for fetrching',sql)
            return sql
        except Exception as e:
            print(e)

    def fn_form_qry_loadfromdb_delta(self, high_wm, low_wm, lst_columns):
        """
        Generate a SQL query to load delta data from the specified table based on watermark values.

        Args:
            high_wm: The high watermark value.
            low_wm: The low watermark value.
            lst_columns: List of column names to be included in the SELECT query.

        Returns:
            sql: The generated SQL query string.
        """
        try:
            expr = " or ".join(
                [
                    f"({a}>'{low_wm}' and {a}<='{high_wm}')"
                    for a in self.list_of_wm_columns
                ]
            )
            print(f"max({expr})n")
            column_list = ",".join(lst_columns)
            if self.typeof_db == 'azuresql' or  self.typeof_db == 'mysql' or self.typeof_db == 'postgres':
                sql=f"(select    {column_list} from {self.schema_name}.{self.table_name} where {expr}) as qry  "
            elif self.typeof_db == 'bigquery' or self.typeof_db =='snowflake':
                sql=f"(select    {column_list} from {self.schema_name}.{self.table_name} where {expr})  "

            print('sql for fetrching',sql)
            return sql
        except Exception as e:
            print(e)

    def fn_getColumnMapping(self, processname):
        """
        Retrieve the column mappings for a given process name and table.

        Args:
            processname: The name of the process to retrieve column mappings for.

        Returns:
            data: The result set of the SQL query for column mappings.
        """
        try:
            print("table name is", self.table_name)
            if self.typeof_db == 'azuresql' or  self.typeof_db == 'mysql' or self.typeof_db == 'postgres':
                sql=f"(select tab.TableName,col.columnname from T_table_configs tab inner join T_table_columns col on tab.TableId=col.TableId  inner join T_process_table_mapping  \
                tptm on tptm.tableId=tab.TableId inner join T_process_list pc on tptm.processId=pc.processId  \
                where tab.TableName='{self.table_name}' and pc.ProcessName='{processname}') as qry "
            elif self.typeof_db == 'bigquery' or self.typeof_db =='snowflake':
                sql=f"(select tab.TableName,col.columnname from T_table_configs tab inner join T_table_columns col on tab.TableId=col.TableId  inner join T_process_table_mapping  \
                tptm on tptm.tableId=tab.TableId inner join T_process_list pc on tptm.processId=pc.processId  \
                where tab.TableName='{self.table_name}' and pc.ProcessName='{processname}') "
            data=self.rep_db_con_obj.fn_read(sql)
            return data
        except Exception as e:
            print(e)
