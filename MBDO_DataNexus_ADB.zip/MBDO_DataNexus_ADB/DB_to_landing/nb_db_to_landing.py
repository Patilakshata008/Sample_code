# Databricks notebook source
df = spark.read.format("bigquery")\
    .option("credentialsFile","/dbfs/FileStore/rbprj_100009_eec5e4919e91.json")\
    .option("parentProject","rbprj-100009")\
    .option("table","test_connection.employee")\
    .option("bigquery.provider", "com.google.cloud.spark.bigquery.v2.Spark34BigQueryTableProvider")\
    .load()
df.display()


# COMMAND ----------

# imports
from f_dbcon import azdbconnection
from f_metadata_configs_updated import waterMarkPreocessor 
from f_mv_db_to_land_updated import mv_db_to_lan
from f_configs import metadatconfigs
from common_func.f_database_connect import DBconnection

from pyspark.sql.functions import greatest,col,to_timestamp,to_str
from pyspark.sql.functions import spark_partition_id, asc, desc
import traceback
from datetime import datetime
from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql import SparkSession

# COMMAND ----------

'''
jobId=dbutils.widgets.get("jobRunId")
FNT_ID = dbutils.widgets.get("FNT_ID")
KeyVaultSecret_prefix=dbutils.widgets.get("src_KeyVaultSecret_prefix")
des_KeyVaultSecret_prefix=dbutils.widgets.get("des_KeyVaultSecret_prefix")
'''

# COMMAND ----------


# FNT_ID = dbutils.widgets.get("FNT_ID")
# jobId=dbutils.widgets.get("job_run_id")
# KeyVaultSecret_prefix=dbutils.widgets.get("KeyVaultSecret_prefix")
# SourceSystem=dbutils.widgets.get("SourceSystem")


# COMMAND ----------

import uuid

FNT_ID = 243
jobId=str(uuid.uuid4())
print('Job_id',jobId)
KeyVaultSecret_prefix='bigquery'
SourceSystem='GCP_Bigquery'


# COMMAND ----------

server = dbutils.secrets.get(scope="fof-prd-scope",key="EDA-SQLDB-ServerName")
database = dbutils.secrets.get(scope="fof-prd-scope",key="EDA-SQLDB-DBName")
spark1 = SparkSession.builder.appName('integrity-tests').config("spark.sql.legacy.timeParserPolicy","EXCEPTION").getOrCreate()

dbasecon=DBconnection(database=database,server=server,spark1=spark1)
con=dbasecon.fn_get_connection()
metadata_configs=metadatconfigs(FNT_ID,con)
config_dict=metadata_configs.get_allconfigs()
dbconfigs=config_dict['db_extractconfigs']
typeof_db=dbconfigs['typeof_db']
print("DB_type",typeof_db)

# COMMAND ----------

# Define the driver string constant
SQL_SERVER_DRIVER = 'com.microsoft.sqlserver.jdbc.SQLServerDriver'
filtered_data = None
list_wm_columns = None
columndetails = None
Folderpath = None
rowcount = None
final_path =None
try:
    # Retrieving database connection and other configurations
    conf_databasename = dbutils.secrets.get(scope='fof-prd-scope', key='EDA-SQLDB-DBName')
    conf_servername = dbutils.secrets.get(scope='fof-prd-scope', key='EDA-SQLDB-ServerName')
    conf_jdbcDriver = SQL_SERVER_DRIVER
    jdbcDriver = SQL_SERVER_DRIVER
    url = f'jdbc:sqlserver://{conf_servername}:1433;database={conf_databasename};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
    spark1 = SparkSession.builder.appName('integrity-tests').config("spark.sql.legacy.timeParserPolicy", "EXCEPTION").getOrCreate()

    if typeof_db == 'azuresql' or  typeof_db == 'mysql' or typeof_db == 'postgres':
        src_databasename=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}DB')
        src_servername=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}Sever')
        src_databaseusername=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}username')
        src_databasepassword=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}Password')
    elif typeof_db == 'bigquery':
        src_materializationDataset = dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}MaterializationDataset') 
        src_parentProject = dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}ParentProject') 
 

    # Determining the JDBC driver and URL based on the type of database
    if typeof_db == 'azuresql':
        src_jdbcDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
        src_url = f'jdbc:sqlserver://{src_servername}:1433;database={src_databasename};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
        print("src_url", src_url)
    elif typeof_db == 'mysql':
        src_jdbcDriver = "com.mysql.cj.jdbc.Driver"
        src_url = f'jdbc:mysql://{src_servername}:3306/{src_databasename}'
        print("typeof_main_notebook", typeof_db)
        print("src_url", src_url)
    elif typeof_db == "postgres":
        src_jdbcDriver = "org.postgresql.Driver"
        src_url = f'jdbc:postgresql://{src_servername}:5432/{src_databasename}'
        print("src_url", src_url)
    elif typeof_db == 'bigquery':
        print('Bigquery line number 48')
        src_credentialsFile  = "/dbfs/FileStore/rbprj_100009_147b17db74b3.json"
    elif typeof_db == 'snowflake':
        src_databasename=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}DB')
        src_servername=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}Server')
        src_databaseusername=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}username')
        src_databasepassword=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}Password')
        src_warehouse=dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}warehouse')
        src_schema = dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}schema')
        src_role = dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}role')
        src_authenticator = dbutils.secrets.get(scope='fof-prd-scope',key=f'{KeyVaultSecret_prefix}authenticator')

    # Creating database connections
    if typeof_db == 'azuresql' or  typeof_db == 'mysql' or typeof_db == 'postgres':
        src_dbcn=azdbconnection(jdbcurl=src_url,jdbcUsername=src_databaseusername,jdbcPassword=src_databasepassword,jdbcdriver=src_jdbcDriver,credentialsFile=None,materializationDataset=None,parentProject=None,host=None,warehouse=None,database=None,schema=None,session=spark1,typeof_db=typeof_db)
    elif typeof_db == "bigquery":
        src_dbcn=azdbconnection(jdbcurl=None,jdbcUsername=None,jdbcPassword=None,jdbcdriver=None,credentialsFile=src_credentialsFile,materializationDataset=src_materializationDataset,parentProject=src_parentProject,host=None,warehouse=None,database=None,schema=None,session=spark1,typeof_db=typeof_db)
    elif typeof_db == "snowflake":
        src_dbcn=azdbconnection(jdbcurl=None,jdbcUsername=src_databaseusername,jdbcPassword=src_databasepassword,jdbcdriver=None,credentialsFile=None,materializationDataset=None,parentProject=None,host=src_servername,warehouse=src_warehouse,database=src_databasename,schema=src_schema,session=spark1,typeof_db=typeof_db)

    dbcon_obj=azdbconnection(jdbcurl=url,jdbcUsername=None,jdbcPassword=None,jdbcdriver=conf_jdbcDriver,credentialsFile=None,materializationDataset=None,parentProject=None,host=None,warehouse=None,database=None,schema=None,session=spark1,typeof_db=typeof_db)
    dbcon_obj.desdb_con_string()
    
    # Reading table configurations
    read_table_configs = f'(select tab.Filename_Template,tab.Total_columns,tab.DbLoadType,tab.LandingDbDeltaFolder,con.DBschemaname, CONVERT(VARCHAR(30),cast(con.LastWaterMarkValue as datetime), 121)  as LastWaterMarkValue,con.SourceTableName,sou.Sourcesystem_name,con.Db_column_to_partition_read,con.number_of_partitions_read_from_source from T_Meta_File_Standard_Schema tab inner join T_META_DB_Extract_configs con on con.FK_FNT_ID=tab.FNT_Id inner join T_META_Source_Systems sou on sou.PK_Sourcesystem_id=tab.FK_sourcesytem_id where tab.fnt_id={FNT_ID}) as a'
    configdata = dbcon_obj.fn_read_withSp(read_table_configs)
    filtered_data = configdata.toPandas().T.to_dict()[0]

    # Reading column level information
    columnLevelInfo = f"""(select Expected_columnname,isWaterMarkColumn,KeyColumnOrder from  T_MST_DQF_Column_Expected where fk_fnt_id={FNT_ID} and Validity_Enddate='9999-12-31 00:00:00.000') as b"""
    columndetails = dbcon_obj.fn_read_withSp(columnLevelInfo)
    watermarkcolumns = columndetails.filter("isWaterMarkColumn==1")
    if watermarkcolumns.count() >= 1:
        list_wm_columns = watermarkcolumns.select('Expected_columnname').rdd.flatMap(lambda x: x).collect()
        print('water mark column present')
    else:
        print('no watermark column configured')
    
    # Retrieving folder path
    Folderpath = dbcon_obj.fn_get_paths(SourceSystem, '', FNT_ID, 'landing', 'landing')
    print('Folderpath', Folderpath)

    # Executing database to landing process
    mdl = mv_db_to_lan(FNT_ID, jobId, filtered_data, dbcon_obj, src_dbcn, list_wm_columns, columndetails, Folderpath, typeof_db)
    mdl.mv_db_to_landing()
    

except Exception as e:
    print(e)
    error = True
    error_msg = e
finally:
    if final_path is not None:
        print('Final_path_in_main_notebook',final_path)
        print('calling logger', FNT_ID, jobId)
        dbcon_obj.fn_update_connector_logs(rowcount, jobId, high_wm, final_path)
    # else:
    #     print("final_path was not assigned")


