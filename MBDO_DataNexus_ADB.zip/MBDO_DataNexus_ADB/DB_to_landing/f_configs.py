class metadatconfigs:
    """This is the class to retrive the database configurations."""

    def __init__(self, fnt_id, con):
        """
        Initialize class metadatconfigs with FNT ID and database connection.

        Args:
            fnt_id (str): The FNT ID for which to retrieve database configurations.
            con: Database connection object.
        """
        self.fnt_id = fnt_id
        self.con = con

    def fn_getdb_configs(self):
        """
        Fetch database configurations for the given FNT ID from the database.

        Returns:
            dict: A dictionary containing the database configurations for the specified FNT ID.
        """
        statement = f"""select *  from T_META_DB_Extract_configs where  FK_FNT_ID={self.fnt_id} """
        print("statement is ", statement)
        exec_statement = self.con.prepareCall(statement)
        res = exec_statement.execute()
        print(res)
        resultSet = exec_statement.getResultSet()
        dic = []
        while resultSet.next():
            vals = {}
            vals["FK_FNT_ID"] = resultSet.getString("FK_FNT_ID")
            vals["typeof_db"] = resultSet.getString("typeof_db")
            dic.append(vals)
        exec_statement.close()
        return vals

    def get_allconfigs(self):
        """
        Fetch all configurations and return as a dictionary.

        Returns:
            dict: A dictionary containing all configuration details.
        """
        dict1 = {}
        dbconfigs = self.fn_getdb_configs()
        dict1["db_extractconfigs"] = dbconfigs
        return dict1