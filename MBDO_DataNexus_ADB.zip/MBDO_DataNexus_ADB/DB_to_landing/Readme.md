# DB_to_landing

This module ensures to copy data from a database to the landing zone. The landing layer contains raw data, and for RDBMS sources, data is stored in parquet format. This is the first point of entry for data into the data lake. Data is organized under source system and filename folders, acting as temporary storage.

## Modules Overview

### f_configs.py

- The provided code defines a class `metadatconfigs` that interacts with a SQL database to fetch and manage metadata configurations.
- `metadatconfigs` class contains the constructor that initializes the class with `fnt_id` and a database connection `con`.
- **Functions:**
  - `fn_getdb_configs`: Fetches database extract configurations from the table `T_META_DB_Extract_configs` based on `fnt_id`.
  - `get_allconfigs`: Aggregates all configurations into a dictionary.

### f_dbcon.py

- The `azdbconnection` class facilitates database connections and operations for various databases (MySQL, PostgreSQL, Azure SQL, Snowflake, BigQuery) using Spark.
- It includes methods for establishing connections, reading, writing data, and executing stored procedures, with support for OAuth2 authentication for Azure SQL.
- **Functions:**
  - `get_dbutils`: Retrieves `dbutils` for accessing Databricks secrets.
  - `fn_get_connection`: Establishes a connection to the database using service principal credentials and returns the connection and access token.
  - `source_con_string_token` and `desdb_con_string`: Establishes source and destination database connections.
  - `fn_read_parallel`: Reads data from the database in parallel using partitioning.
  - `fn_read`: Reads data from the database without partitioning.
  - `fn_read_withSp`: Reads data from the database using a stored procedure.
  - `fn_write_parallel`: Writes data to the database in parallel using partitioning.
  - `fn_get_paths`: Retrieves paths from the database using a stored procedure.
  - `fn_update_watermark`: Updates the watermark value in the database using a stored procedure.
  - `fn_update_rowcount`: Updates the row count in the database using a stored procedure.
  - `fn_insert_connector_logs`: Inserts connector logs into the database using a stored procedure.
  - `fn_update_connector_logs`: Updates connector logs in the database using a stored procedure.

### f_metadata_configs_updated.py

- The provided code defines a class `waterMarkPreocessor` that handles various database operations related to watermark processing.
- **Functions:**
  - `fn_formQuery`: Forms a SQL query to get the maximum values of watermark columns based on the database type.
  - `fn_get_low_watermark`: Placeholder method for getting the low watermark.
  - `fn_get_high_watermark`: Executes the SQL query to get the high watermark.
  - `fn_getcount_full`: Forms and executes a SQL query to get the full count of records in the table.
  - `fn_getcount_delta`: Forms and executes a SQL query to get the count of records between high and low watermarks.
  - `fn_form_qry_loadfromdb_full`: Forms a SQL query to load all columns from the table.
  - `fn_form_qry_loadfromdb_delta`: Forms a SQL query to load columns from the table between high and low watermarks.
  - `fn_getColumnMapping`: Forms and executes a SQL query to get column mappings for a given process name.

### f_metadata_functions.py

- The `waterMarkPreocessor` class is designed to manage watermark processing for database tables.
- It includes methods to form SQL queries, retrieve high and low watermarks, count records, and load data from the database.
- **Key Methods:**
  - `fn_formQuery`: Forms a SQL query to get the maximum values of watermark columns.
  - `fn_get_high_watermark`: Retrieves the high watermark using a provided SQL query.
  - `fn_getcount_full`: Counts all records in the table.
  - `fn_getcount_delta`: Counts records between high and low watermarks.
  - `fn_form_qry_loadfromdb_full`: Forms a SQL query to load all data from the table.
  - `fn_form_qry_loadfromdb_delta`: Forms a SQL query to load data between high and low watermarks.
  - `fn_getColumnMapping`: Retrieves column mappings for a given process name.

### f_mv_db_to_land_updated.py

- The `mv_db_to_lan` class is designed to move data from a database to a landing zone, handling both full and incremental loads.
- It initializes with various parameters including database connection objects, watermark columns, and file paths.
- **Key Methods:**
  - `mv_db_to_landing`: Main method to handle the data transfer process.
  - Inserts initial connector logs.
  - Determines the type of load (full, merge, or append) and forms the appropriate SQL query using the `waterMarkPreocessor` class.
  - Retrieves the high watermark and calculates the maximum date.
  - Depending on the load type, counts the records and forms the SQL query to load data.
  - Reads data in parallel from the source database.
  - Writes the data to a specified landing folder in Parquet format.
  - Updates the watermark and connector logs after the data transfer.
  
### nb_azuredb_v1.py

- The `azdbconnection` class manages database connections and operations using Spark and Azure SQL with OAuth2 authentication.
- It includes methods for establishing connections, reading and writing data in parallel, and executing stored procedures for tasks like updating watermarks and logging.
- **Functions:**
  - Ensures secure and efficient data operations with various databases.

### nb_db_to_landing.py

- **Steps:**
  1. Import required modules: Imports necessary modules and classes for database connections and data processing.
  2. Set job and database configuration: Sets up job ID, FNT_ID, and database connection details.
  3. Initialize database connection: Initializes a database connection using the `azdbconnection` class and retrieves metadata configurations.
  4. Retrieve source database credentials: Retrieves credentials for the source database based on the type of database (Azure SQL, MySQL, PostgreSQL, BigQuery, or Snowflake).
  5. Create database connections: Creates database connection objects for the source and destination databases.
  6. Read table configurations: Reads table configurations and column-level information from the database.
  7. Execute data transfer: Executes the data transfer process from the source database to the landing zone.
  8. Error handling and logging: Handles any exceptions and updates the connector logs.

### nb_source_database.py

- The `dbconnection` class is designed to manage database connections and operations using Spark and Azure SQL with OAuth2 authentication.
- **Key Functions:**
  - Initialization: Sets up database connection parameters (JDBC URL, username, password, driver, and Spark session).
  - `fn_get_connection()`: Generates an OAuth2 access token and creates a JDBC connection.
  - Read Methods:
    - `fn_read_parallel()`: Reads data in parallel from the database using specified partitions.
    - `fn_read()`: Reads data from the database without partitioning.
    - `fn_read_withSp()`: Reads data using a stored procedure with an access token.
  - Write Method:
    - `fn_write_parallel()`: Writes data to the database in parallel.
  - Stored Procedure Methods:
    - `fn_get_paths()`: Executes a stored procedure to get paths.
    - `fn_update_watermark()`: Updates the watermark value.
    - `fn_update_rowcount()`: Updates the row count.
    - `fn_insert_connector_logs()`: Inserts connector logs.
    - `fn_update_connector_logs()`: Updates connector logs.
