# Databricks notebook source
import msal
class dbconnection:
  """This is the class for database connection establishment."""

  def __init__(self,jdbcurl,jdbcUsername,jdbcPassword,jdbcdriver,session):
    """
    Initialize the dbconnection class.

    Args:
        jdbcurl (str): JDBC URL for the database connection.
        jdbcUsername (str): Username for the database.
        jdbcPassword (str): Password for the database.
        jdbcdriver (str): JDBC driver class name.
        session (SparkSession): Active Spark session.
    """
    self.jdbcurl = jdbcurl
    self.username=jdbcUsername
    self.password=jdbcPassword
    self.driver=jdbcdriver
    self.session=session
    
  
    
  def fn_get_connection(self):
    """
    Establish a JDBC connection using a service principal with OAuth2 authentication.

    Returns:
        tuple: A tuple containing the JDBC connection object and the access token.
    """
    # Set url & credentials
    tenant_id = dbutils.secrets.get(scope="eda-dev-adb-scope",key="EDA-SPN-TenantId")
    sp_client_id = dbutils.secrets.get(scope="eda-dev-adb-scope",key="EDA-SPN-ClientId")
    sp_client_secret = dbutils.secrets.get(scope="eda-dev-adb-scope",key="EDA-SPN-ClientSecret")
    
    url=self.jdbcurl

    # Write your SQL statement as a string


    # Generate an OAuth2 access token for service principal
    authority = f"https://login.windows.net/{tenant_id}"
    app = msal.ConfidentialClientApplication(sp_client_id, sp_client_secret, authority)
    token = app.acquire_token_for_client(scopes=["https://database.windows.net/.default"])["access_token"]

    # Create a spark properties object and pass the access token
    properties = spark._sc._gateway.jvm.java.util.Properties()
    properties.setProperty("accessToken", token)

    # Fetch the driver manager from your spark context
    driver_manager = spark._sc._gateway.jvm.java.sql.DriverManager

    # Create a connection object and pass the properties object
    con = driver_manager.getConnection(url, properties)
    return con,token
      
  def fn_read_parallel(self,sql,numberOfPartitions,partitionColumn,lowerBound,upperBound):
    """
    Read data from the database table in parallel using the specified partitioning.

    Args:
        sql (str): The name of the table or SQL query to execute.
        numberOfPartitions (int): Number of partitions to use for parallelism.
        partitionColumn (str): Column to partition the data on.
        lowerBound (int): Lower bound for partition column values.
        upperBound (int): Upper bound for partition column values.

    Returns:
        DataFrame: A PySpark DataFrame containing the queried data.
    """
    print('no of partition,lower bound,uppre bound,partition column is',numberOfPartitions,partitionColumn,lowerBound,upperBound)
    jdbcDF = self.session.read.format("jdbc") \
    .option("url",self.jdbcurl) \
    .option("dbtable", sql) \
    .option("user", self.username) \
    .option("password", self.password) \
    .option("driver", self.driver) \
    .option("numPartitions",numberOfPartitions ) \
    .option("partitionColumn",f"{partitionColumn}" ) \
    .option("lowerBound", lowerBound)\
    .option("upperBound", upperBound)\
    .load()
    print('partitions in df',jdbcDF.rdd.getNumPartitions())
    #.cache()
    return jdbcDF

  def fn_read(self,sql):
    """
    Read data from the database table or execute a query.

    Args:
        sql (str): The name of the table or SQL query to execute.

    Returns:
        DataFrame: A PySpark DataFrame containing the queried data.
    """
    jdbcDF = self.session.read.format("jdbc") \
    .option("url",self.jdbcurl) \
    .option("dbtable", sql) \
    .option("user", self.username) \
    .option("password", self.password) \
    .option("driver", self.driver) \
    .load()
    return jdbcDF
  
  def fn_read_withSp(self,sql):
    """
    Reads data from the database using a stored procedure and an access token.

    Args:
        sql (str): Stored procedure name or table name.

    Returns:
        DataFrame: A Spark DataFrame containing the fetched data.
    """
    jdbcDF = self.session.read.format("jdbc") \
    .option("url",self.jdbcurl) \
    .option("dbtable", sql) \
    .option("accessToken", self.token) \
    .option("hostNameInCertificate", "*.database.windows.net") \
    .option("driver", self.driver) \
    .load()
    return jdbcDF
  
  def fn_write_parallel(self,sql,numberOfPartitions,partitionColumn,lowerBound,upperBound,df):
    """
    Writes a DataFrame to the database in parallel using JDBC.

    Args:
        sql (str): Table name or SQL query for the write operation.
        numberOfPartitions (int): Number of partitions for parallel write.
        partitionColumn (str): Column name to use for partitioning.
        lowerBound (int): Lower bound for partitioning.
        upperBound (int): Upper bound for partitioning.
        df (DataFrame): Spark DataFrame to be written to the database.
    """
    print('no of partition,lower bound,uppre bound,partition column is',numberOfPartitions,partitionColumn,lowerBound,upperBound)
    print('jdbc url is ',self.jdbcurl)
    print('tablename is',sql)
    df.repartition(numberOfPartitions).write.mode('overwrite')\
    .format("jdbc") \
    .option("url",self.jdbcurl) \
    .option("dbtable", sql) \
    .option("user", self.username) \
    .option("password", self.password) \
    .option("driver", self.driver).save()
    
  
  def fn_get_paths(self,sourcesystem_name,usecase_name,fnt_id,dllayer,pathtype):
    """
    Retrieves paths from the database using a stored procedure.

    Args:
        sourcesystem_name (str): Name of the source system.
        usecase_name (str): Name of the use case.
        fnt_id (int): Functional task ID.
        dllayer (str): Data lake layer.
        pathtype (str): Path type.

    Returns:
        dict: A dictionary containing the fetched path.
    """
    try:
        statement = f"""EXEC dbo.sp_get_paths  @sourcesystem='{sourcesystem_name}',@usecase='{usecase_name}',@fnt={fnt_id},@dllayer='{dllayer}',@pathtype='{pathtype}'"""
        print(statement)
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet=exec_statement.getResultSet()   
        while (resultSet.next()):
            vals={}        
            vals['path']=resultSet.getString('path')               

        return vals
        exec_statement.close()   
    except Exception as e:
        print(e)
  
  def fn_update_watermark(self,fnt_id,watermarkvalue):
    """
    Updates the watermark value in the database.

    Args:
        fnt_id (int): Functional task ID.
        watermarkvalue (str): New watermark value.

    Returns:
        tuple: A tuple containing a success flag and an error message (if any).
    """
    try:
        statement = f"""EXEC dbo.sp_update_watermark  @fntid={fnt_id},@watermarkvalue='{watermarkvalue}'"""
        print(statement)
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()             
        exec_statement.close()   
        return True,''
    except Exception as e:
        return False,e
  
  def fn_update_rowcount(self,fnt_id,job_id,rowcount):
    """
    Updates the row count for a specific task in the database.

    Args:
        fnt_id (int): Functional task ID.
        job_id (str): Job ID.
        rowcount (int): Row count to update.

    Returns:
        tuple: A tuple containing a success flag and an error message (if any).
    """
    try:
        statement = f"""EXEC dbo.sp_update_db_delta_count  @fnt_id={fnt_id},@job_id='{job_id}',@row_count={rowcount}"""
        print(statement)
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()             
        exec_statement.close()   
        return True,''
    except Exception as e:
        return False,e
  
  def fn_insert_connector_logs(self,FNT_ID,jobId):
    """
    Inserts logs into the connector logs table.

    Args:
        FNT_ID (int): Functional task ID.
        jobId (str): Job run ID.

    Returns:
        tuple: A tuple containing a success flag and an error message (if any).
    """
    try:
        statement = f"""EXEC dbo.sp_insert_connector_logs @fk_fnt_id={FNT_ID},@job_run_id='{jobId}'"""
        print(statement)
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()             
        exec_statement.close()   
        return True,''
    except Exception as e:
        return False,e
  
  def fn_update_connector_logs(self,row_count,job_run_id,lastwatermark_value):
    """
    Updates logs in the connector logs table.

    Args:
        row_count (int): Row count to update.
        job_run_id (str): Job run ID.
        lastwatermark_value (str): Last watermark value.

    Returns:
        tuple: A tuple containing a success flag and an error message (if any).
    """
    try:
        statement = f"""EXEC dbo.sp_update_connector_logs @row_count={row_count},@job_run_id='{job_run_id}',@lastwatermark_value='{lastwatermark_value}'"""
        print(statement)
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()             
        exec_statement.close()   
        return True,''
    except Exception as e:
        return False,e