# Databricks notebook source
# MAGIC %md --Run the below 2 Cells before executing other cells--

# COMMAND ----------

from pyspark.sql import SparkSession

# import msal
# import os
# import os.path, time
# import datetime
# from datetime import datetime
# from pyspark.sql import SparkSession
# import csv

# COMMAND ----------

spark = SparkSession.builder.appName("integrity-tests").getOrCreate()
sqlserver = dbutils.secrets.get(scope="fof-prd-scope", key="sqlSever")  # noqa: F821
sqldatabase = dbutils.secrets.get(scope="fof-prd-scope", key="sqlDB")  # noqa: F821
url = f"jdbc:sqlserver://{sqlserver};databaseName={sqldatabase}"

# COMMAND ----------

# MAGIC %md #1.0 Source System Configuration

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/sourcesystem.csv")
)
df.write.format("jdbc").option("url", url).option("dbtable", "T_Sourcesystems").option(
    "user", "fofsqladmin"
).option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md # 2.0 File Standard Schema Configuration

# COMMAND ----------


df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/filenametemplate.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_File_Standard_Schema"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md #3.0 DQF Column Expected Configuration
# MAGIC

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/dqffile.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_DQF_Column_Expected"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md #4.0 File Validation Mapping Configuration

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/attributemapping.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_FNT_File_Attribute_Mapping"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md # 5.0 Data Quality Check Mapping Configuration

# COMMAND ----------


df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/attributeschemamapping.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_FNT_File_Schema_Attribute_Mapping"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md # 6.0 Job Scheduling Configuration

# COMMAND ----------


df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/T_job_schedule_logs.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_job_schedule_logs"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md #7.0 Alert mapping Configuration

# COMMAND ----------


df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/Alertconfig.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_map_alert_config_validation"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md #8.0 RDBMS Data Configuration

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/dbextract.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_DB_Extract_configs"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md #9.0 Eventhub Data Configuration

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/eventhubconfig.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_Iot_Data_Config "
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md #10.0 File Validation Master Configuration

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/attributemaster.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_File_Attributes_Master"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md # 11.0 Data Quality Validation Master Configuration

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/schemattributemaster.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "T_File_Schema_Attributes"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()

# COMMAND ----------

# MAGIC %md #12. API Data Configuration

# COMMAND ----------

df = (
    spark.read.format("csv")
    .option("header", "true")
    .load("/mnt/metadata/IN/apidataconfig.csv")
)
df.write.format("jdbc").option("url", url).option(
    "dbtable", "t_api_metadata_config"
).option("user", "fofsqladmin").option("password", "FoF@Admin").mode("append").save()