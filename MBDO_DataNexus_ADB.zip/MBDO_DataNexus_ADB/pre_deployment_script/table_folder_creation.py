class configsbuilder:
    def __init__(self, config_dict, spark):
        self.config = config_dict
        self.schema1 = self.config["schema"]
        self.SourceSystem = self.config["allconfigs"]["Sourcesystem_name"]
        self.FileTemplate = self.config["allconfigs"]["Filename_Template"]
        self.dbname = self.config["allconfigs"]["dbname"]
        self.tablename = self.config["allconfigs"]["tablename"]
        self.path = "dbfs:/mnt/landing/" + self.SourceSystem + "/IN"
        self.bronze_success_path = (
            "dbfs:/mnt/bronze/"
            + self.SourceSystem
            + "/Raw/Success/IN/"
            + self.FileTemplate
        )
        self.bronze_error_path = (
            "dbfs:/mnt/bronze/"
            + self.SourceSystem
            + "/Raw/Error/IN/"
            + self.FileTemplate
        )
        self.bronze_cache_path = "dbfs:/mnt/bronze/" + self.SourceSystem + "/Cache/IN"
        self.silver_error_path = (
            "dbfs:/mnt/silver/" + self.SourceSystem + "/Error/IN/" + self.FileTemplate
        )
        self.spark = spark
        self.dbutils = self.get_dbutils()  # noqa: F821
        self.lis = [
            self.path,
            self.bronze_success_path,
            self.bronze_error_path,
            self.bronze_cache_path,
            self.silver_error_path,
        ]

    def get_dbutils(self):
        try:
            # from pyspark.dbutils import DBUtils

            dbutils = DBUtils(self.spark)  # noqa: F821
        except ImportError:
            import IPython

            dbutils = IPython.get_ipython().user_ns["dbutils"]  # noqa: F821
        return dbutils  # noqa: F821

    def fn_get_schema(self, columns):
        schema = ""
        for i in range(len(columns)):
            # print(i)
            if len(columns) == 1 or i == len(columns) - 1:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                )
            else:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                    + ","
                )

        return schema

    def checkfolderexists(self, path1):
        self.path2 = path1
        try:
            if dbutils.fs.ls(self.path2):  # noqa: F821
                return True
        except Exception as err:
            if "java.io.FileNotFoundException" in str(err):
                return False

    def create_folder(self, path1):
        self.path2 = path1
        self.dbutils.fs.mkdirs(self.path2)  # noqa: F821
        print("source folder created " + self.path2)

    def create_deltatable(self):
        db_query = f"Create database if not exists {self.SourceSystem}"
        self.spark.sql(db_query)
        self.table_schema = self.fn_get_schema(self.schema1)
        self.table_schema += (
            ",start_date timestamp,end_date timestamp, current_status int"
        )
        query = f"CREATE TABLE if not exists {self.dbname}.{self.tablename}({self.table_schema}) using delta location '/mnt/silver/{self.SourceSystem}/Success/IN/{self.FileTemplate}'"
        print("complete qry is", query)
        self.spark.sql(query)
        print("delta table created")

    def autoconfigsbuilder(self):
        # for pat in self.lis:
        #    if not self.checkfolderexists(pat):
        #        self.create_folder(pat)
        self.create_deltatable()
