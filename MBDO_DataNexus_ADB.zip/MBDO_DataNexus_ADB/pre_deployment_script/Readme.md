# Pre-Deployment Script - README

This repository contains a set of scripts designed to configure resources and automate tasks in the pre-deployment phase. These scripts ensure that data pipeline configurations and Delta tables are properly set up before deployment.

## Table of Contents

- [Auto_configs.py](#auto_configspy)
- [Auto_Create_Delta_Table.py](#auto_create_delta_tablepy)
- [db_configreader.py](#dbconfigreaderpy)
- [metadata_configuration.py](#metadata_configurationpy)
- [table_folder_creation.py](#table_folder_creationpy)

---

## Auto_configs.py

**Purpose**:  
This script is currently a placeholder and does not contain any code. It is intended for future configuration tasks related to the pre-deployment process.

**Usage**:  
No code has been implemented yet. It can be extended for future requirements.

---

## Auto_Create_Delta_Table.py

This script is responsible for creating Delta tables based on configurations for a specific range of `FNT_ID` values.

### Key Steps:
1. **Set FNT_ID**:  
   - The `FNT_ID` is initially set to "215".

2. **Import Required Modules**:  
   - `SparkSession` from `pyspark`
   - `Dbconfigreaders` from `db_configreader`
   - `DBconnection` from `common_func.databaseconnect`
   - `configsbuilder` from `table_folder_creation`

3. **Initialize Spark Session and Retrieve Secrets**:  
   - Initializes a Spark session for data processing with the application name "integrity-tests".
   - Sets the Spark SQL legacy time parser policy to "LEGACY".
   - Retrieves SQL server and database credentials from the Databricks secret scope `fof-prd-scope`.

4. **Establish Database Connection**:  
   - Creates an instance of `DBconnection` with the retrieved credentials and establishes the connection using the `fn_get_connection` method.

5. **Retrieve Configurations**:  
   - Creates an instance of `Dbconfigreaders` with the established connection and `FNT_ID`.
   - Retrieves the configurations using the `getall_configs` method.
   - Extracts and prints the schema, source system, and file template from the configurations.

6. **Build Configurations**:  
   - Creates an instance of `configsbuilder` with the configuration data and Spark session.
   - Calls the `autoconfigsbuilder` method to create the necessary Delta tables and folders.

7. **Loop Through FNT_IDs**:  
   - Iterates through a range of `FNT_ID` values from 180 to 214.
   - Repeats the above steps for each `FNT_ID` to set up configurations and build Delta tables accordingly.
   - Prints the current `FNT_ID` for tracking progress.

---

## db_configreader.py

This script defines the `Dbconfigreaders` class, which interacts with a database to retrieve configuration data.

### Key Methods:
- **`__init__`**: Initializes the class with a database connection and `FNT_ID`.
- **`fn_get_schema`**: Executes a stored procedure to retrieve schema details.
- **`fn_get_deltaLake_configs`**: Retrieves Delta Lake configurations.
- **`fn_get_db_tb_ss_fnt`**: Retrieves database, table, and source system details.
- **`getall_configs`**: Calls the above methods to gather all configurations and returns them in a dictionary.

---

## metadata_configuration.py

This script is responsible for configuring various metadata and data quality settings.

### Key Steps:
1. **Initialize Spark Session and Retrieve Secrets**:  
   - Initializes a Spark session with the application name "integrity-tests".
   - Retrieves the SQL server and database credentials from the Databricks secret scope `fof-prd-scope`.

2. **Source System Configuration**:  
   - Reads `sourcesystem.csv` and writes its content to the `T_Sourcesystems` table in the SQL Server database.

3. **File Standard Schema Configuration**:  
   - Reads `filenametemplate.csv` and writes its content to the `T_File_Standard_Schema` table.

4. **DQF Column Expected Configuration**:  
   - Reads `dqffile.csv` and writes its content to the `T_DQF_Column_Expected` table.

5. **File Validation Mapping Configuration**:  
   - Reads `attributemapping.csv` and writes its content to the `T_FNT_File_Attribute_Mapping` table.

6. **Data Quality Check Mapping Configuration**:  
   - Reads `attributeschemamapping.csv` and writes its content to the `T_FNT_File_Schema_Attribute_Mapping` table.

7. **Job Scheduling Configuration**:  
   - Reads `T_job_schedule_logs.csv` and writes its content to the `T_job_schedule_logs` table.

8. **Alert Mapping Configuration**:  
   - Reads `Alertconfig.csv` and writes its content to the `T_map_alert_config_validation` table.

9. **RDBMS Data Configuration**:  
   - Reads `dbextract.csv` and writes its content to the `T_DB_Extract_configs` table.

10. **Eventhub Data Configuration**:  
    - Reads `eventhubconfig.csv` and writes its content to the `T_Iot_Data_Config` table.

11. **File Validation Master Configuration**:  
    - Reads `attributemaster.csv` and writes its content to the `T_File_Attributes_Master` table.

12. **Data Quality Validation Master Configuration**:  
    - Reads `schemattributemaster.csv` and writes its content to the `T_File_Schema_Attributes` table.

---

## table_folder_creation.py

This script defines the `configsbuilder` class for managing and building configurations related to Delta tables and folders in the Databricks environment.

### Key Methods:
- **`__init__`**: Initializes the class with configuration data and a Spark session, and sets up paths for folder and table creation.
- **`get_dbutils`**: Retrieves the `dbutils` object for file system operations.
- **`fn_get_schema`**: Constructs a schema string from column definitions.
- **`checkfolderexists`**: Checks if a folder exists in the Databricks file system.
- **`create_folder`**: Creates a new folder in the Databricks file system.
- **`create_deltatable`**: Creates a Delta table in the specified database with the provided schema.
- **`autoconfigsbuilder`**: Calls the method to create the Delta table and folder based on the provided configurations.

---

## Pre-Deployment Configuration

These scripts help configure resources, Delta tables, and metadata before the main deployment. It ensures that all necessary tables, configurations, and file system structures are ready for use during the actual deployment of data pipelines.

## Requirements

- Databricks environment
- Databricks secret scope (`fof-prd-scope`)
- SQL Server access credentials
- CSV files (e.g., `sourcesystem.csv`, `filenametemplate.csv`, etc.) with proper format


