# Databricks notebook source
FNT_ID = "215"

# COMMAND ----------

from pyspark import SparkSession
from db_configreader import Dbconfigreaders
from common_func.databaseconnect import DBconnection
from table_folder_creation import configsbuilder

# COMMAND ----------

spark = SparkSession.builder.appName("integrity-tests").getOrCreate()
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
server = dbutils.secrets.get(scope="fof-prd-scope", key="sqlSever")  # noqa: F821
database = dbutils.secrets.get(scope="fof-prd-scope", key="sqlDB")  # noqa: F821
spark1 = SparkSession.builder.appName("integrity-tests").getOrCreate()
source_dl_layer = "Bronze"
dest_dl_layer = "Silver"
dbasecon = DBconnection(database=database, server=server, spark1=spark1)
con = dbasecon.fn_get_connection()
configreader = Dbconfigreaders(con, FNT_ID)
config_dict = configreader.getall_configs()
schema1 = config_dict["schema"]
SourceSystem = config_dict["deltalake_configs"]["DbName"]
FileTemplate = config_dict["deltalake_configs"]["TabelName"]
print(SourceSystem)
print(FileTemplate)
print(config_dict)

# COMMAND ----------

delt = configsbuilder(config_dict, spark1)
delt.autoconfigsbuilder()

# COMMAND ----------

for FNT_ID in range(180, 214):
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
    server = dbutils.secrets.get(scope="fof-prd-scope", key="sqlSever")
    database = dbutils.secrets.get(scope="fof-prd-scope", key="sqlDB")
    spark1 = SparkSession.builder.appName("integrity-tests").getOrCreate()
    source_dl_layer = "Bronze"
    dest_dl_layer = "Silver"
    dbasecon = DBconnection(database=database, server=server, spark1=spark1)
    con = dbasecon.fn_get_connection()
    configreader = Dbconfigreaders(con, FNT_ID)
    config_dict = configreader.getall_configs()
    schema1 = config_dict["schema"]
    print(FNT_ID)
    delt = configsbuilder(config_dict, spark1)
    delt.autoconfigsbuilder()


# COMMAND ----------

# MAGIC %sql
# MAGIC create database db_kafkametadata