class Dbconfigreaders:
    def __init__(self, dbcon, fnt_id):

        # self.Sourcesystem=Sourcesystem
        # self.fnt_attributes_master={}
        self.con = dbcon
        # self.con=self.a.fn_get_connection()
        # self.FNT_ID=FNT_ID
        self.fnt_id = fnt_id

    def fn_get_schema(self):
        statement = f"""EXEC dbo.sp_get_schema_details  @fnt_id='{self.fnt_id}'"""
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        # print(res)
        results = []
        while resultSet.next():
            vals = {}
            vals["Expected_Columnname"] = resultSet.getString("Expected_Columnname")
            vals["Expected_Datatype"] = resultSet.getString("Expected_Datatype")
            vals["Expected_Length"] = resultSet.getString("Expected_Length")
            vals["Expected_Precision"] = resultSet.getInt("Expected_Precision")
            vals["Expected_Unit"] = resultSet.getString("Expected_Unit")
            vals["Expected_Type"] = resultSet.getString("Expected_Type")
            vals["Expected_Scale"] = resultSet.getInt("Expected_Scale")
            vals["Is_Nullable"] = resultSet.getString("Is_Nullable")
            vals["Is_Unique"] = resultSet.getString("Is_Unique")
            vals["operation"] = resultSet.getString("operation")
            vals["Query"] = resultSet.getString("Query")
            vals["Is_Mandatory_Column"] = resultSet.getString("Is_Mandatory_Column")
            vals["Expected_DatetimeFormat"] = resultSet.getString(
                "Expected_DatetimeFormat"
            )
            vals["Expected_Regex"] = resultSet.getString("Expected_Regex")
            vals["Expected_startvalue"] = resultSet.getString("Expected_startvalue")
            vals["Expected_endvalue"] = resultSet.getString("Expected_endvalue")

            results.append(vals)
        exec_statement.close()
        return results

    def fn_get_deltaLake_configs(self):
        statement = (
            f"""EXEC dbo.[sp_get_Deltatable_configs_new] @fnt_id={self.fnt_id}"""
        )
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        # result_dict={}
        while resultSet.next():
            vals = {}
            vals["DbName"] = resultSet.getString("DbName")
            vals["TabelName"] = resultSet.getString("TabelName")
            vals["KeyColumns"] = resultSet.getString("KeyColumns")
            vals["PartitionColumns"] = resultSet.getString("PartitionColumns")
            vals["WaterMarkColumns"] = resultSet.getString("WaterMarkColumns")
            vals["DbLoadType"] = resultSet.getString("DbLoadType")
            vals["SCD_Column"] = resultSet.getString("SCD_Column")
            # result_dict.append(vals)
            # Close connections
        exec_statement.close()
        # self.con.close()
        return vals

    def fn_get_db_tb_ss_fnt(self):
        statement = f"""select Sourcesystem_name,Filename_Template,DatalakeDbName as dbname,FNT_Delta_Lake_table_Name as tablename from [dbo].[T_META_File_Standard_Schema] inner join [dbo].[T_MST_Sourcesystems] on FK_sourcesytem_id= PK_Sourcesystem_id where FNT_Id={self.fnt_id}"""
        exec_statement = self.con.prepareCall(statement)
        exec_statement.execute()
        resultSet = exec_statement.getResultSet()
        # result_dict={}
        while resultSet.next():
            vals = {}
            vals["Sourcesystem_name"] = resultSet.getString("Sourcesystem_name")
            vals["Filename_Template"] = resultSet.getString("Filename_Template")
            vals["dbname"] = resultSet.getString("dbname")
            vals["tablename"] = resultSet.getString("tablename")

            # result_dict.append(vals)
            # Close connections
        exec_statement.close()
        # self.con.close()
        return vals

    def getall_configs(self):
        config_dict = {}
        columnnames = []
        fileschema = self.fn_get_schema()
        filedelta = self.fn_get_deltaLake_configs()
        allconfigs = self.fn_get_db_tb_ss_fnt()
        config_dict["schema"] = fileschema
        config_dict["deltalake_configs"] = filedelta
        config_dict["allconfigs"] = allconfigs
        print('columnnames', columnnames)
        return config_dict
