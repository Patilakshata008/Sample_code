# Databricks notebook source
from datetime import datetime
import json
import multiprocessing as mp
from pyspark.sql import SparkSession
from f_attribute_validator import AttributeValidator as avr
from f_utility_functions import Dtbaseconnect as dbcon1
from f_retrieve_listoffiles import RetriveListofFiles as rlf
from f_log_files import updatinglogs as ul
from f_db_reader import databasereaders as dbr
from f_retrieve_listofattributes import Retrivelistattributes as ra
from common_func.f_database_connect import DBconnection as db
from common_func.f_logs import commonlogs as cl
# Databricks notebook source
# MAGIC %reload_ext autoreload
# MAGIC %autoreload 2
# MAGIC

# COMMAND ----------




# COMMAND ----------



# import uuid
# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# SourceSystem='Test_AdvHRcsv'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID='2'
# FileTemplate='Test_HR_csv'


# import uuid
# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# SourceSystem='quotation_montly_report_001'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID='3'
# FileTemplate='quotation_sample'


# import uuid
# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# SourceSystem='pilump'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID='4'
# FileTemplate='pilump'

# import uuid
# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# SourceSystem='sapp'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID='5'
# FileTemplate='sapp'

# import uuid
# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# SourceSystem='eadm_peps_decision_trees'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID='7'
# FileTemplate='be_data_extract_matrix_eadm'


# COMMAND ----------

# Input is passed from azure data factory pipelines
job_run_id = dbutils.widgets.get("jobRunId")  # noqa: F821
pipeline_run_id = dbutils.widgets.get("pipielineRunId")  # noqa: F821
# AppName=dbutils.widgets.get('ApplicationName')
SourceSystem = dbutils.widgets.get("SourceSystem")  # noqa: F821
FileTemplate = dbutils.widgets.get("FileName_Template")  # noqa: F821
FNT_ID = dbutils.widgets.get("FNT_Id")  # noqa: F821
IOTFlag = dbutils.widgets.get("IS_IOT")  # noqa: F821
HierarchyFlag = dbutils.widgets.get("IS_Hierarchical")  # noqa: F821
curr_try = dbutils.widgets.get("curr_try")  # noqa: F821
# HierarchyFlag='True'


# COMMAND ----------


def fn_process_files(batchfiles):
    """
    Processes a batch of files and updates delta logs, validation status, and attribute details.

    Args:
        batchfiles (list): A list of file metadata dictionaries containing details like 
            'FK_FNT_Id', 'FileName', 'PK_file_id', and 'FilePath'.

    Returns:
        list: A list of dictionaries where each dictionary contains:
            - 'File_val_res': Overall validation result for the file.
            - 'File_Name': The name of the file.
            - 'sourcepath': Calculated source path for the file.
            - 'destinationpath': Calculated destination path for the file.
            - 'File_id': Primary key identifier for the file.
            - 'result': Result of the path calculation for the file.

    Steps:
        1. Inserts delta logs for the batch of files.
        2. Retrieves file attribute list.
        3. If `fv_flag` is 0, calculates file paths and updates logs directly.
        4. Otherwise, processes file attributes, validates attributes, and updates logs:
            - Logs detailed attribute values.
            - Performs attribute validation and calculates file paths.
            - Updates validation status and detailed logs.

    Raises:
        Exception: If any error occurs during the file processing or database interactions.

    Notes:
        - Requires several external functions or classes like `ra`, `cmnlogs`, `dbasecon`, and `avr`.
        - Assumes `fv_flag`, `job_run_id`, `FNT_ID`, `path`, `pipeline_run_id`, and other global variables
          are defined and accessible.
    """
    # res={'File_val_res':'','File_Name':''}
    batchlen = len(batchfiles)
    print("batchfiles are------------ ", batchfiles)
    print("in step 1 inserting delta logs for", batchlen, "files")
    cmnlogs.fn_insert_delta_logs(
        batchfiles, job_run_id, pipeline_run_id, from_dl_layer=source_dl_layer
    )
    print("in step 2 get file attribute list")
    ratt = ra(dbcon, FNT_ID, job_run_id)
    file_attribute_list = []
    res_list = []
    if fv_flag == 0:
        overall_res = True
        for file in batchfiles:
            res = {}
            sourcepath, destinationpath, result = dbasecon.fn_calculate_file_path(
                file["FK_FNT_Id"],
                file["FileName"],
                overall_res,
                file["PK_file_id"],
                path,
                file["FilePath"],
            )
            res["File_val_res"] = overall_res
            res["File_Name"] = file["FileName"]
            res["sourcepath"] = sourcepath
            res["destinationpath"] = destinationpath
            res["File_id"] = file["PK_file_id"]
            res["result"] = result
            res_list.append(res)
        cmnlogs.fn_update_delta_logs_new(
            batchfiles,
            job_run_id,
            to_dl_layer=None,
            to_dl_layer_path=None,
            validation_status="completed",
        )
    else:
        for file in batchfiles:
            file_attributes = ratt.fn_file_process_slave_get_attributes(file)
            print("file_attributes", file_attributes)
            # print('i:',type(i))
            length_file_att = len(file_attributes)
            len_file_att = length_file_att - 1
            while len_file_att > -1:
                file_attributes[len_file_att]["PK_file_id"] = file["PK_file_id"]
                len_file_att = len_file_att - 1
            file_attribute_list.append(file_attributes)

        print("list of file attributes:", file_attribute_list)
        print("in step 3 updating attribute details log")
        updlogs.fn_log_attribute_values(json.dumps(file_attribute_list))
        res_list = []
        detailed_list = []
        for file_att, file in zip(file_attribute_list, batchfiles):
            res = {"File_val_res": "", "File_Name": ""}
            print("file_att---- ", file_att)
            print("file----- ", file)
            av = avr(dbasecon, file_att, file["PK_file_id"], FNT_ID)
            print("file_att-------", file_att)
            overall_res, detailed_res = av.fn_getattributesValidation()
            print("overall_res-----------------", overall_res)
            print("detailed_res--------------", detailed_res)
            detailed_list.append(detailed_res)
            print("details status resis", detailed_list)

            sourcepath, destinationpath, result = dbasecon.fn_calculate_file_path(
                file["FK_FNT_Id"],
                file["FileName"],
                overall_res,
                file["PK_file_id"],
                path,
                file["FilePath"],
            )
            print("sorcepath ", sourcepath)
            print("destinationpath ", destinationpath)
            res["File_val_res"] = overall_res
            res["File_Name"] = file["FileName"]
            res["sourcepath"] = sourcepath
            res["destinationpath"] = destinationpath
            res["File_id"] = file["PK_file_id"]
            res["result"] = result
            res_list.append(res)
        print("result is---------------- ", res_list)
        print("detailed_list-----", detailed_list)
        cmnlogs.fn_update_delta_logs_new(
            batchfiles,
            job_run_id,
            to_dl_layer=None,
            to_dl_layer_path=None,
            validation_status="completed",
        )
        updlogs.fn_update_attribute_validation(json.dumps(detailed_list))
    return res_list


def fn_copyfiles(batchfiles):
    """
    Copies files from source to destination paths and updates delta logs.

    Args:
        batchfiles (list): A list of dictionaries where each dictionary contains:
            - 'File_Name': Name of the file to be copied.
            - 'sourcepath': Source path of the file.
            - 'destinationpath': Destination path where the file should be copied.
            - 'File_id': Unique identifier of the file.
            - 'result': Validation result for the file ('Error' indicates issues).

    Returns:
        dict: A dictionary mapping file IDs to their processing status ('processed').

    Steps:
        1. Processes each file in the batch:
            - Determines the actual source and destination paths.
            - Logs an alert if the validation result is 'Error'.
            - Moves the file from the source to the destination.
        2. Updates delta logs to indicate the completion of the copy activity.

    Notes:
        - Files with a source path starting with `/dbfs/` are adjusted to use the `dbfs:/` prefix.
        - Assumes `dbutils.fs.mv` is available for moving files in a Databricks environment.
        - Requires external functions or modules such as `cmnlogs.fn_add_alerts` and 
          `cmnlogs.fn_update_delta_logs_newcopy`.

    Raises:
        Exception: If any error occurs during file movement or log updates.
    """
    file1 = {}
    for file in batchfiles:
        filename = file["File_Name"]
        sourcepath = file["sourcepath"]
        destinationpath = file["destinationpath"]
        file_id = file["File_id"]
        result = file["result"]
        if sourcepath.startswith("/dbfs/"):
            actual_src_path = sourcepath.replace("/dbfs/", "dbfs:/")
        else:
            # Actual_src_path='dbfs:'+sourcepath
            actual_src_path = sourcepath
            # Destinationpath=dbutils.widgets.get('destpath')
        if destinationpath.startswith("dbfs:"):
            actual_destpath = destinationpath
        else:
            # Actual_destpath='dbfs:'+destinationpath
            actual_destpath = destinationpath
        print("source and destination paths are ", actual_src_path, actual_destpath)
        if result == "Error":
            cmnlogs.fn_add_alerts(
                FNT_ID,
                "File_Validation_Error",
                " " + str(filename),
                job_run_id + "-" + FNT_ID,
                file_id,
            )
        # Moving file from landing to bronze
        dbutils.fs.mv(actual_src_path, actual_destpath, recurse=True)  # noqa: F821
        file1[file_id] = "processed"
    # Updating delta logs after moving file to bronze layer
    cmnlogs.fn_update_delta_logs_newcopy(
        batchfiles,
        job_run_id,
        to_dl_layer=dest_dl_layer,
        copy_activity_status="completed",
    )
    return file1


# COMMAND ----------


# Creates an instance of the class
sqlserver = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-ServerName")  # noqa: F821
sqldatabase = dbutils.secrets.get(scope="datanexus-dev-scope", key="EDA-SQLDB-DBName")  # noqa: F821
spark1 = SparkSession.builder.appName("integrity-tests").getOrCreate()
dest_dl_layer = "Bronze"
source_dl_layer = "Landing"
success_path = "success"
error_path = "error"
suspense_path = "suspense"

# Object for utility function
dbcon = db(sqldatabase, sqlserver, spark1)
dbasecon = dbcon1(
    dbasecon=dbcon,
    sourceName=SourceSystem,
    source_dl_layer=source_dl_layer,
    dest_dl_layer=dest_dl_layer,
    FNT_ID=FNT_ID,
    FileTemplate=FileTemplate,
    job_run_id=job_run_id,
    HierarchyFlag=HierarchyFlag,
    spark=spark1,
    IOTFlag=IOTFlag,
)

path = dbasecon.func_get_paths()
success_destpath = path["Success"]
print("succdestpath---", success_destpath)
error_destpath = path["Error"]
if dest_dl_layer == "Bronze":
    suspense_destpath = path["Suspense"]

# Object creation for retrivelistoffiles
rtfiles = rlf(
    dbasecon,
    dbcon,
    sourceName=SourceSystem,
    source_dl_layer=source_dl_layer,
    dest_dl_layer=dest_dl_layer,
    HierarchyFlag=HierarchyFlag,
    FNT_ID=FNT_ID,
    FileTemplate=FileTemplate,
    job_run_id=job_run_id,
    spark1=spark1,
)
# Object for updating logs
updlogs = ul(
    dbcon,
    sourceName=SourceSystem,
    dest_dl_layer=dest_dl_layer,
    FNT_ID=FNT_ID,
    job_run_id=job_run_id,
    HierarchyFlag=HierarchyFlag,
    FileTemplate=FileTemplate,
    spark1=spark1,
)
# Retrieve the list if files in landing
cmnlogs = cl(
    dbcon,
    sourceName=SourceSystem,
    dest_dl_layer=dest_dl_layer,
    key="FileValidation",
    FNT_ID=FNT_ID,
    job_run_id=job_run_id,
    HierarchyFlag=HierarchyFlag,
    FileTemplate=FileTemplate,
    spark1=spark1,
)
end_date = datetime.now().strftime("%Y-%m-%d %H:00:00")
# end_date='2022-12-19 16:00:00'
print("end_date", end_date)

lst = rtfiles.fn_Retrieve_list_of_files(end_date)
print("Final list is ", lst)
# final_lst=lst.replace("[[","[").replace("]]","]").replace("[],","").replace(",[]","")
# Log the list of files in db
landingtimelogs = dbr(dbcon, FNT_ID, job_run_id)
list_of_fnts = updlogs.fn_log_List_of_Files(lst)
print("list of fnts", list_of_fnts)
print("Length of list_fnts", len(list_of_fnts))

if len(list_of_fnts) > 0:
    pk_file_id = list_of_fnts[0]["PK_file_id"]
    print(pk_file_id)
    # Check for late arrivals
    Arrival_time = landingtimelogs.fn_get_landing_time(pk_file_id)
    expected_landingtime = landingtimelogs.fn_get_file_schema_details()
    fv_flag = expected_landingtime[0]["FV_Needed"]
    print(Arrival_time)
    print(expected_landingtime)
    # Late arriving file
    if int(Arrival_time[0]["TimeDiffinSeconds"]) > int(
        expected_landingtime[0]["Incoming_freqvalue"]
    ):
        # alert
        delay = int(Arrival_time[0]["TimeDiffinSeconds"]) - int(
            expected_landingtime[0]["Incoming_freqvalue"]
        )
        cmnlogs.fn_add_alerts(
            FNT_ID,
            "FILE_LANDED_LATE",
            " The file was delayed by " + str(delay) + " seconds",
            job_run_id + "-" + FNT_ID,
            pk_file_id,
        )
        print("alertsent")

manager = mp.Manager()
return_dict = manager.dict()
n_cores = 2
attributes_all = {}
procs = []
final_list_of_results = {}

# Process and move files in batches
batchsize = dbasecon.fn_get_file_params(FNT_ID)["Batch_Size"]
print("bs--", batchsize)
# batch=len(list_of_fnts)//5

if batchsize == 0:
    batchsize = 10
for value in range(0, len(list_of_fnts), batchsize):
    index1 = value
    print("index1", index1)
    opt = fn_process_files(list_of_fnts[index1: index1 + batchsize])
    # pool=ThreadPool(1)
    # updation_status=pool.map(fn_copyfiles,opt)
    updation_status = fn_copyfiles(opt)

# print(opt)
if HierarchyFlag == "True":
    updlogs.fn_update_filepickup_ts(end_date, FNT_ID)
    print("Timestamp updated for lastpickup field")


# COMMAND ----------


# COMMAND ----------

