# File Validation

This repository contains a set of Python classes designed for the validation and processing of files. The files undergo validation based on attributes like filename, extension, size, resolution, etc., and are subsequently moved to the Bronze Layer once validation is successful. The system also interacts with a database to retrieve and log file information.

## Overview

The file processing system performs several tasks including:

- Retrieving file attributes like size, resolution, creation time, etc.
- Validating files based on predefined rules and criteria.
- Interacting with a database to retrieve paths, attributes, and file information.
- Logging file information and validation results into the database.
- Managing file paths, including retrieving and calculating source and destination paths.
  
## Components

### 1. **f_attribute_retriever.py**
   - **Class:** `AttributeRetriever`
   - **Purpose:** Retrieves various attributes of files including size, creation time, modification time, resolution (image/video), color mode (image), video bitrate, and frame dimensions (video).
   - **Methods:**
     - `fn_get_createdTime`: Retrieves file creation time.
     - `fn_get_modifiedTime`: Retrieves last modified time.
     - `fn_getPath`: Retrieves the absolute file path.
     - `fn_getType`: Retrieves file type/extension.
     - `fn_getSize`: Retrieves file size.
     - `fn_img_resolution`: Retrieves image resolution.
     - `fn_img_colormode`: Retrieves image color mode.
     - `fn_video_duration`: Retrieves video duration.
     - `fn_video_bit_rate`: Retrieves video bitrate.
     - `fn_video_frame_dimension`: Retrieves video frame dimensions.
   - **Usage:** Initialize the class with a file path and a list of attributes to retrieve the file information.

### 2. **f_attribute_validator.py**
   - **Class:** `AttributeValidator`
   - **Purpose:** Validates various attributes of a file based on certain criteria (e.g., size > 0, resolution > 300x300).
   - **Methods:**
     - Validation functions for different attributes like file size, image resolution, video duration, bitrate, etc.
     - `fn_getattributesValidation`: Validates each attribute and returns validation results.
   - **Usage:** Initialize the class with a database connection, attributes, file ID, and FNT ID. Use `fn_getattributesValidation` to validate file attributes.

### 3. **f_db_reader.py**
   - **Class:** `databasereaders`
   - **Purpose:** Retrieves file-related information from the database.
   - **Methods:**
     - `fn_get_hierarchypath`: Retrieves file pickup time and list of paths.
     - `fn_get_list_of_attributes`: Retrieves mapped attributes from the database.
     - `fn_get_landing_time`: Retrieves late-arriving file details.
     - `fn_get_file_schema_details`: Retrieves file schema details.
   - **Usage:** Use this class to interact with the database to fetch file paths, attributes, and schema details.

### 4. **f_log_files.py**
   - **Class:** `updatinglogs`
   - **Purpose:** Logs various file processing information into the database.
   - **Methods:**
     - `fn_log_List_of_Files`: Logs a list of files into the database.
     - `fn_log_attribute_values`: Logs attribute values into the database.
     - `fn_update_attribute_validation`: Updates attribute validation logs.
     - `fn_update_filepickup_ts`: Updates file pickup timestamps.
   - **Usage:** Use this class to log file details and validation results into the database.

### 5. **f_retrieve_listofattributes.py**
   - **Class:** `Retrivelistattributes`
   - **Purpose:** Retrieves and processes file attributes by interacting with the database and using the `AttributeRetriever` class.
   - **Methods:**
     - `fn_file_process_slave_get_attributes`: Extracts attributes and retrieves file attributes.
     - `fn_retrieve_individual_files_Attributes`: Retrieves and prints file attributes.
   - **Usage:** Use this class to retrieve and process file attributes, interacting with the `AttributeRetriever` class.

### 6. **f_retrieve_listoffiles.py**
   - **Class:** `RetriveListofFiles`
   - **Purpose:** Retrieves a list of files from a specified directory, potentially using hierarchical paths, and interacts with the database to get file paths.
   - **Methods:**
     - `fn_Retrieve_list_of_files`: Retrieves a list of files based on the hierarchical flag.
     - `fn_Retrive_list_of_files_hierarchy0`: Retrieves files using hierarchical paths.
     - `fn_Retrieve_list_of_files_hierarchy1`: Retrieves files directly from the root path.
   - **Usage:** Use this class to retrieve a list of files from a specified directory, potentially using hierarchical paths.

### 7. **f_utility_functions.py**
   - **Class:** `Dtbaseconnect`
   - **Purpose:** Interacts with the database to retrieve file paths, list files, and calculate file paths for processing.
   - **Methods:**
     - `cleanNullTerms`: Cleans a dictionary by removing keys with `None` values.
     - `func_get_paths`: Retrieves file paths from the database.
     - `fn_iotfolder`: Retrieves IoT folder details.
     - `fn_get_list_of_paths`: Lists files in a specified path.
     - `fn_get_file_params`: Retrieves file parameters.
     - `fn_calculate_file_path`: Calculates the source and destination paths for a file.
   - **Usage:** Use this class for retrieving file paths and calculating paths for file processing.

### 8. **get_sparkutils.py**
   - **Class:** `get_sparkutils`
   - **Purpose:** Provides functionality related to Spark sessions and utility functions for interacting with the database and files.
   - **Methods:**
     - `get_db_utils`: Initializes dbutils for Spark sessions.
   - **Usage:** Use this class to set up Spark utilities for the processing pipeline.


