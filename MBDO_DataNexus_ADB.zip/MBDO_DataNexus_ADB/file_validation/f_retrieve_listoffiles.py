from f_db_reader import databasereaders
import os
from datetime import datetime


class RetriveListofFiles:
    """This is a class for retrieving list of files."""

    def __init__(
        self,
        dbcon,
        con,
        sourceName,
        source_dl_layer,
        dest_dl_layer,
        HierarchyFlag,
        FNT_ID,
        FileTemplate,
        job_run_id,
        spark1,
    ):
        """Constructor for initializing the RetriveListofFiles class.

        Parameters:
            dbcon : Database connection object.
            con : Database connection object for queries.
            sourceName (str): Source name for the files.
            source_dl_layer (str): Source data layer.
            dest_dl_layer (str): Destination data layer.
            HierarchyFlag (str): Flag indicating if the hierarchy is enabled ("True" or "False").
            FNT_ID (int): File type ID.
            FileTemplate (str): File name template for filtering files.
            job_run_id (str): Unique ID for the job run.
            spark1 : Spark session object.
        """
        self.spark = spark1
        dbutils = self.get_dbutils()
        print(dbutils)
        self.job_run_id = job_run_id
        self.sourceName = sourceName
        self.source_dl_layer = source_dl_layer
        self.dest_dl_layer = dest_dl_layer
        self.HierarchyFlag = HierarchyFlag
        self.FNT_ID = FNT_ID
        self.FileTemplate = FileTemplate
        self.a = dbcon
        self.con = con
        self.dbread = databasereaders(self.con, self.FNT_ID, self.job_run_id)

    def get_dbutils(self):
        """Retrieve the dbutils object for interacting with Databricks filesystem.

        Returns:
            DBUtils: A Databricks utilities object.
        """
        try:
            from pyspark.dbutils import DBUtils

            dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython

            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils

    def fn_Retrieve_list_of_files(self, end_date) -> list:
        """Retrieve a list of files based on the given date and hierarchy flag.

        Parameters:
            end_date (str): The end date for file retrieval.

        Returns:
            list: A list of file details, including name, path, size, and modification time.
        """
        try:

            path = self.a.func_get_paths()
            rootpath = path[self.source_dl_layer]
            self.end_date = end_date
            print("File_listing_path", rootpath)
            print(self.end_date)
            print("hierarchy")
            if self.HierarchyFlag == "True":
                listofjson = self.fn_Retrive_list_of_files_hierarchy0(
                    self.end_date, rootpath
                )
                return listofjson
            else:
                listofnametime = self.fn_Retrieve_list_of_files_hierarchy1(rootpath)
                return listofnametime
        except Exception as e:
            print(e)
            return list()

    def fn_Retrive_list_of_files_hierarchy0(self, endate, rootpath):
        """Retrieve files from a hierarchical directory structure.

        Parameters:
            endate (str): The end date for file retrieval.
            rootpath (str): The root path for file retrieval.

        Returns:
            list: A list of JSON objects representing file paths and details.
        """
        self.end_date = endate
        self.rootpath = rootpath
        list_json = self.dbread.fn_get_hierarchypath(self.end_date, self.rootpath)
        return list_json

    def fn_Retrieve_list_of_files_hierarchy1(self, rootpath):
        """Retrieve files from a flat directory structure.

        Parameters:
            rootpath (str): The root path for file retrieval.

        Returns:
            list: A list of dictionaries containing file names, paths, and creation times.
        """
        dbutils = self.get_dbutils()
        print("root path is", rootpath)
        print("executing dbutils comand")
        fileList = dbutils.fs.ls(rootpath)
        print("done executing dbutils comand")
        print("filelist is", fileList)
        print("file template is", self.FileTemplate)
        listoffiles = []
        for files in fileList:
            if files.name.startswith(self.FileTemplate):
                # listoffiles.append(files)
                listoffiles.append(
                    [
                        files.path.replace("dbfs:", ""),
                        files.name,
                        files.size,
                        files.modificationTime,
                    ]
                )
        list_of_name_time = [
            {
                "CreatedTime": datetime.fromtimestamp(
                    os.path.getctime("/" + str(f[0]).replace(":", ""))
                ).strftime("%Y-%m-%d %H:%M:%S"),
                "FileName": f[1],
                "FilePath": (str(f[0]).replace(":", "")),
            }
            for f in listoffiles
        ]
        print("lst with time and path", list_of_name_time)
        return list_of_name_time
