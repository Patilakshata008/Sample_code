class get_sparkutils:
    """This class provides utility functions for working with Spark in different environments."""

    def __init__(self, spark):
        """
        Initializes the get_sparkutils class.

        Parameters:
            spark (SparkSession): The Spark session to be used for obtaining the dbutils.

        Attributes:
            spark (SparkSession): The Spark session.
            dbutils (DBUtils or None): The dbutils object, initialized based on the environment.
        """
        self.spark = spark
        self.dbutils = sel.get_db_utils()

    def get_db_utils(self):
        """
        Returns the dbutils object based on the environment.

        If the Spark configuration indicates that Databricks is enabled, the `DBUtils` class is imported
        and used to initialize dbutils. Otherwise, it assumes that the environment is Jupyter and retrieves
        `dbutils` from the IPython namespace.

        Returns:
            dbutils (DBUtils or None): The dbutils object for the environment.
        """
        dbutils = None
        if self.spark.conf.get("spark.databricks.service.client.enabled") == "true":

            from pyspark.dbutils import DBUtils

            dbutils = DBUtils(self.spark)

        else:

            import IPython

            dbutils = IPython.get_ipython().user_ns["dbutils"]

        return dbutils
