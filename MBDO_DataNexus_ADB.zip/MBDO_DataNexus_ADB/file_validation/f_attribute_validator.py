

class AttributeValidator:
    """This is a class for validating file attributes."""

    def __init__(self, dbcon, attributes, file_id, FNT_ID):
        """The constructor for AttributeValidator class

        Parameters:
           attributes : File attributes from sql table.
           file_id (string): File_id of the particular file.
        """
        self.FNT_ID = FNT_ID
        self.attributes = attributes
        self.file_id = file_id
        self.a = dbcon
        self.format = self.a.fn_get_file_params(self.FNT_ID)["File_Type"]
        self.function_mapper = {
            "gt_0": self.fn_check_gt_0,
            "Within_domain": self.fn_check_within_domain,
            "within_5_days": self.fn_check_within_5_days,
            "(300,300)": self.fn_check_img_resolution,
            "modes": self.fn_check_imgclr_mode,
            "within_dim": self.fn_check_vd_dimension,
            "duration_gt_0": self.fn_check_vd_duration,
            "bit_gt_0": self.fn_check_vd_bitrate,
        }

    def fn_check_gt_0(self, value):
        """
        The function to check size of the file.

        Parameters:
            value(int): Size of the file.

        Returns:
            Returns Boolean value.
        """
        print("size is", value)
        return int(value) > 0

    def fn_check_within_domain(self, value):
        """
        The function to check file format.

        Parameters:
            value (string):format of the file.

        Returns:
            Boolean value.
        """
        print("selfformat", self.format)
        print("other is", value)
        domain = [
            ".csv",
            ".txt",
            ".json",
            ".xml",
            ".parquet",
            ".jpg",
            ".jpeg",
            ".png",
            ".tif",
            "mp4",
            "mp3",
            "avi",
            ".pdf"
        ]
        print(domain)
        return value == "." + self.format

    def fn_check_within_5_days(self, value):
        """
        The function to check file inserted within 5 days.

        Parameters:
            value(ComplexNumber): File inserted time.

        Returns:
            True - if file inserted within 5 days.
        """
        print(value)
        from datetime import datetime, timedelta

        time_between_insertion = datetime.now() - timedelta(days=5)
        print(time_between_insertion)
        return True

    def fn_check_img_resolution(self, value):
        """
        Checks if the resolution of an image is greater than or equal to 300x300 pixels.

        Takes a string value representing the resolution of an image (in the format 'width,height'),
        converts it to a tuple, and compares it to the threshold resolution (300, 300).

        Args:
            value (str): The resolution of the image in 'width,height' format (e.g., '1024,768').

        Returns:
            bool: True if the resolution is greater than or equal to (300, 300), else False.
        """
        print(value)
        print(type(value))
        value = value[1:len(value) - 1]
        x = list(map(int, value.split(",")))
        return tuple(x) >= (300, 300)

    def fn_check_imgclr_mode(self, value):
        """
        Checks if the image color mode is valid.

        Validates if the given image color mode is one of the supported modes.

        Args:
            value (str): The color mode of the image (e.g., 'RGB', 'RGBA').

        Returns:
            bool: True if the color mode is valid, else False.
        """
        print(value)
        mode = ["L", "RGBA", "HSB", "RGB", "CMYK", "Grey scale", "Bitmap"]
        if value in mode:
            return True
        else:
            return False

    def fn_check_vd_duration(self, value):
        """
        Checks if the video duration is greater than 0.

        Verifies if the video duration provided is greater than zero.

        Args:
            value (str): The duration of the video in seconds.

        Returns:
            bool: True if the video duration is greater than 0, else False.
        """
        print("video duration is", value)
        return int(value) > 0

    def fn_check_vd_bitrate(self, value):
        """
        Checks if the video bitrate is greater than 0.

        Verifies if the video bitrate provided is greater than zero.

        Args:
            value (str): The bitrate of the video in kbps.

        Returns:
            bool: True if the bitrate is greater than 0, else False.
        """
        print("bitrate", value)
        return int(value) > 0

    def fn_check_vd_dimension(self, value):
        """
        Checks if the video frame dimensions are greater than (1000, 1000).

        Takes a string value representing the video frame dimensions (in the format 'width,height'),
        converts it to a tuple, and compares it to the threshold frame dimension (1000, 1000).

        Args:
            value (str): The frame dimensions of the video in 'width,height' format (e.g., '1280,720').

        Returns:
            bool: True if the frame dimensions are greater than (1000, 1000), else False.
        """
        print("Frame dimension", value)
        value = value[1:len(value) - 1]
        x = list(map(int, value.split(",")))
        return tuple(x) > (1000, 1000)

    def fn_getattributesValidation(self):
        """
        The function to validate file attributes.

        Parameters:0

        Returns:
             check results and list of details
        """
        subresult = {}

        list_of_details = []
        for b1 in self.attributes:
            details = {}
            if b1["Validation_Needed"]:
                print(b1["Validation_Type"])
                print(b1["File_Attribute_Value"])
                res = self.function_mapper[b1["Validation_Type"]](
                    b1["File_Attribute_Value"]
                )
                subresult[b1["FK_File_Attribute_Id"]] = res
                details["FK_File_Attribute_Id"] = b1["FK_File_Attribute_Id"]
                details["File_id"] = self.file_id
                details["validation_status"] = res
                list_of_details.append(details)
        result = all(subresult.values())
        return result, list_of_details
