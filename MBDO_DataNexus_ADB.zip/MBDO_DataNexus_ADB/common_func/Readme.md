# common_func
## Overview

The `common_func` module provides functionalities for connecting to a database and logging file processing activities in an Azure SQL database.

1. **Database Connection (`f_database_connect.py`)**: Facilitates securely connecting to an Azure SQL database using a service principal for authentication.
2. **Logging (`f_logs.py`)**: Provides methods for logging and updating file processing activities in the database.

## Table of Contents

- [Overview](#overview)
- [Usage](#usage)
  - [Database Connection](#database-connection)
  - [Logging Functions](#logging-functions)
- [Dependencies](#dependencies)
- [Contributing](#contributing)
- [License](#license)

## Usage

### Database Connection (`f_database_connect.py`)

The `DBconnection` class enables a secure connection to an Azure SQL database using service principal credentials. It retrieves the necessary secrets from Databricks secret scope and uses the Microsoft Authentication Library (MSAL) to authenticate and acquire an OAuth2 access token.

#### Class: `DBconnection`

- **Constructor (`__init__`)**:
  - Initializes the class with the following parameters:
    - `database`: The name of the Azure SQL database.
    - `server`: The name of the SQL server.
    - `spark`: The Spark session object to create a JDBC connection.

- **Method: `get_dbutils`**:
  - Retrieves the `dbutils` utility for accessing Databricks secrets.

- **Method: `fn_get_connection`**:
  - Retrieves the tenant ID, client ID, and client secret from Databricks secret scope.
  - Constructs the JDBC URL for the SQL server.
  - Uses MSAL to acquire an OAuth2 access token.
  - Sets up connection properties using the access token.
  - Creates a JDBC connection to the SQL server using Spark's JVM gateway.

#### Example Usage:

```python
from f_database_connect import DBconnection

# Initialize DBconnection class
db_connection = DBconnection(database="your_database", server="your_server", spark=spark)

# Get dbutils (Databricks utility object)
dbutils = db_connection.get_dbutils()

# Establish the connection
conn = db_connection.fn_get_connection()
