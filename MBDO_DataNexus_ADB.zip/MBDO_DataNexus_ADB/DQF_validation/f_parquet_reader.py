from f_utility_functions import *
from pyspark.sql.functions import explode_outer,col
import pyspark.sql.functions as sf
class parquetreader:
    def __init__(self,header,spark,schema):
        """
            Initializes the class with the given header and Spark session.

            This constructor initializes the object with the provided header configuration and Spark session.
            The header is used to determine if the data files include a header row, and the Spark session 
            is required for processing the data within the class.

            Args:
                header (bool): A flag indicating whether the data files contain a header row.
                spark (SparkSession): The Spark session used for data processing.

            Attributes:
                header (bool): The flag indicating if data files contain a header row.
                spark (SparkSession): The Spark session used for processing data.
        """

        self.header=header
        self.spark=spark
        self.schema=schema
        
    def flatten_df(self, nested_df):
        """
            Flattens a nested DataFrame by extracting nested fields and appending them as new columns.

            This method takes a DataFrame with nested structures and flattens it by creating new columns 
            for each field inside the nested structs, while preserving the original columns. The new columns 
            are named by concatenating the parent column name with the nested field name.

            Args:
                nested_df (DataFrame): A DataFrame that may contain nested structures (struct types) 
                                        to be flattened.

            Returns:
                DataFrame: A new DataFrame where the nested structs are flattened, and the original 
                        and nested fields are represented as separate columns.
        """

        flat_cols = [c[0] for c in nested_df.dtypes if c[1][:6] != 'struct']
        nested_cols = [c[0] for c in nested_df.dtypes if c[1][:6] == 'struct']
        flat_df = nested_df.select(flat_cols +
                                [sf.col(nc+'.'+c).alias(nc+'_'+c)
                                    for nc in nested_cols
                                    for c in nested_df.select(nc+'.*').columns])
        return flat_df
    
    def fn_get_schema(self, columns):
        """
        Constructs a schema definition for valid data based on column configurations.

        Args:
            columns (list): List of dictionaries representing column configurations.

        Returns:
            str: Schema string for valid data.
        """
        schema = ""
        for i in range(len(columns)):
            if len(columns) == 1 or i == len(columns) - 1:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                )
            else:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                    + ","
                )

        return schema
    
    def fn_read_parquet(self,filepath):
        """
            Reads a Parquet file into a DataFrame.

            This method reads a Parquet file from the specified file path and returns the data as a 
            Spark DataFrame. The header parameter is used to specify whether the file has a header.

            Args:
                filepath (str): The path to the Parquet file to be read.

            Returns:
                DataFrame: A DataFrame containing the data from the Parquet file.
        """

        header='true' if self.header==True else 'false'
        schema = self.schema 
        final_schema = self.fn_get_schema(schema)
        print('file path is',filepath)
        data=self.spark.read.schema(final_schema).parquet(*filepath)
        return data
    
    def db_1(self,filepath):
        """
            Reads a Parquet file into a DataFrame.

            This method reads a Parquet file from the specified file path and returns the data as a 
            Spark DataFrame. The header parameter is used to specify whether the file has a header.

            Args:
                filepath (str): The path to the Parquet file to be read.

            Returns:
                DataFrame: A DataFrame containing the data from the Parquet file.
        """

        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        return data
    
    def api_1_109(self,filepath):
        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        return data
    
    def api_4_113(self,filepath):
        """
            Reads a Parquet file into a DataFrame.

            This method reads a Parquet file from the specified file path and returns the data as a 
            Spark DataFrame. The header parameter is used to specify whether the file has a header.

            Args:
                filepath (str): The path to the Parquet file to be read.

            Returns:
                DataFrame: A DataFrame containing the data from the Parquet file.
        """
        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        return data
    
    def api_7_115(self,filepath):
        """
            Reads a Parquet file into a DataFrame.

            This method reads a Parquet file from the specified file path and returns the data as a 
            Spark DataFrame. The header parameter is used to specify whether the file has a header.

            Args:
                filepath (str): The path to the Parquet file to be read.

            Returns:
                DataFrame: A DataFrame containing the data from the Parquet file.
        """
        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        return data
    
    def api_3_112(self,filepath):
        """
                Reads a Parquet file, then explodes nested fields into separate rows.

                This method reads a Parquet file from the specified file path and processes the nested 
                fields `counties` and `types` by exploding them into separate rows. It returns a DataFrame 
                where these nested fields are flattened, with each element in the arrays represented 
                as individual rows.

                Args:
                    filepath (str): The path to the Parquet file to be read.

                Returns:
                    DataFrame: A DataFrame containing the exploded nested fields `counties` and `types`.
        """

        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        data1=data.withColumn("counties", explode_outer(data.counties)).withColumn("types", explode_outer(data.types))
        return data1
    
    def api_6_114(self,filepath):
        """
            Reads a Parquet file, then explodes the nested field `exp` into separate rows.

            This method reads a Parquet file from the specified file path and processes the nested 
            field `exp` by exploding it into separate rows. It returns a DataFrame where the nested 
            field is flattened, with each element in the array represented as an individual row.

            Args:
                filepath (str): The path to the Parquet file to be read.

            Returns:
                DataFrame: A DataFrame containing the exploded nested field `exp`.
        """

        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        data1=data.withColumn("exp", explode_outer(data.exp))
        return data1
    
    def api_9_116(self,filepath):
        """
                Reads a Parquet file, explodes the nested field `images`, and flattens the DataFrame.

                This method reads a Parquet file from the specified file path, processes the nested 
                field `images` by exploding it into separate rows, and then flattens the resulting 
                DataFrame. It returns a DataFrame where the `images` field is exploded, and any nested 
                structures are flattened into separate columns.

                Args:
                    filepath (str): The path to the Parquet file to be read.

                Returns:
                    DataFrame: A DataFrame where the `images` field is exploded and the resulting 
                            nested structure is flattened into separate columns.
        """
        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        data1=data.withColumn("images", explode_outer(data.images))
        data2 = self.flatten_df(data1)
        return data2
    
    def api_8_117(self,filepath):
        """
            Reads a Parquet file, explodes the `holidays` field, and flattens the DataFrame twice.

            This method reads a Parquet file from the specified file path, processes the nested 
            field `holidays` by exploding it into separate rows, and flattens the resulting 
            DataFrame twice to extract all nested fields. It also explodes the nested `type` field 
            and flattens the structure into separate columns.

            Args:
                filepath (str): The path to the Parquet file to be read.

            Returns:
                DataFrame: A DataFrame where the `holidays` and `type` fields are exploded, and 
                        all nested structures are flattened into separate columns.
        """

        header='true' if self.header==True else 'false'
        print('file path is',filepath)
        data=self.spark.read.parquet(*filepath)
        data2=data.selectExpr("*","explode(holidays)").select("*","col.*").drop("holidays","col")
        data2 = data2.withColumn("type", explode_outer(col("type")))
        data2=self.flatten_df(data2)
        data2=self.flatten_df(data2)
        return data2