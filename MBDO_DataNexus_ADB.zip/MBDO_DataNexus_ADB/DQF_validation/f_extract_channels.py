# Create a Class for loading specific Channel with samples and timestamp
from asammdf import MDF
import io
import sys

class ChannelExtractor():
    def __init__(self, channel):
            """
    Initializes an instance with a specified channel.

    This constructor method initializes an instance of the class with a given channel 
    that can be used for subsequent operations, such as communication or data processing.

    Args:
        channel (str): The channel used for communication or processing. This can 
                        be an identifier for a specific channel.

    """

        self.channel = channel

    # Extracts Timestamp
    def extractChannelTimestamp(self, val):
            """
    Extracts the timestamps for a specific channel from the MDF file.

    This method extracts the timestamps associated with the specified channel from 
    an MDF (Measurement Data Format) file. The MDF file is provided as a byte stream.

    Args:
        val (bytes): A byte stream representing the contents of an MDF file.

    Returns:
        list: A list of timestamps associated with the specified channel in the MDF file.
    """
        print('val',val)
        file_stream = io.BytesIO(val)
        mdf = MDF(file_stream)
        mdf_one_channel = mdf.get(self.channel)
        return mdf_one_channel.timestamps

    # Extracts  Values/Samples
    def extractChannelValues(self, val):
            """
    Extracts the sample values for a specific channel from the MDF file.

    This method extracts the sample values associated with the specified channel from 
    an MDF (Measurement Data Format) file. The MDF file is provided as a byte stream.

    Args:
        val (bytes): A byte stream representing the contents of an MDF file.

    Returns:
        list: A list of sample values associated with the specified channel in the MDF file.
    """
        file_stream = io.BytesIO(val)
        mdf = MDF(file_stream)
        mdf_one_channel = mdf.get(self.channel)

        return mdf_one_channel.samples