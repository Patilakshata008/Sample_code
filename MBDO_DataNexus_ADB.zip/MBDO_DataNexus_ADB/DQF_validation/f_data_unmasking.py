from pyspark.sql.functions import udf,rand
from pyspark.sql import functions as f
from pyspark.sql.types import StringType
from cryptography.fernet import Fernet
import random
import json

class Data_unmasking:
  def __init__(self,config,spark1):
    """
        Initializes the class with the provided configuration and Spark session.

        This method initializes the class with the given configuration dictionary and 
        sets up essential properties, including the schema, Spark context, FNT ID, and 
        Delta Lake configuration. It also loads the schema into a DataFrame for further use 
        and sets up the database connection details.

        Args:
            config (dict): A dictionary containing the configuration details, including 
                          schema, file read configurations, Delta Lake configurations, 
                          and other settings.
            spark1 (SparkSession): A Spark session instance to interact with Spark.

        Attributes:
            config (dict): The configuration dictionary passed during initialization.
            schema (list): The schema details extracted from the configuration.
            spark (SparkSession): The Spark session passed during initialization.
            sc (SparkContext): The Spark context associated with the provided Spark session.
            FNT_ID (str): The FNT ID extracted from the configuration.
            schema_df (DataFrame): A DataFrame created from the schema to be used for processing.
            dbutils (object): A utility to interact with Databricks features.
            databasename (str): The database name for Delta Lake extracted from the configuration.
            tablename (str): The table name for Delta Lake extracted from the configuration.
    """
    self.config=config
    self.schema=self.config['schema']
    self.spark=spark1
    self.sc=self.spark.sparkContext
    self.FNT_ID=self.config['file_read_configs']['FNT_Id']
    self.schema_df=self.spark.read.json(self.sc.parallelize([json.dumps(self.schema)]))
    self.dbutils=self.get_dbutils()
    self.databasename=config['deltalake_configs']['DbName']
    print(self.databasename)
    self.tablename=config['deltalake_configs']['TabelName']
    print(self.tablename)

    
  def get_dbutils(self):
    """
        Retrieves the Databricks utilities (dbutils) object.

        This method attempts to import and return the Databricks utilities (`dbutils`) object 
        for interacting with Databricks-specific functionalities such as secrets, file system 
        operations, and jobs. It checks if the `pyspark.dbutils` module is available, and if 
        not, falls back to using `IPython` to retrieve the object from the current namespace.

        Returns:
            dbutils (object): The Databricks utilities object for interacting with Databricks 
                              services like secrets, widgets, and file system.
    """

        try:
            from pyspark.dbutils import DBUtils
            dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython
            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils
  
  @staticmethod
  def decrypt_val(cipher_text,MASTER_KEY):
    """
            Decrypts an encrypted value using the provided master key.

            This method takes an encrypted string (`cipher_text`) and decrypts it using the 
            specified `MASTER_KEY` with the `Fernet` symmetric encryption algorithm.

            Args:
                cipher_text (str): The encrypted value as a string.
                MASTER_KEY (str): The master key used for decryption. It should be a valid Fernet key.

            Returns:
                str: The decrypted (clear) value as a string.

            Raises:
                InvalidToken: If the `cipher_text` is invalid or has been tampered with.
    """
    f = Fernet(MASTER_KEY)
    clear_val=f.decrypt(cipher_text.encode()).decode()
    return clear_val

  def data_mask(self):
    """
        The function to apply data masking on columns based on schema configuration.

        Parameters:
            schema_df: DataFrame containing the schema with columns marked as maskable.
            FNT_ID: Filename Template Id to generate the encryption key.
            dbutils: Utility to access secrets in Databricks.
            databasename: Name of the database where the table resides.
            tablename: Name of the table to be masked.
            
        Returns:
            DataFrame: A DataFrame containing the columns with the applied maskings, such as encryption.

    """
    mask_dict=self.schema_df.filter("Is_Maskable=1").select('Expected_Columnname','Mask_value').rdd.collectAsMap()
    column=self.schema_df.filter("Is_Maskable=1").select('Expected_Columnname').rdd.flatMap(lambda x: x).collect()
    for columns,maskval in mask_dict.items():

        if maskval=='Encryption':
            #encrypt = f.udf(self.mask_encrypt_func, StringType())
            fernetkey="fernet-key-"+self.FNT_ID
            encryptionKey = self.dbutils.preview.secret.get(scope = "fof-prd-scope", key = fernetkey)
            
            sqlContext.udf.register("decrypt",Data_unmasking.decrypt_val, StringType())
            decrypt_df=spark.sql("select m.*,decrypt(df['columns'], '"+EncryptionKey+"')as '"+columns+"' from  '"+self.databasename+"'.'"+self.tablename+"' m")
            decrypt_df.createOrReplaceTempView("decryptedtable")  
    return decrypt_df
  
  
 
