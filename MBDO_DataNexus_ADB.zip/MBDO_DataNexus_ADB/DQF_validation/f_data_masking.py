from pyspark.sql.functions import udf,rand
from pyspark.sql import functions as f
from pyspark.sql.types import StringType
from cryptography.fernet import Fernet
import random
import json

class Data_masking:
  def __init__(self,gooddf,config,spark1):
      """
      Initializes the object with the provided data and configurations.

      This constructor method sets up the initial state of the class, initializing essential attributes
      like `gooddf`, `config`, and `spark` for processing data, as well as setting up various UDFs 
      for data masking and encryption.

      Args:
          gooddf (DataFrame): The DataFrame containing the good data to be processed.
          config (dict): The configuration dictionary containing relevant settings, schema, and file read configurations.
          spark1 (SparkSession): The active SparkSession object used for Spark operations.

      Initializes the following attributes:
          gooddf (DataFrame): The DataFrame passed as an argument.
          config (dict): The configuration dictionary passed as an argument.
          schema (list): The schema for the data, extracted from the `config` dictionary.
          spark (SparkSession): The active Spark session.
          sc (SparkContext): The SparkContext from the `spark` session.
          FNT_ID (str): The FNT ID from the `file_read_configs` section of the `config` dictionary.
          schema_df (DataFrame): A DataFrame containing the schema information in JSON format.
          dbutils: Utility methods for interacting with Databricks, initialized by calling `get_dbutils()`.
          mask_func1 (UserDefinedFunction): A UDF for applying token masking, defined by `Data_masking.mask_token_func`.
          mask_encrypt (UserDefinedFunction): A UDF for applying encryption masking, defined by `Data_masking.mask_encrypt_func`.
          mask_scrumble (UserDefinedFunction): A UDF for applying scrambling masking, defined by `Data_masking.mask_scrumbling`.

      Raises:
          Exception: If any issue arises during the initialization of the Spark session or UDFs.
      """
      self.gooddf=gooddf
      self.config=config
      self.schema=self.config['schema']
      self.spark=spark1
      self.sc=self.spark.sparkContext
      self.FNT_ID=self.config['file_read_configs']['FNT_Id']
      self.schema_df=self.spark.read.json(self.sc.parallelize([json.dumps(self.schema)]))
      self.dbutils=self.get_dbutils()
      
      self.mask_func1=f.udf(Data_masking.mask_token_func,StringType())
      self.mask_encrypt=f.udf(Data_masking.mask_encrypt_func,StringType())
      self.mask_scrumble=f.udf(Data_masking.mask_scrumbling,StringType())
      
  def get_dbutils(self):
      """
        Retrieves the Databricks utilities (dbutils) for interacting with Databricks notebooks.

        This method checks if the `DBUtils` module is available from `pyspark.dbutils` and initializes
        it using the provided Spark session. If the module is not available (e.g., in a non-Databricks 
        environment), it attempts to access `dbutils` from the IPython user namespace.

        Returns:
            dbutils: An instance of the `DBUtils` class, which provides utility methods for interacting 
                    with Databricks features like file systems, secrets, widgets, and more.

        Raises:
            ImportError: If neither the `pyspark.dbutils` module nor `dbutils` from the IPython namespace 
                          can be found in the current environment.
      """
      try:
          from pyspark.dbutils import DBUtils
          dbutils = DBUtils(self.spark)
      except ImportError:
          import IPython
          dbutils = IPython.get_ipython().user_ns["dbutils"]
      return dbutils
      
  @staticmethod
  def mask_token_func(colVal):
      """
        Masks a portion of the input string by replacing characters from the 3rd to the 8th position 
        with the letter 'x'.

        This function takes an input string (`colVal`), converts it into a list of characters, 
        and then modifies the characters from index 2 (3rd character) to index 7 (8th character) by 
        replacing them with six 'x' characters. The modified list is then joined back into a string 
        and returned.

        Args:
            colVal (str): The input string to be masked. It should be a string with at least 8 characters.

        Returns:
            str: The masked version of the input string, with characters at positions 3 through 8 replaced 
                by 'x'.

        Example:
            >>> mask_token_func("ABCDEFGH")
            'ABxxxxGH'

        Note:
            - If the input string is shorter than 8 characters, the function will mask as many characters
              as possible from index 2 onwards, without causing an error.
            - If the input string is empty or None, the function will return an empty string.
      """
      charList=list(colVal)
      charList[2:8]='x'*6
      return "".join(charList)

  @staticmethod
  def mask_encrypt_func(clear_text,MASTER_KEY):
      """
        Encrypts the input string using the provided encryption key with the Fernet algorithm.

        This function takes a string (`clear_text`) and encrypts it using the symmetric Fernet encryption 
        scheme. The encryption key (`MASTER_KEY`) is required to perform the encryption, and the 
        resulting encrypted string (ciphertext) is returned.

        Args:
            clear_text (str): The string to be encrypted.
            MASTER_KEY (str): The encryption key to use for the Fernet encryption. It should be a valid
                              key generated using the Fernet library.

        Returns:
            str: The encrypted version of the input string, encoded as an ASCII string.

        Example:
            >>> master_key = Fernet.generate_key()
            >>> mask_encrypt_func("HelloWorld", master_key)
            'gAAAAABg...'

        Note:
            - The input `clear_text` must be a valid UTF-8 string.
            - The `MASTER_KEY` should be kept secret and secure.
            - This function assumes that `MASTER_KEY` is a valid Fernet key and does not handle key
              validation or generation.
      """     
      f = Fernet(MASTER_KEY)
      clear_text_b=bytes(clear_text, 'utf-8')
      cipher_text = f.encrypt(clear_text_b)
      cipher_text = str(cipher_text.decode('ascii'))
      return cipher_text
  
  @staticmethod
  def mask_scrumbling(colval):
        """
        Scrambles the characters of the input string by randomly shuffling them.

        This function takes an input string (`colval`), converts it to a list of characters, and 
        randomly shuffles the order of those characters. It then joins the shuffled characters 
        back into a string and returns the result.

        Args:
            colval (str): The string whose characters need to be scrambled.

        Returns:
            str: The scrambled version of the input string, with characters shuffled randomly.

        Example:
            >>> mask_scrumbling("HelloWorld")
            'lWlroHelo'

        Note:
            - The function uses the `random.shuffle` method, which alters the list in place.
            - The result will vary each time the function is called because of the random nature of shuffling.
            - The input `colval` must be a string, and an empty string will be returned if the input is empty.
        """
        strlist=list(colval)
        random.shuffle(strlist:=strlist)
        return "".join(strlist)

  def data_mask(self):
        """
        Applies data masking transformations to specified columns of the DataFrame.
    
        This function takes a DataFrame (`gooddf`) and masks specific columns based on their 
        configuration from the schema. The columns to be masked are identified by the `Is_Maskable` flag 
        in the schema, and each column's masking type is specified by the `Mask_value`. Depending on 
        the masking type, the function applies one of the following transformations:
        - **Token masking**: Replaces part of the string with a 'x' (for example, for credit card or phone numbers).
        - **Encryption**: Encrypts the value using a `Fernet` encryption key.
        - **Shuffling**: Randomly shuffles the characters of the value.
        - **Constant value**: Replaces the column value with a constant specified in the `Mask_value`.
    
        Args:
            None
    
        Returns:
            pyspark.sql.DataFrame: A DataFrame with masked columns.
    
        Example:
            >>> df_masked = data_mask()
            >>> df_masked.show()
    
        Note:
            - The function uses `mask_token_func`, `mask_encrypt_func`, and `mask_scrumbling` for the different masking types.
            - It requires access to `dbutils` for encryption key retrieval.
            - The function assumes that the schema includes an `Is_Maskable` column with values indicating whether 
              a column can be masked and a `Mask_value` column indicating the type of masking.
            - The function works in-place, modifying the `gooddf` DataFrame.
            - After applying the masking, the original column is dropped and replaced with the masked column.
        """    
        mask_dict=self.schema_df.filter("Is_Maskable=1").select('Expected_Columnname','Mask_value').rdd.collectAsMap()
        column=self.schema_df.filter("Is_Maskable=1").select('Expected_Columnname').rdd.flatMap(lambda x: x).collect()
        df1=self.gooddf
        for columns,maskval in mask_dict.items():

            df=df1.select(f.col('id'),f.col(columns))
            display(df)
            if maskval=='Token':
                df_masked=df.withColumn("masked_column",self.mask_func1(df[columns]))
                df_masked=df_masked.drop(columns).withColumnRenamed("masked_column",columns)
                display(df_masked)
            elif maskval=='Encryption':
                fernetkey="fernet-key-"+self.FNT_ID
                encryptionKey = self.dbutils.preview.secret.get(scope = "fof-prd-scope", key = fernetkey)
                df_masked = df.withColumn("masked_column", self.mask_encrypt(df[columns],f.lit(encryptionKey)))
                df_masked=df_masked.drop(columns).withColumnRenamed("masked_column",columns)
            elif maskval=='Shuffling':
                df_masked=df.withColumn("masked_column",self.mask_scrumble(df[columns]))
                df_masked=df_masked.drop(columns).withColumnRenamed("masked_column",columns)

            else:
                df_masked = df.withColumn("masked_columns", f.lit(maskval).cast(StringType()))
                df_masked=df_masked.drop(columns).withColumnRenamed("masked_columns",columns)
            df1=df1.drop(columns)
            df1=df1.join(df_masked, df1.id == df_masked.id, "left_outer").drop(df_masked.id)
        df1.show()    
        return df1
  
  
 
