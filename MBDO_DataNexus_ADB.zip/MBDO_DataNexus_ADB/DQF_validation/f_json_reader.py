from f_utility_functions import *
from pyspark.sql import SparkSession
class jsonreader:
    def __init__(self,schema_df,IOTFlag):
        """
            Initializes the class with schema and IOT flag.
            This constructor initializes the class with a given schema DataFrame and an IOT flag, 
            which can be used for processing and determining how data is handled or processed based 
            on the schema and IOT configuration.
            Args:
                schema_df (DataFrame): The schema DataFrame containing metadata information about 
                                        the structure and columns expected in the data.
                IOTFlag (bool): A flag indicating whether the data processing is related to IOT data 
                                or not. This can be used for conditionally processing IOT-related data.
        """

        self.schema_df=schema_df
        self.IOTFlag=IOTFlag
        
    def fn_iot_json(self,filepath,string):
        """
            Processes and extracts data from an IoT-related JSON file.
  
            This function reads the contents of a given JSON file, processes it by splitting and 
            restructuring the content based on IoT message patterns, and returns a DataFrame 
            with the relevant fields extracted from the 'Body' section of the message.
  
            Args:
                filepath (str): The path to the IoT JSON file to be processed.
                string (str): A prefix string that will be added to the column names of the extracted 
                              fields from the JSON file.
  
            Returns:
                DataFrame: A DataFrame containing the extracted and flattened JSON fields from the 
                          'Body' section, with the prefix string added to the column names.
        """
        vals=sc.wholeTextFiles(filepath).values().flatMap(lambda a:['{"EnqueuedTimeUtc":'+val if i>0 else val for i,val in enumerate(a.split('\r\n{"EnqueuedTimeUtc":'))])
        df=spark.read.json(vals)
        data = vals.first()
        BodyMessage=data.split("Body",1)[1] 
        cols_list=BodyMessage.replace('":{',"{").replace("}}","}")
        print(f'file path is',filepath)

        dictionary = ast.literal_eval(cols_list)
        body_columns=dictionary.keys()
        df_columns=list(body_columns)
        appended_cols = [string+"."+x for x in df_columns]

        df_json=df.select(appended_cols)
        return df_json
        
    
    def fn_readjson(self,filepath):
        """
            Reads and processes JSON files, handling both IoT and non-IoT scenarios.

            This function checks the flag indicating whether the file is an IoT file or not.
            - For IoT files, it uses the `fn_iot_json` method to extract and process the 'Body' part of the JSON.
            - For non-IoT files, it processes the JSON data with the appropriate transformations such as exploding nested fields and applying schema-based transformations.

            Args:
                filepath (str): The path to the JSON file to be read and processed.

            Returns:
                DataFrame: A DataFrame with the processed data from the JSON file, either extracted from the IoT message body or transformed based on the schema.
        """

        filepath=filepath.replace('/dbfs/','/')
        if self.IOTFlag=='True':
            string='Body'
            df=self.fn_iot_json(filepath,string)
            return df
        else: 
            df = spark.read.option('multiline','True').json(filepath)

            list_of_cols_explode=self.schema_df.filter("operation='explode'").select('query')
            print('list of cols to explode is',list_of_cols_explode.show())
            if list_of_cols_explode.count()>0:
                for col in list_of_cols_explode.toPandas().iterrows():
                    print('isnide explode col is',col)
                    print(col[1]['query'])
                    transformed=df.withColumn(col[1]['query'],explode(col[1]['query']))
            else:
                transformed=df

          #lets create a dynamic select expression based on schema file

            new_schema_df=self.schema_df.filter("operation!='explode'")
            expr=[str(a[9]+" as "+a[0]) for a in new_schema_df.toPandas().values]
            complexnewdf=transformed.selectExpr(expr)

            return complexnewdf