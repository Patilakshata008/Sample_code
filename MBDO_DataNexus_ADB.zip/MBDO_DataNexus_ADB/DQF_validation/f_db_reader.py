class Dbreader:
    def __init__(self,dbcon):
        """
            Initializes the class with a database connection.

            This constructor initializes the object with a given database connection 
            and assigns it to the `con` attribute for further database operations.

            Args:
                dbcon (object): A database connection object, typically used to interact with the database.
        """

        self.con=dbcon
    
    def fn_get_tags_xml(self,fnt_id):
        """
            Fetches XML tags from the database for a specific `fnt_id`.

            This method executes a stored procedure in the database to retrieve XML tags associated 
            with the given `fnt_id`. It processes the result set and stores the retrieved values in 
            a dictionary.

            Args:
                fnt_id (int): The function ID used to query the XML tags.

            Returns:
                list: A list of dictionaries containing the fetched XML tag data. The dictionary is 
                    populated with the tag values retrieved from the result set.
                    
            Raises:
                Exception: If there is any error during the database execution, the exception is 
                        caught and printed.
        """

        try:
            statement = f"""EXEC dbo.sp_get_xmltags @fntid={fnt_id}"""
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            resultSet=exec_statement.getResultSet()
            result_dict=[]
            while (resultSet.next()):
                vals={}
                result_dict.append(vals)
                # Close connections
            exec_statement.close()
                #self.con.close()
            return result_dict
        except Exception as e:
            print(e)
           
    def fn_get_files_for_dqf(self,fnt_id):
        """
            Fetches files for Data Quality Framework (DQF) based on the provided `fnt_id`.

            This method executes a stored procedure to retrieve files associated with a specific 
            `fnt_id` from the database. The result set is processed to extract relevant information 
            such as `Tracking_Id`, `To_DL_Layer`, `FNT_Id`, `job_run_id`, and `File_Id`, which are 
            returned in a list of dictionaries.

            Args:
                fnt_id (str): The function ID used to query the files for DQF.

            Returns:
                list: A list of dictionaries containing the retrieved file information for DQF. Each 
                    dictionary contains the following keys:
                        - `Tracking_Id`: The tracking ID of the file.
                        - `To_DL_Layer`: The target data layer for the file.
                        - `FNT_Id`: The function ID associated with the file.
                        - `job_run_id`: The job run ID associated with the file.
                        - `File_Id`: The file ID.

            Raises:
                Exception: If there is any error during the database execution, the exception is 
                        caught and printed.
        """

        try:
            statement = f"""EXEC dbo.sp_get_files_for_dqf @fntid='{fnt_id}'"""
            print("Statement is ",statement)
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            resultSet=exec_statement.getResultSet()
            result_dict=[]
            while (resultSet.next()):
                vals={}
                vals['Tracking_Id']=resultSet.getString('Tracking_Id')
                vals['To_DL_Layer']=resultSet.getString('To_DL_Layer')
                vals['FNT_Id']=resultSet.getString('FNT_Id')
                vals['job_run_id']=resultSet.getString('job_run_id')
                vals['File_Id']=resultSet.getString('FK_File_Id')

                result_dict.append(vals)
              # Close connections
            exec_statement.close()
              #self.con.close()
            return result_dict
        except Exception as e:
            print(e)
            
    def fn_get_no_columns_new(self,fntid):
        """
                Fetches the total number of columns for the specified function ID (`fntid`).

                This method executes a stored procedure to retrieve the total number of columns 
                associated with the given `fntid` from the database. The result is returned as an 
                integer representing the total number of columns.

                Args:
                    fntid (str): The function ID used to query the number of columns.

                Returns:
                    int: The total number of columns associated with the given `fntid`.

                Raises:
                    Exception: If there is any error during the database execution, the exception is 
                            caught and printed.
        """
        try:
            statement= f"""EXEC [dbo].[sp_get_no_columns_new] @fntid={fntid}"""

            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            resultSet=exec_statement.getResultSet()
            while (resultSet.next()):
                result_dict=resultSet.getInt('Total_columns')
            exec_statement.close()
            return result_dict
        except Exception as e:
            print(e)
            
    def fn_get_no_rows(self,Tracking_id,fnt_id):
        """
            Fetches the aggregated row count for a specific tracking ID and function ID (`fnt_id`).

            This method executes a stored procedure to retrieve the total number of rows 
            associated with the given `Tracking_id` and `fnt_id` from the database. The result 
            is returned as an integer representing the aggregated row count.

            Args:
                Tracking_id (str): The tracking ID used to query the number of rows.
                fnt_id (str): The function ID used to query the number of rows.

            Returns:
                int: The aggregated row count associated with the given `Tracking_id` and `fnt_id`.

            Raises:
                Exception: If there is any error during the database execution, the exception is 
                        caught and printed.
        """

        try:
            statement = f"""EXEC dbo.sp_get_no_rows @Tracking_Id='{Tracking_id}',@fnt_id='{fnt_id}'"""
            print('fn_get_no_rows query is ',statement)
            exec_statement = self.con.prepareCall(statement)
            print(exec_statement.execute())
            resultSet=exec_statement.getResultSet()
            #print(resultSet)
            while (resultSet.next()):
                result_dict=resultSet.getInt('agg_row_cnt') 
            exec_statement.close()
            return result_dict
        except Exception as e:
            print(e)       
       
    