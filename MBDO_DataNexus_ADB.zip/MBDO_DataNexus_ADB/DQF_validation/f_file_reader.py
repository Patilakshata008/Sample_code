
import json
from f_csvtxt_reader import *
from f_json_reader import *
from f_xml_reader import *
from f_move_files import *
from f_parquet_reader import *
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType,StructField,StructType,LongType,DecimalType,DateType,TimestampType,FloatType,BooleanType
from pyspark.sql import functions as func
from functools import reduce  # For Python 3.x
from pyspark.sql import DataFrame
from f_json_2reader import *
import operator
class masterdata:
    def __init__(self,dbwrite,dbread,tracking_id,ref_tracking_ids,config,list_of_files,IOTFlag,spark,mvfl):  
        """
            Initializes an instance of the class, setting up various configurations and reading necessary 
            files based on the provided configurations.

            This constructor takes several parameters to initialize the instance's attributes, such as database 
            connections, tracking IDs, configuration details, file paths, and other settings. It also sets up 
            objects for different types of file readers (CSV, JSON, XML, Parquet) based on the provided configurations.

            Args:
                dbwrite (DatabaseConnection): A connection object used for writing data to the database.
                dbread (DatabaseConnection): A connection object used for reading data from the database.
                tracking_id (str): The tracking ID for the current job or process.
                ref_tracking_ids (list): List of reference tracking IDs.
                config (dict): Configuration dictionary that contains settings for file reading, schemas, etc.
                list_of_files (list): List of files to be processed.
                IOTFlag (bool): A flag indicating whether the process is related to IoT data.
                spark (SparkSession): The SparkSession object used for Spark-related operations.
                mvfl (str): The name of the MVFL (Machine Vision Failure Logic) used for processing.

            Attributes:
                dbwrite (DatabaseConnection): The connection used for writing data to the database.
                dbread (DatabaseConnection): The connection used for reading data from the database.
                spark (SparkSession): The Spark session object.
                fnt_id (str): The FNT ID used for processing files.
                File_Schema (str): The expected schema for the files being processed.
                mov (str): The name of the MVFL for processing.
                job_run_id (str): The tracking ID for the current job.
                ref_tracking_ids (list): List of reference tracking IDs.
                header (bool): A flag indicating whether the file contains a header.
                delimiter (str): The delimiter used in the file.
                schema (dict): The schema for the file.
                IOTFlag (bool): A flag indicating whether the process is related to IoT data.
                sc (SparkContext): The SparkContext object.
                schema_df (DataFrame): The schema DataFrame read from the configuration.
                xmlroottag (str): The root tag for XML files.
                xmldetailstag (str): The details tag for XML files.
                list_of_files (list): List of files to be processed.
                columns (list): List of column names to be processed.
                fileType (str): The type of the file being processed (e.g., CSV, JSON, XML, Parquet).
                file_read_configs (dict): Configuration details for reading files.
                csv_obj (csvtxtdatareader): Object for reading CSV files.
                json_obj (jsonreader): Object for reading JSON files.
                json_obj2 (json2reader): Object for reading JSON files with a different format.
                xml_obj (xmldatareader): Object for reading XML files.
                parquet_obj (parquetreader): Object for reading Parquet files.
                function_mapper (dict): A mapping of validation functions for JSON data.
"""
        self.dbwrite=dbwrite
        self.dbread=dbread
        self.spark = spark
        self.fnt_id=config['file_read_configs']['FNT_Id']
        self.File_Schema=config['file_read_configs']['Expected_Schema']
        self.mov=mvfl
        self.job_run_id=tracking_id
        self.ref_tracking_ids=ref_tracking_ids
        self.header=config['file_read_configs']['is_header_present']
        self.delimiter=config['file_read_configs']['delimiter']
        self.schema=config['schema']
        self.IOTFlag=IOTFlag
        self.spark = spark
        self.sc=self.spark.sparkContext
        self.schema_df=self.spark.read.json(self.sc.parallelize([json.dumps(self.schema)]))
        self.xmlroottag=config['file_read_configs']['xmlroottag']
        self.xmldetailstag=config['file_read_configs']['xmldetailstag']
        self.list_of_files=list_of_files
        self.columns=self.schema_df.filter("operation='column'").rdd.map(lambda a:a['Expected_Columnname']).collect()
        self.fileType=config['file_read_configs']['File_Type']
        self.file_read_configs=config['file_read_configs']
        self.csv_obj=csvtxtdatareader(self.header,self.delimiter,self.spark)
        self.json_obj=jsonreader(self.schema_df,self.IOTFlag)
        self.json_obj2=json2reader(self.spark,self.sc)
        self.xml_obj=xmldatareader(self.xmlroottag,self.xmldetailstag,self.File_Schema,self.fnt_id,self.spark)
        self.parquet_obj=parquetreader(self.header)
        self.function_mapper={'jsondata_32':self.json_obj2.jsondata_32,'jsondata_55':self.json_obj2.jsondata_55,'jsondata_96':self.json_obj2.jsondata_96}
        
    def fn_readFiles(self):
        """
            Reads the necessary files and returns the processed data.

            This method retrieves the master data by calling the `fn_masterdata` method, which is responsible 
            for reading and processing the required files.

            Returns:
                DataFrame: The processed data returned from the `fn_masterdata` method.
        """

        dataframe=None
        data=self.fn_masterdata()
        return data
    
    def fn_masterdata(self):
        """
                Processes a list of files and returns a combined DataFrame after performing validation, error handling, 
                and logging operations.

                This method reads files from a given list of files, processes them based on their type (JSON, CSV, XML, 
                or Parquet), checks column names, and handles any errors. It also logs error counts and updates error 
                status in the database.

                The method performs the following:
                - Iterates over each file in the list of files.
                - Reads the file according to its type (JSON, CSV, XML, or Parquet).
                - Checks if the file's column names match the expected schema.
                - Appends the data to a list if valid, or moves it to the error location if invalid.
                - Updates error status and row counts in the database.

                Returns:
                    DataFrame: A combined DataFrame from all valid files. Returns None if no valid data is found.
        """

        def unionAll(*dfs):
            return reduce(DataFrame.unionAll, dfs)

            # Create an empty RDD
        emp_RDD = self.spark.sparkContext.emptyRDD()
        # Create empty schema
        columns = StructType([])
        # Create an empty RDD with empty schema
        data = self.spark.createDataFrame(data = emp_RDD,
                                 schema = columns)
        Totaldata=[]
        error_row_cnt=0
        json_data=[]
        error_data=[]
        errorstatus_data=[]
        expected_length=self.dbread.fn_get_no_columns_new(self.fnt_id)
        dict_error={}
        dict_error['error_row_cnt']=0
        for file in self.list_of_files:
            #error_row_cnt=0
            dict_data={}
            
            print('file is ',file)
            
            filepath=file[1]
            x=filepath.split("/")
            file_id=file[0]
            filename= x[len(x)-1]
            if self.fileType=='json':
                print('inside filereader at json function')
                tempdata=self.function_mapper[self.file_read_configs['data_func']](filepath)
                print('data in temp data')
            elif self.fileType=='csv' or self.fileType=='txt':
                tempdata=self.csv_obj.fn_readcsv_txt(filepath)
            elif self.fileType=='xml':
                tempdata=self.xml_obj.fn_readxml(filepath)
            elif self.fileType=='parquet':
                tempdata=self.parquet_obj.fn_read_parquet(filepath)
            tempdata.createOrReplaceTempView('abc')
            row_cnt=self.spark.sql("select count(*) from abc").first()[0]

            print('row_cnt',row_cnt)
            dict_data['filename']=filename
            dict_data['row_cnt']=row_cnt
            dict_data['file_id']=file_id
            print('dict_dtaa',dict_data)
            json_data.append(dict_data)

            actual_length=len(tempdata.columns)
            print("actual_length_type",type(actual_length))
            print("expected_length_type",type(expected_length))

            print("Actual_length",actual_length)
            print("Expected_length",expected_length)
            
            result=self.fn_checkcolumnnames(tempdata,file,file_id)
            if result==True: 
                print('inside result')
                act_tempdata=tempdata.withColumn("Source_file", lit(str(filepath))).withColumn("Tracking_Id",lit(str(self.job_run_id)))
                Totaldata.append(act_tempdata)
                dict_error['ref_tracking_ids']=self.ref_tracking_ids
                dict_error['error_row_cnt']=dict_error['error_row_cnt']+error_row_cnt
                dict_error['expected_length']=expected_length
                 
            else:
                print('inside else')
                error_row_cnt=error_row_cnt+tempdata.count()
                data=self.mov.fn_move_error_files(file,self.ref_tracking_ids,file_id)
                
                errorstatus_data.append(data)
                dict_error['ref_tracking_ids']=self.ref_tracking_ids
                dict_error['error_row_cnt']=dict_error['error_row_cnt']+error_row_cnt
                dict_error['expected_length']=expected_length
                
        if len(errorstatus_data)>0:
            print("ho")
            self.dbwrite.fn_update_error_status_new(errorstatus_data)
        self.dbwrite.fn_update_row_cnt_new(json_data)
        print('before insert delta_logs')        
        error_data.append(dict_error)
        print('error_data----------',error_data)
        self.dbwrite.fn_update_error_row_cnt_new(error_data)
        print('updated error row count')
        if(len(Totaldata)>0):
            data=unionAll(*Totaldata)
        else:
            data=None
        print('return final dataframe from filereader module')
        return data      
        
    def fn_checkcolumnnames(self,dataframe,file,file_id):
        """
            Checks if the columns in the given DataFrame match the expected mandatory columns defined in the schema.

            This method compares the columns in the DataFrame against the list of mandatory columns defined in the schema.
            It returns `True` if all mandatory columns are present, otherwise it returns `False`.

            The method performs the following:
            - Retrieves the list of expected mandatory column names from the schema.
            - Compares the actual columns in the DataFrame with the expected columns.
            - If any expected column is missing, it returns `False`, otherwise it returns `True`.

            Args:
                dataframe (DataFrame): The DataFrame whose columns are to be validated.
                file (str): The file path (not used in validation but passed as part of the function signature).
                file_id (str): The file ID (not used in validation but passed as part of the function signature).

            Returns:
                bool: `True` if all mandatory columns are present, `False` otherwise.
        """
        columns=self.schema_df.filter("Is_Mandatory_Column='1'").rdd.map(lambda a:a['Expected_Columnname']).collect()
        column_list_expected=columns
        column_list_actual=dataframe.columns
        print("column_list_expected",column_list_expected)
        print("column_list_actual",column_list_actual)
        total=0
        for i in column_list_expected:
            if i not in column_list_actual:
                total=1
        if total==1:
            return False
        else:
            return True
