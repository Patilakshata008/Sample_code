from pyspark.sql import SparkSession
from pyspark.sql.functions import col,to_timestamp
from pyspark.sql.types import StructType, StructField, StringType,TimestampType
import re
class pdfreader:
    def __init__(self, header: bool, spark: SparkSession):
        self.header = header
        self.spark = spark

    def fn_read_pdf(self, filepath: str):
        header_option = "true" if self.header else "false"
        print("Header:", header_option)
        print("Filepath:", filepath)

        df = (
            self.spark.read.format("pdf")
            .option("imageType", "BINARY")
            .option("resolution", "300")
            .option("pagePerPartition", "8")
            .option("reader", "pdfBox")
            # .load(filepath)
            .load("dbfs:/tmp/quotation_sample_10.pdf")
        )

        print("Inside PDF Reader")

        # Extract text content from PDF (assuming `df` contains a column 'text')
        pdf_text = " ".join(row.text for row in df.select("text").collect())

        # Extract fields using regex patterns
        extracted_data = self.extract_fields(pdf_text)

        # Create DataFrame with extracted data
        extracted_df = self.create_dataframe(extracted_data)

        extracted_df.printSchema()
        # extracted_df.show(truncate=False)

        return extracted_df

    def extract_fields(self, pdf_text: str):
        patterns = {
            "tel": r"Tel\s*:\s*([\d\(\)\s-]+)",
            "fax": r"Fax\s*:\s*([\d\(\)\s-]+)",
            "date": r"Date\s*:\s*([\dA-Za-z-]+)",
            "item_no": r"Item No:\s*(.+)",
            "price_sop": r"SOP[^\d]*([\d.]+)\s*/pc",
            "price_sop_1_year": r"SOP\+1Year[^\d]*([\d.]+)\s*/pc",
            "price_sop_2_year": r"SOP\+2Year[^\d]*([\d.]+)\s*/pc",
            "moq": r"MOQ\s*:\s*([\d,]+)",
            "lead_time": r"Lead Time\s*:\s*([\d\w\s]+)",
            "validity": r"Validity\s*:\s*Till\s*:\s*([\d\w-]+)",
        }

        # Extract fields using regex patterns
        tel_match = re.search(patterns["tel"], pdf_text)
        fax_match = re.search(patterns["fax"], pdf_text)
        date_match = re.search(patterns["date"], pdf_text)
        item_no = re.search(patterns["item_no"], pdf_text)
        price_sop = re.search(patterns["price_sop"], pdf_text)
        price_sop_1 = re.search(patterns["price_sop_1_year"], pdf_text)
        price_sop_2 = re.search(patterns["price_sop_2_year"], pdf_text)
        moq = re.search(patterns["moq"], pdf_text)
        lead_time = re.search(patterns["lead_time"], pdf_text)
        validity = re.search(patterns["validity"], pdf_text)

        # Store extracted values in a dictionary
        extracted_values = {
            "tel": tel_match.group(1) if tel_match else None,
            "fax": fax_match.group(1) if fax_match else None,
            "date": date_match.group(1) if date_match else None,
            "item_no": item_no.group(1) if item_no else None,
            "price_sop": price_sop.group(1) if price_sop else None,
            "price_sop_1_year": price_sop_1.group(1) if price_sop_1 else None,
            "price_sop_2_year": price_sop_2.group(1) if price_sop_2 else None,
            "moq": moq.group(1) if moq else None,
            "lead_time": lead_time.group(1) if lead_time else None,
            "validity": validity.group(1) if validity else None,
        }

        return extracted_values

    def create_dataframe(self, extracted_values: dict):
        schema = StructType(
            [
                StructField("date", StringType(), True),
                StructField("tel", StringType(), True),
                StructField("fax", StringType(), True),
                StructField("item_no", StringType(), True),
                StructField("price_sop", StringType(), True),
                StructField("price_sop_1_year", StringType(), True),
                StructField("price_sop_2_year", StringType(), True),
                StructField("moq", StringType(), True),
                StructField("lead_time", StringType(), True),
                StructField("validity", StringType(), True),
            ]
        )

        data = [tuple(extracted_values[key] for key in schema.fieldNames())]
        return self.spark.createDataFrame(data, schema=schema)


# Example usage (assuming Spark session exists as `spark`)
# pdf_reader = PDFReader(header=True, spark=spark)
# extracted_df = pdf_reader.fn_read_pdf("dbfs:/tmp/quotation_sample_2.pdf")
# filepath = "dbfs:/tmp/quotation_sample_2.pdf"
# reader = pdfreader(header=True, spark=spark)
# pdf_df = reader.fn_read_pdf(filepath)
# display(pdf_df)