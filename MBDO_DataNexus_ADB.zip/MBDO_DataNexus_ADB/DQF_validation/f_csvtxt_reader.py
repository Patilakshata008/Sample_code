from f_utility_functions import *
from functools import reduce 
from pyspark.sql.functions import col,lit
from pyspark.sql import DataFrame
class csvtxtdatareader:
    def __init__(self,header,delimiter,spark):

        """
            Initializes the configuration object for processing files with the given parameters.
        Args:
            header (bool): A boolean flag indicating whether the file contains a header (True) or not (False).
            delimiter (str): The delimiter used in the file to separate columns (e.g., ',', ';', '\t').
            spark (SparkSession): The SparkSession object used for Spark operations.
        Attributes:
            header (bool): The header flag for the file.
            delimiter (str): The delimiter for the file.
            spark (SparkSession): The SparkSession instance to be used for file processing.
        """
        self.header=header
        self.delimiter=delimiter
        self.spark=spark
        
    def fn_readcsv_txt(self,filepath):
        """
             Reads a CSV or TXT file from the given file path using Apache Spark, with options to infer schema and handle multiline data.

            Args:
                filepath (str): The path to the CSV or TXT file to be read.

            Returns:
                DataFrame: A Spark DataFrame containing the data from the file.

            Notes:
                - The method uses the SparkSession instance stored in `self.spark` to read the file.
                - The `header` attribute is used to determine if the first row of the file contains column names.
                - The file's schema is inferred automatically, and multiline options are enabled.
        """

        header='true' if self.header==True else 'false'
        print("filepath",filepath)
        data=self.spark.read.format('csv').option('inferSchema','true').option('header','true').option('multiline','true').load(filepath)
        print('insder csvtxt')
        data.printSchema()
        return data