# Databricks notebook source
# MAGIC %reload_ext autoreload
# MAGIC %autoreload 2

# COMMAND ----------


import uuid

#Input is passed from azure data factory pipelines
job_run_id=dbutils.widgets.get('jobRunId')
pipeline_run_id=dbutils.widgets.get('pipielineRunId')
#AppName=dbutils.widgets.get('ApplicationName')
SourceSystem=dbutils.widgets.get('SourceSystem')
FileTemplate=dbutils.widgets.get('FileName_Template')
IOTFlag=dbutils.widgets.get('IS_IOT')
FNT_ID=dbutils.widgets.get('FNT_Id')
HierarchyFlag=dbutils.widgets.get('IS_Hierarchical')
curr_try=dbutils.widgets.get('curr_try')
#HierarchyFlag='True'
#need add this params


# COMMAND ----------

# import uuid

# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# #pipeline_run_id='18ecc52a-61b4-423d-a105-5bba7e68843d'
# SourceSystem='Test_AdvHRcsv'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID = '2'
# FileTemplate='Test_HR_csv'
# curr_try=1

# COMMAND ----------

# import uuid

# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# #pipeline_run_id='18ecc52a-61b4-423d-a105-5bba7e68843d'
# SourceSystem='pilump'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID = '4'
# FileTemplate='pilump'
# curr_try=1

# COMMAND ----------

# import uuid

# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# #pipeline_run_id='18ecc52a-61b4-423d-a105-5bba7e68843d'
# SourceSystem='quotation_montly_report_001'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID = '3'
# FileTemplate='quotation_sample'
# curr_try=1

# COMMAND ----------

# import uuid

# job_run_id=str(uuid.uuid4())
# print(job_run_id)
# pipeline_run_id=str(uuid.uuid4())
# SourceSystem='sapp'
# HierarchyFlag='False'
# IOTFlag='False'
# FNT_ID = '16'
# FileTemplate='pcbmr_sapp'
# curr_try=1

# COMMAND ----------

import os
import shutil
import time
from datetime import datetime
from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
import msal
import json
import pathlib
import pandas as pd
import multiprocessing as mp
import functools
from pyspark.sql.functions import spark_partition_id, asc, desc
import ast
from pyspark.sql.functions import monotonically_increasing_id 
from multiprocessing.pool import ThreadPool
from pyspark.sql.types import StringType,StructField,StructType,LongType,DecimalType,DateType,TimestampType,FloatType,BooleanType
from pyspark.sql import functions as func
from functools import reduce  # For Python 3.x
from pyspark.sql import DataFrame
import operator

del sum 
%pip install openpyxl


# COMMAND ----------

from f_utility_functions import utilityfunction as utf
#from Dbconnection import *
from f_db_reader import *
from f_db_writers import *
from f_db_configreader import *
from f_delta_table_load import *
from f_move_files import *
from common_func.f_database_connect import *
from common_func.f_logs import *
from f_attribute_validator4 import *
from f_file_reader2 import *
from f_data_masking import *
from f_xlsx_reader import *
from f_pdf_reader import *

# COMMAND ----------

bbaddf=None
gooddf=None
attributes=None
spark.conf.set("spark.sql.legacy.timeParserPolicy","EXCEPTION")
spark.conf.set("spark.sql.shuffle.partitions",'auto')
server = dbutils.secrets.get(scope="datanexus-dev-scope",key="EDA-SQLDB-ServerName")
database = dbutils.secrets.get(scope="datanexus-dev-scope",key="EDA-SQLDB-DBName")
sqlusername = dbutils.secrets.get(scope="datanexus-dev-scope",key="EDA-SQLDB-SQLusername")
sqlPassword = dbutils.secrets.get(scope="datanexus-dev-scope",key="EDA-SQLDB-DBPassword")
url=f"jdbc:sqlserver://{server};databaseName={database}"
spark1 = SparkSession.builder.appName('integrity-tests').config("spark.sql.legacy.timeParserPolicy","EXCEPTION").getOrCreate()
source_dl_layer='Bronze'
dest_dl_layer='Silver'
dbasecon=DBconnection(database=database,server=server,spark1=spark1)
con=dbasecon.fn_get_connection()
dbread=Dbreader(con)
dbwrite=Dbwriters(con)
dbwriter=commonlogs(dbasecon,sourceName=SourceSystem,dest_dl_layer=dest_dl_layer,key='DQFValidation',FNT_ID=FNT_ID,job_run_id=job_run_id,HierarchyFlag=HierarchyFlag,FileTemplate=FileTemplate,spark1=spark1)

list_of_batches=dbread.fn_get_files_for_dqf(FNT_ID)
print("list_of_batches " ,list_of_batches)
configreader=Dbconfigreaders(con,FNT_ID,source_dl_layer,dest_dl_layer,SourceSystem)
config_dict=configreader.getall_configs()
uf=utf(con,source_dl_layer,dest_dl_layer,SourceSystem)
path=config_dict['path']
badrowscount=0
print('configs are-----------------------',config_dict)
mv=Movefiles(dbwrite,uf,config_dict,source_dl_layer,dest_dl_layer,path,FileTemplate,spark1,FNT_ID,dbwriter,SourceSystem)
#path=dbcon.func_get_paths()

if len(list_of_batches)>0:
    
    batches_files=pd.DataFrame.from_records(list_of_batches).groupby(['FNT_Id'])['File_Id','To_DL_Layer'].apply(lambda g: g.values.tolist()).to_dict()
    ref_tracking_ids_temp=pd.DataFrame.from_records(list_of_batches).groupby(['FNT_Id'])['Tracking_Id'].apply(lambda g: set(g.values.tolist())).to_dict()
    ref_tracking_ids={a:'|'.join([c for c in b]) for a,b in ref_tracking_ids_temp.items()}
    print('ref tracking ids are',ref_tracking_ids)
else:
    batches_files={}
print("batches_files",batches_files)
for key,value in batches_files.items():
    print('key is',key)
    print('value is',value)
    check=config_dict['dqf_needed']
    DQF_Check=check['DQF_Needed']
    Duplicate_Check=check['Duplicatecheck_Needed']
    act_from_dl_layer_path=path['Bronze-Success']
    json1={'file_id':0,'filepath':act_from_dl_layer_path,'fnt_id':key}
    
    dbwriter.fn_insert_delta_logs(file=json1,job_id=job_run_id,pipeline_run_id=pipeline_run_id,from_dl_layer=source_dl_layer,\
                                     ref_tracking_ids=ref_tracking_ids[key])
    
    print("DQF_Needed value is ",DQF_Check)
    fnt_info=config_dict['file_read_configs']
    File_Type=fnt_info['File_Type']
    print('File_type is',File_Type)
    if File_Type=='csv' or File_Type=='txt' or File_Type=='json'  or File_Type=='xml' or File_Type=='parquet' or File_Type=='xlsx' or File_Type=='pdf' :
        act_temp_file_path=path['Bronze-Cache']
            #act_temp_file_path=path['Cache']
        print("temp_file_path ",act_temp_file_path)
        track_id=job_run_id+'-'+key
        print('DQF tracking id',track_id)
        av=AttributeValidator(config=config_dict,\
                            temp_file_path=act_temp_file_path,\
                            temp_file_name=job_run_id+'_'+key,spark=spark1,job_run_id=job_run_id)
        msdata=masterdata(dbwrite,dbread,job_run_id,ref_tracking_ids[key],config_dict,\
                               value,IOTFlag,spark1,mv,track_id) 
        data=msdata.fn_readFiles()
        
        data.printSchema()
        display(data)
        print('final df in dqf notebook')
        
            #display(data)
    

    if data is None:
        act_to_dl_layer_path=path['Bronze-Error']
        
        json3={'file_id':0,'filepath':act_to_dl_layer_path,'fnt_id':key}
        dbwriter.fn_update_delta_logs_new(file=json3,job_id=job_run_id,to_dl_layer=source_dl_layer,\
                                     to_dl_layer_path=act_to_dl_layer_path,validation_status='completed',\
                                     ref_tracking_ids=ref_tracking_ids[key])
        print("Delta logs are updated for error file")
        gooddf_count=0
        baddf_count=0
        error_df_count=0
        
    elif  not DQF_Check:
        print('dqf not needed')

        print('after repartition')
        gooddf_count=data.count()
        print('good data count',gooddf_count)
        #display(data)
        print('adding index column to df')
        data1=uf.fn_addindex(data)
        gooddf=data1
        baddf_count=0
        error_df_count=0
        badrowscount=0
        print('last stmt of elif loop')
    else:
        data=uf.fn_addindex(data)
        print('data')
        print('count of data')

        print('schema of data is',data.schema)
        baddf,gooddf,error_df=av.fn_getattributesValidation(data)
        #display(gooddf)
        from pyspark.sql.functions import spark_partition_id, asc, desc
        
        gooddf.printSchema()

        gooddf_count=gooddf.count()
        print('count of gooddf is ',gooddf_count)
        baddf_count=baddf.count()
        #error_df_count=error_df.count()
        error_df_count=error_df.count()
        print('count of badddf is ',baddf_count)
        
        
    if error_df_count>0:
        print('error data count is greater than 0')
        error_df=error_df.withColumn('tracking_id',lit(job_run_id))
        error_df=error_df.withColumn('batchId',lit(-1))
        error_df=error_df.withColumn('curr_time',current_timestamp())
        error_df.write.format('jdbc').option('url',url).option('dbtable','T_LOG_error_reason_data').option('user',sqlusername).option('password',sqlPassword).mode('append').save()
    if baddf_count>0:
        print('baddf count is grrater than 0')
        display(baddf)
        mv.fn_move_baddf_silver(baddf,path,FileTemplate,uf)
        keycolumn=config_dict['deltalake_configs']['KeyColumns']
        dbwriter.fn_add_alerts(key,'DQF_FAILURE_RECORDS','',job_run_id+'-'+FNT_ID,'')
    if gooddf_count>0:
        print('gooddf count is greater than 0')
        act_target_path=path['Silver-Success']
        targetpath=act_target_path+FileTemplate
        print("targetpath ",targetpath)
        print('calling the delta lake function here')
        #masking=Data_masking(gooddf,config_dict,spark1)
        print('masking obj is created')
        #maskdf=masking.data_mask()
        maskdf=gooddf
        print('maksing completed')
        deltaload=DeltaTableLoad(config_dict,targetpath,maskdf,spark1)
        print('obj for deltaload created and calling table_load func')
        deltaload.table_load()
    act_to_dl_layer_path=path['Silver-Success']
    json2={'file_id':0,'filepath':act_to_dl_layer_path,'fnt_id':key}
    dbwriter.fn_update_delta_logs_new(file=json2,job_id=job_run_id,to_dl_layer=dest_dl_layer,\
                                   to_dl_layer_path=act_to_dl_layer_path,validation_status='completed',\
                                   copy_activity_status='completed',ref_tracking_ids=ref_tracking_ids[key])
    print("updated status for good df")
                #For reconciliation logs
    expected_rows=dbread.fn_get_no_rows(ref_tracking_ids[key],key)
    print ("expected_rows",expected_rows)
    print(badrowscount)
    dbwrite.fn_insert_delta_summary_logs(ref_tracking_ids[key],expected_rows,gooddf_count,baddf_count,track_id)
     

# COMMAND ----------

# %sql
# SHOW VOLUMES

# COMMAND ----------

# %sql
# CREATE VOLUME mbdo_bronze_dev

# COMMAND ----------

# %sql
# CREATE VOLUME mbdo_bronze_dev.quotation_montly_report_001.Cache

# COMMAND ----------

# MAGIC %sql
# MAGIC --SHOW VOLUMES IN `mbdo_bronze_dev`.`Test_AdvHRcsv`;
# MAGIC --CREATE VOLUME mbdo_bronze_dev.quotation_montly_report_001.Cache
# MAGIC
# MAGIC -- DROP VOLUME mbdo_bronze_dev.Test_AdvHRcsv.Cache;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --SHOW VOLUMES IN `mbdo_bronze_dev`.`Test_AdvHRcsv`;
# MAGIC -- CREATE VOLUME mbdo_bronze_dev.pilump.Cache
# MAGIC
# MAGIC -- DROP VOLUME mbdo_bronze_dev.Test_AdvHRcsv.Cache;

# COMMAND ----------

# MAGIC %md
# MAGIC display(plain)