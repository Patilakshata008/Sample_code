from pyspark.sql import DataFrame
import pandas as pd
from functools import reduce
from f_db_configreader import *

# %pip install openpyxl
# %pip install openpyxl --upgrade
# %pip install pandas --upgrade

class xlsxreader:
    def __init__(self, header, spark, schema):
        self.header = header
        self.spark = spark
        self.schema = schema

    def fn_get_schema(self, columns):
        """
        Constructs a schema definition for valid data based on column configurations.

        Args:
            columns (list): List of dictionaries representing column configurations.

        Returns:
            str: Schema string for valid data.
        """
        schema = ""
        for i in range(len(columns)):
            if len(columns) == 1 or i == len(columns) - 1:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                )
            else:
                schema += (
                    columns[i]["Expected_Columnname"]
                    + " "
                    + columns[i]["Expected_Datatype"]
                    + ","
                )

        return schema

    def fn_read_excel(self, filepath):
        header = "true" if self.header else "false"
        print("Header:", header)
        print("Filepath is --->", filepath)

        df_list = []
        # Set the minimum inflate ratio to a lower value using Spark configuration
        self.spark.conf.set("spark.executorEnv.POI_MIN_INFLATE_RATIO", "0.001")
        # Set the minimum inflate ratio using ZipSecureFile
        self.spark._jvm.org.apache.poi.openxml4j.util.ZipSecureFile.setMinInflateRatio(0.001)
        schema = self.schema 
        final_schema = self.fn_get_schema(schema)
        print('schema as per the metadata table is ',final_schema )
        for file in filepath:
            xls = pd.ExcelFile(file)
            print("the sheets in excel is ",xls.sheet_names)
            sheet_name = xls.sheet_names[0]
            print("the 1st sheet name in excel is ",sheet_name) 
            df = (
                self.spark.read.format("com.crealytics.spark.excel")
                .option("header", "true")
                # .option("inferSchema", "true")
                .schema(final_schema)
                .option("sheetName",sheet_name)
                .option("maxRowsInMemory", 2000)
                .load(file)
    )
            df_list.append(df)

        # Merge DataFrames
        data = reduce(lambda df1, df2: df1.unionByName(df2), df_list)
        print("Inside Excel Reader")
        row_count = data.count()
        data.printSchema()
        print(f"Number of rows: {row_count}")
        return data

