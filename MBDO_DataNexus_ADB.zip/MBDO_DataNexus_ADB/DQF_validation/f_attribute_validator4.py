import pyspark.sql.functions as func
from pyspark.sql.functions import lit
from itertools import chain
import builtins as bi
from pyspark.sql import SparkSession
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import StringType,StructField,StructType,LongType,DecimalType,DateType,TimestampType,FloatType,BooleanType
from pyspark.sql.functions import concat,collect_list,col,explode,lit
import operator
from f_file_reader import *

class AttributeValidator:
    def __init__(self,config,temp_file_name,temp_file_path,spark,job_run_id):
        """
            Initializes an instance of the class with configuration, file details, schema, and Spark context.

            This constructor is used to initialize the instance with the necessary configuration, file details, schema, and Spark session for processing. It also defines the structure of the schema, attributes, and a function mapper for data validation.

            Parameters:
                config (dict): A dictionary containing configuration details such as schema, file reading configurations, and other attributes.
                temp_file_name (str): The name of the temporary file.
                temp_file_path (str): The path to the temporary file.
                spark (SparkSession): The Spark session for interacting with the Spark cluster.
                job_run_id (str): A unique identifier for the job run.

            Attributes:
                job_run_id (str): The job run identifier.
                config (dict): The configuration settings.
                schema (dict): The schema for the data.
                header (bool): A flag indicating if the file contains headers.
                delimiter (str): The delimiter used in the file.
                attributes (dict): A dictionary of attributes.
                spark (SparkSession): The Spark session object.
                sc (SparkContext): The Spark context object.
                schema_df (DataFrame): The schema data frame.
                schema1 (StructType): The schema for the data validation.
                columns (list): A list of expected column names.
                fileType (str): The type of the file (e.g., CSV, JSON).
                fnt_id (str): The file template ID.
                temp_file_name (str): The temporary file name.
                temp_file_path (str): The temporary file path.
                att_df (DataFrame): Data frame of attributes.
                schema3 (StructType): The schema for validation rules.
                function_mapper (dict): A dictionary mapping validation types to functions.
                order_of_validation (dict): A dictionary specifying the order of validation steps.
        """

        self.job_run_id=job_run_id
        self.config=config
        self.schema=config['schema']
        self.header=config['file_read_configs']['is_header_present']
        self.delimiter=config['file_read_configs']['delimiter']
        self.attributes=config['list_of_attributes']
        self.spark=spark
        self.sc=self.spark.sparkContext
        self.schema_df=self.spark.read.json(self.sc.parallelize([json.dumps(self.schema)]))
        self.schema1=StructType([
                       StructField("id", StringType()),
                       StructField("column_success", StringType())
                        ])
        
        self.columns=self.schema_df.filter("operation='column'").rdd.map(lambda a:a['Expected_Columnname']).collect()
        self.fileType=config['file_read_configs']['File_Type']
        self.fnt_id=config['file_read_configs']['FNT_Id']
        self.temp_file_name=temp_file_name
        self.temp_file_path=temp_file_path
        self.att_df=self.spark.read.json(self.sc.parallelize([json.dumps(self.attributes)])) 
        self.schema3=StructType([
                       StructField("id", StringType()),
                       StructField("column", StringType()),
                       StructField("Validationtype", StringType())
                        ])
        self.function_mapper={'CheckNull':self.fn_filternulls,'length':self.fn_checklength,'Datatype':self.fn_validate_schema_precision_Scale
                              ,'DateFormatCheck':self.fn_check_date_time_format,'CheckRegex':self.fn_checkregex,'check_value_length':self.fn_check_column_value_length,'Checkuniquerow':self.fn_check_unique_column_values,'Check_required_values':self.fn_check_column_values,'CheckColumnCount':self.fn_checkcolumnsum, 'check_value_range':self.fn_checkcolumn_value_range}
        self.order_of_validation={1:'CheckNull',2:'length',3:'Datatype',4:'DateFormatCheck',5:'CheckRegex',6:'check_value_length',7:'Checkuniquerow',8:'Check_required_values',9:'CheckColumnCount',10:'check_value_range'}
      

    def fn_filternulls(self,flattened_df,strings):
        """
            Filters out rows with null values for non-nullable columns.

            This function checks for null values in the specified non-nullable columns in the provided DataFrame. If any non-nullable column contains null values, it identifies and collects the rows where those nulls occur. The function then returns a dictionary containing the column names as keys and the corresponding row IDs with null values as values.

            Parameters:
                flattened_df (DataFrame): The input DataFrame containing the data to be checked for null values.
                strings (list): A list of column names that should be checked for null values.

            Returns:
                dict: A dictionary where the keys are the names of columns with null values and the values are lists of row IDs that contain null values in those columns.
        """
        non_nullable_columns=self.schema_df.filter("Is_Nullable=0").rdd.map(lambda a:a['Expected_Columnname']).collect()
        print('non nullable columns are ',non_nullable_columns)
        null_dict={}
        null_df1 = self.spark.createDataFrame([], StructType([]))
        if len(non_nullable_columns)>0:

            matches=[elem for elem in non_nullable_columns if elem in strings]
            for a in matches:
                cond=functools.reduce(operator.or_,[col(a).isNull()])
                null_success_df=flattened_df.select(col('id'),col(a)).withColumn('null_success',when(cond,False).otherwise(True)) 
                df=null_success_df.filter(col('null_success')==False)
                var=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
                if len(var)!=0:
                    null_dict[a]=df.select(col('id')).rdd.flatMap(lambda x: x).collect()                    
        return null_dict
                        
    
    def fn_checklength(self,data,strings):
        """
            Checks if the values in specified columns exceed the maximum defined length.

            This function verifies that the values in the specified columns do not exceed the maximum length defined in the schema. If any column value exceeds the maximum length, the row IDs with violations are collected and returned. The function works based on the `length` attribute from the schema and checks columns passed in the `strings` list.

            Parameters:
                data (DataFrame): The input DataFrame containing the data to be checked for length violations.
                strings (list): A list of column names that should be checked for exceeding the maximum length.

            Returns:
                dict: A dictionary where the keys are column names and the values are lists of row IDs that have values exceeding the defined maximum length in those columns.
        """
        df_columns=self.att_df.filter("File_Attribute_Name='length'").select(explode(split("Columnnames", "[,]")).alias('Columns'))
    
        length_dict=self.schema_df.select('Expected_Columnname','Expected_Length').rdd.collectAsMap()
        mapping_expr = create_map([lit(x) for x in chain(*length_dict.items())])
        df_col_len=df_columns.withColumn("length", mapping_expr[col('Columns')])

        ls_columns_int_string_filtered=df_col_len.filter(df_columns.Columns.isin(strings))       
        collength_dict=ls_columns_int_string_filtered.rdd.collectAsMap()

        length_df1 = self.spark.createDataFrame([], StructType([]))
        length_dict={}
        for alias,max_length in collength_dict.items():
            cond=functools.reduce(operator.or_,[length(col(alias)) >max_length ])
            len_success_df=data.select(col('id'),col(alias)).withColumn('length_success',when(cond,False).otherwise(True)) 
            df=len_success_df.filter(col('length_success')==False)
            var=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
            if len(var)!=0:
                length_dict[alias]=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
       
        return length_dict
      
    def fn_check_date_time_format(self,data,strings):
        """
            Checks if the values in specified columns conform to the expected date/time format.

            This function verifies that the values in the specified columns adhere to the expected date/time format defined in the schema. If any column value does not match the expected format, the row IDs with violations are collected and returned. The function works based on the `DateFormatCheck` attribute from the schema and checks columns passed in the `strings` list.

            Parameters:
                data (DataFrame): The input DataFrame containing the data to be checked for date/time format violations.
                strings (list): A list of column names that should be checked for compliance with the expected date/time format.

            Returns:
                dict: A dictionary where the keys are column names and the values are lists of row IDs that have values not matching the expected date/time format in those columns.
        """
        df_columns=self.att_df.filter("File_Attribute_Name='DateFormatCheck'").select(explode(split("Columnnames", "[,]")).alias('Columns'))

        datetime_dict=self.schema_df.select('Expected_Columnname','Expected_DatetimeFormat').rdd.collectAsMap()
        mapping_expr = create_map([lit(x) for x in chain(*datetime_dict.items())])
        df_col_date=df_columns.withColumn("dateformat", mapping_expr[col('Columns')])

        ls_columns_int_string_filtered=df_col_date.filter(df_columns.Columns.isin(strings))       
        date_formats=ls_columns_int_string_filtered.rdd.collectAsMap()       

        date_df1 = self.spark.createDataFrame([], StructType([])) 
        date_dict={}
        for alias,dtformat in date_formats.items():
            cond=functools.reduce(operator.or_,[to_timestamp(col(alias),dtformat).isNull()])        
            print('cond is',cond)
            len_success_df=data.select(col('id'),col(alias)).withColumn('date_success',when(cond,False).otherwise(True)) 
            df=len_success_df.filter(col('date_success')==False)
            var=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
            if len(var)!=0:
                date_dict[alias]=df.select(col('id')).rdd.flatMap(lambda x: x).collect()

        return date_dict
     
        

    def fn_validate_schema_precision_Scale(self,data,strings):

        """
                Validates the precision and scale of data against the schema.

                This function checks whether the data in the provided columns conforms to the expected precision and scale defined in the schema. It performs data validation by reading the data from a temporary file and comparing it with the expected schema. If any values fail to conform to the expected schema, the row IDs with violations are collected and returned.

                Parameters:
                    data (DataFrame): The input DataFrame to be validated against the schema.
                    strings (list): A list of column names that should be validated for precision and scale.

                Returns:
                    dict: A dictionary where the key 'datatypefailed' contains a list of row IDs where the data did not conform to the expected schema precision and scale.
        """

        if self.fnt_id=='32':
            struct_type=self.fn_write_to_temp_path(data.select([c for c in data.columns if c not in {'Sequence within Line'}]))
        else:
            struct_type=self.fn_write_to_temp_path(data)

        print('temp path is',self.temp_file_path+'/'+self.temp_file_name)
        plain=self.spark.read.schema(struct_type).csv(self.temp_file_path+'/'+self.temp_file_name,header=True)

        print('plain data is',plain)
        print('plain schema is',plain.schema)
        print('file name',self.temp_file_path+'/'+self.temp_file_name)
        length_dict={}
        final_data=self.spark.read.schema(struct_type).option("primitivesAsString", True).option('mode','PERMISSIVE')\
                                     .csv(self.temp_file_path+'/'+self.temp_file_name,header=True,multiLine=False)

        print('DATA IN DATTPE')
        print('FINAL DATA')
        final_data_filled=final_data.withColumn('Datatype_success',when(col('_corrupt_record').isNull(),True).otherwise(False))
        datatype_success_df,datatype_failure_df=final_data_filled\
                                                .filter(col('Datatype_success')==True)\
                                                .drop('_corrupt_record'),final_data_filled\
                                                .filter(col('Datatype_success')==False).drop('_corrupt_record')
        var=datatype_failure_df.select(col('id')).rdd.flatMap(lambda x: x).collect()
        if len(var)!=0:
             length_dict['datatypefailed']=datatype_failure_df.select(col('id')).rdd.flatMap(lambda x: x).collect()
        return length_dict
    
    def fn_checkregex(self,data,strings):
        """
            Validates data columns against specified regular expressions.

            This function checks whether the values in the specified columns match the expected regular expressions defined in the schema. The validation is applied to the given list of column names, and the row IDs with values that do not match the regex pattern are collected and returned.

            Parameters:
                data (DataFrame): The input DataFrame containing the data to be validated.
                strings (list): A list of column names that should be validated against the regex patterns.

            Returns:
                dict: A dictionary where each key is a column name and the value is a list of row IDs where the values did not match the expected regex pattern.
        """

        df_columns=self.att_df.filter("File_Attribute_Name='CheckRegex'").select(explode(split("Columnnames", "[,]")).alias('Columns'))
    
        datetime_dict=self.schema_df.select('Expected_Columnname','Expected_Regex').rdd.collectAsMap()
        mapping_expr = create_map([lit(x) for x in chain(*datetime_dict.items())])
        ls_columns_regex=df_columns.withColumn("regex", mapping_expr[col('Columns')])
        ls_columns_regex_filtered=ls_columns_regex.filter(df_columns.Columns.isin(strings))       
        column_names=ls_columns_regex_filtered.rdd.collectAsMap()       
        reg_df1 = self.spark.createDataFrame([], StructType([]))

        regex_dict={}
        for columns,regex in column_names.items():
            print('regex-columns',columns)
            cond=functools.reduce(operator.or_,[(col(columns)).rlike(regex)])
            reg_success_df=data.select(col('id'),col(columns)).withColumn('regex_success',when(cond,True).otherwise(False)) 
            df=reg_success_df.filter(col('regex_success')==False)
            var=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
            if len(var)!=0:
                regex_dict[columns]=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
        print('regex_completed')
        return regex_dict
    
    def fn_check_column_value_length(self,data,strings):

        """
            Validates the length of values in the specified columns.
            This function checks whether the values in the specified columns meet the expected length criteria.
            It compares the length of each column's values with the predefined length and flags any value 
            that is either shorter than the minimum length or exceeds the maximum length.
            Parameters:
                data (DataFrame): The input DataFrame containing the data to be validated.
                strings (list): A list of column names to validate for length.
            Returns:
                dict: A dictionary where each key is a column name and the value is a list of row IDs where 
                    the length validation failed (i.e., the value is either too short or too long).
        """

        df_columns=self.att_df.filter("File_Attribute_Name='check_value_length'").select(explode(split("Columnnames", "[,]")).alias('Columns'))
 
        length_dict=self.schema_df.select('Expected_Columnname','Expected_Length').rdd.collectAsMap()
        mapping_expr = create_map([lit(x) for x in chain(*length_dict.items())])
        df_col_len=df_columns.withColumn("length", mapping_expr[col('Columns')])
        ls_columns_int_string_filtered=df_col_len.filter(df_columns.Columns.isin(strings))       
        column_names=ls_columns_int_string_filtered.rdd.collectAsMap()

        length_df1 = self.spark.createDataFrame([], StructType([]))
        colvalue_length={}
        for columns,max_length in column_names.items():
            cond=functools.reduce(operator.or_,[(length(col(columns))<3) | (length(col(columns))>max_length)])
            columnvalues_success_df=data.select(col('id'),col(columns)).withColumn('valuelen_success',when(cond,False).otherwise(True)) 
            df=columnvalues_success_df.filter(col('valuelen_success')==False)
            var=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
            if len(var)!=0:
                colvalue_length[columns]=df.select(col('id')).rdd.flatMap(lambda x: x).collect()

        return colvalue_length
        
    def fn_check_unique_column_values(self,data,strings):
        """
            Checks if values in the specified columns are unique.
            This function identifies columns in the data that should have unique values. It returns two DataFrames:
            one containing the unique rows and another containing rows with duplicate values in the specified columns.
            Parameters:
                data (DataFrame): The input DataFrame containing the data to be validated.
                strings (list): A list of column names to check for uniqueness (not used directly in the current implementation).
            Returns:
                tuple: A tuple containing two DataFrames:
                    - `unique_col_failure_df`: A DataFrame with rows that have duplicate values in the specified columns.
                    - `unique_columns_df`: A DataFrame with only the unique rows.
        """
        unique_columns_df=data.distinct()
        dup_columns_df=data.exceptAll(data.drop_duplicates())
        unique_col_failure_df1=dup_columns_df.withColumn('Checkuniquerow_success',lit("false").cast(BooleanType()))
        unique_col_failure_df=unique_col_failure_df1.withColumn('Column_success',lit("check_unique_column_values").cast(StringType()))
        return unique_col_failure_df,unique_columns_df
    
    def fn_check_column_values(self,data,strings): 
        """
            Validates that the values in the specified columns start and end with expected values.

            This function checks whether the values in the specified columns begin with a predefined start value
            and end with a predefined end value. If the condition is not met, the corresponding row ID is collected
            and returned.

            Parameters:
                data (DataFrame): The input DataFrame containing the data to be validated.
                strings (list): A list of column names to validate for start and end values.

            Returns:
                dict: A dictionary where each key is a column name and the value is a list of row IDs where 
                    the start and/or end value validation failed (i.e., the value does not start or end with the expected value).
        """       
        ls_columns_string1=self.att_df.filter("File_Attribute_Name='Check_required_values'").select(explode(split("Columnnames", "[,]")).alias('Columns'))
        start_val=self.schema_df.select('Expected_Columnname','Expected_startvalue').rdd.collectAsMap()
        end_val=self.schema_df.select('Expected_Columnname','Expected_endvalue').rdd.collectAsMap()
        mapping_expr = create_map([lit(x) for x in chain(*start_val.items())])
        mapping_expr1 = create_map([lit(x) for x in chain(*end_val.items())])
        ls_columns_string1_df=ls_columns_string1.withColumn("startvalue", mapping_expr[col('Columns')])
        ls_columns_string1_df2=ls_columns_string1_df.withColumn("endvalue", mapping_expr1[col('Columns')])

        ls_columns_string1_filtered=ls_columns_string1_df2.filter(ls_columns_string1.Columns.isin(strings))
        column_name1=ls_columns_string1_filtered.rdd.collect()
        val_df1 = self.spark.createDataFrame([], StructType([]))
        colvalues_dict={}
        for columns,startval,endval in column_name1:
            print('check_required_values-columns',columns)
            cond=functools.reduce(operator.or_,[((col(columns)).startswith(startval)) & ((col(columns)).endswith(endval)) ])

            colvalue_success_df=data.select(col('id'),col(columns)).withColumn('colvalues_success',when(cond,True).otherwise(False)) 
            df=colvalue_success_df.filter(col('colvalues_success')==False)
            var=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
            if len(var)!=0:
                colvalues_dict[columns]=df.select(col('id')).rdd.flatMap(lambda x: x).collect()

        print('check_required_values-completed')
        return colvalues_dict
      
    def fn_checkcolumnsum(self,data,strings):
        """
            Validates the sum of values in specified columns.
            This function checks the sum of values for specified columns and verifies if the sum is equal to 10.
            If the sum is not equal to 10, the row ID is collected and returned.
            Parameters:
                data (DataFrame): The input DataFrame containing the data to be validated.
                strings (list): A list of column names whose sum of values will be checked.
            Returns:
                dict: A dictionary where each key is a column name, and the value is a list of row IDs where the sum of the values
                    in the column is not equal to 10.
        """
        ls_columns_int_string=self.att_df.filter("File_Attribute_Name='CheckColumnCount'").select(explode(split("Columnnames", "[,]")).alias('Columns'))

        ls_columns_int_string_filtered=ls_columns_int_string.filter(ls_columns_int_string.Columns.isin(strings))       
        columnsum_val=ls_columns_int_string_filtered.rdd.flatMap(lambda x: x).collect()
        sum_df1 = self.spark.createDataFrame([], StructType([]))
        colsum={}
       
        check_cond_df=data.withColumn("ColumnSum", bi.sum(data[col] for col in columnsum_val))

        colsum_success_df=check_cond_df.withColumn('colsum_success',when(check_cond_df['ColumnSum']!=10,False).otherwise(True)) 
        df=colsum_success_df.filter(func.col('colsum_success')==False)
        var=df.select(func.col('id')).rdd.flatMap(lambda x: x).collect()
        for col in columnsum_val:
            if len(var)!=0:
                colsum[col]=df.select(func.col('id')).rdd.flatMap(lambda x: x).collect()

        return colsum
      
    def fn_checkcolumn_value_range(self,data,strings):
        """
            Validates the values in specified columns based on a defined range.
            This function checks if the values in the specified columns fall within a given range (between `start_range` and `end_range`).
            If any value is outside the specified range, the corresponding row ID is collected and returned.
            Parameters:
                data (DataFrame): The input DataFrame containing the data to be validated.
                strings (list): A list of column names whose values will be checked against the defined ranges.
            Returns:
                dict: A dictionary where each key is a column name, and the value is a list of row IDs where the value in the column is 
                    outside the specified range.
        """
        ls_column_name=self.att_df.filter("File_Attribute_Name='check_value_range'").select(explode(split("Columnnames", "[,]")).alias('Columns'))
        ls_column_name_filtered=ls_column_name.filter(ls_column_name.Columns.isin(strings))
        start_range=self.schema_df.select('Expected_Columnname','Expected_startrange').rdd.collectAsMap()
        end_range=self.schema_df.select('Expected_Columnname','Expected_endrange').rdd.collectAsMap() 
        mapping_expr = create_map([lit(x) for x in chain(*start_range.items())])
        mapping_expr1 = create_map([lit(x) for x in chain(*end_range.items())])
        ls_columns_string1_df=ls_column_name.withColumn("start_range", mapping_expr[col('Columns')])
        ls_columns_string1_df2=ls_columns_string1_df.withColumn("end_range", mapping_expr1[col('Columns')])
        ls_columns_string1_filtered=ls_columns_string1_df2.filter(ls_column_name.Columns.isin(strings))
        column_val=ls_columns_string1_filtered.rdd.collect()
        print('start_range---',start_range)
        print('end_range---',end_range)      

        range_df1 = self.spark.createDataFrame([], StructType([]))
        valrange_dict={}
        for cols,start_range,end_range in column_val:
            cond=functools.reduce(operator.or_,[data[cols].between(start_range,end_range) ])
            range_success_df=data.select(col('id'),col(cols)).withColumn('colvalues_success',when(cond,True).otherwise(False)) 
            df=range_success_df.filter(col('colvalues_success')==False)
            var=df.select(col('id')).rdd.flatMap(lambda x: x).collect()
            if len(var)!=0:
                valrange_dict[cols]=df.select(col('id')).rdd.flatMap(lambda x: x).collect()

        return valrange_dict
    
    def fn_write_to_temp_path(self,data):
        """
            Writes the given DataFrame to a temporary CSV file and returns the schema with additional fields.
            This function writes the input DataFrame to a specified temporary file path in CSV format. 
            Additionally, it appends new columns (`_corrupt_record`, `Source_file`, and `Tracking_Id`) to the DataFrame's schema 
            and returns the modified schema.
            Parameters:
                data (DataFrame): The DataFrame to be written to the temporary path.
            Returns:
                StructType: The modified schema of the DataFrame with the appended fields.
        """
        col_list=[Row[0] for Row in self.schema_df.filter("operation='column'").select('Expected_Columnname').collect()]
        data.write.format('csv').mode("overwrite").option('header','true').save(self.temp_file_path+'/'+self.temp_file_name)
        print('data schema--------',data.schema)
        to_prepend = [StructField("_corrupt_record",StringType(),True)]#StructField("Source_file",StringType(),True),StructField("Tracking_Id",StringType(),True)]
        schema=StructType(data.schema.fields+to_prepend)
        print('schema====',schema)
        return schema

  
    def fn_constructStruct(self):
        """
            Constructs a StructType schema based on the given schema DataFrame and returns it.
            This function filters the `schema_df` DataFrame to retrieve the columns where the 
            `operation` is set to 'column'. It then consolidates the schema using the `fn_consolidateSchema` 
            method and constructs a final `StructType` schema. The schema is printed in JSON format for validation 
            and then returned.
            Returns:
                StructType: The constructed StructType schema based on the filtered and consolidated schema.
        """
        schema_df=self.schema_df.filter("operation='column'")
        finallist=self.fn_consolidateSchema(schema_df)
        print('filanlist---',finallist)
        final_schema=StructType(finallist)
        print('schem in json',final_schema.json())
        
        return final_schema

    def fn_consolidateSchema(self,df):
        """
            Consolidates the schema information from the provided DataFrame into a list of StructFields.
            This function iterates over the rows of the given DataFrame (`df`), extracting schema 
            details like column name, data type, nullability, length, scale, and precision. It then 
            maps these attributes to a corresponding `StructField` using the `fn_map_dtype` method. 
            Additionally, three extra fields (`_corrupt_record`, `Source_file`, and `Tracking_Id`) 
            are appended to the schema list. The final list of schema fields is returned.
            Args:
                df (DataFrame): The DataFrame containing the schema information to be consolidated.
            Returns:
                list: A list of StructField objects representing the final schema.
        """
        ls=list()
        for a in df.rdd.collect():

          ls.append(self.fn_map_dtype(a['Expected_Columnname'],a['Expected_Datatype'],a['Is_Nullable'],a['Expected_Length'],a['Expected_Scale'],a['Expected_Precision']) )
        ls.append(StructField("_corrupt_record",StringType(),True))
        ls.append(StructField("Source_file",StringType(),True))
        ls.append(StructField("Tracking_Id",StringType(),True))
        print('list of schema is',ls)
        return ls
  
    def fn_map_dtype(self,name,dtype,nullable,length,scale=None,precision=None): 
        """
            Maps a column's attributes to a corresponding StructField based on its data type.

            This function takes in a column name, data type, nullability, length, scale, and precision 
            to map the data type to the appropriate Spark SQL type. It also considers whether the column 
            is nullable or not and creates a `StructField` with the corresponding metadata.

            Args:
                name (str): The name of the column.
                dtype (str): The data type of the column (e.g., 'string', 'int', 'decimal').
                nullable (str): A flag indicating whether the column is nullable ('1' for nullable, '0' for non-nullable).
                length (str): The length of the column (if applicable).
                scale (str, optional): The scale of the decimal type (if applicable). Defaults to None.
                precision (str, optional): The precision of the decimal type (if applicable). Defaults to None.

            Returns:
                StructField: A StructField object representing the column's data type and properties.
        """
        print('name,dtype,nullable,length,scale,precision',name,dtype,nullable,length,scale,precision)
        type=None
        metadata=None
        nullabilty=None

        if dtype=="string" or dtype=="UUID" or dtype=='varchar' or dtype=='nvarchar' or dtype=='char':
            type=StringType()

        elif dtype=="int" or dtype=='bigint' or dtype=='short':
            type=LongType()

        elif dtype=="decimal" or dtype=='float':
            type=DecimalType(int(precision),int(scale))

        elif dtype=="timestamp" or dtype=='datetime':
            type=StringType()
        elif dtype=='date':
            type=StringType()
        elif dtype=="bit" or dtype=='boolean':
            type=BooleanType()
        if nullable=='1':
            nullabilty=True
        elif nullable=='0':
            nullabilty=False
        if type is not None:
            structfield=StructField(name,type,nullable= nullabilty,metadata=metadata)
        return structfield
 
    def fn_getattributesValidation(self,data):  
        """
            Performs attribute validation on the provided data based on the validation rules defined in 
            the class attributes. This function iterates through the `order_of_validation` list, 
            performs validation checks on columns, and categorizes the rows into good and bad rows 
            based on the validation results.
            The function checks if validation is needed for each attribute and applies the corresponding 
            validation function to each column listed in the attribute's `Columnnames`. The validation 
            results are returned as a DataFrame with additional columns indicating the validation type 
            and the column being validated.
            Args:
                data (DataFrame): The input data to be validated.
            Returns:
                tuple: A tuple containing three DataFrames:
                    - `baddf`: DataFrame containing rows that failed validation.
                    - `good_df`: DataFrame containing rows that passed validation.
                    - `error_df`: DataFrame with the validation errors for the failed rows.
        """  
        subresult={}    
        list_of_baddfs={}
        act_goodrows_df1 = self.spark.createDataFrame([], StructType([]))
        goodrows_df=data
        print('insidevalidation',goodrows_df.count())
        unique={}
        for a in self.order_of_validation.values():
            print('a is',a) 
  
            if a in [val['File_Attribute_Name'] for val in self.attributes]:
                b1=[val for val in self.attributes if val['File_Attribute_Name']==a][0] 
                print('b1 is',b1)
                print('b1 is',type(b1))
                if b1['Validation_Needed']==True:   
                    print('validation---',b1['File_Attribute_Name'])
                    print('------------------------------')
                    Columnnames = b1['Columnnames']
                    strings = Columnnames.replace(',',' ').split()
                    goodrows_df
                    unique_dict=self.function_mapper[b1['File_Attribute_Name']](data,strings)
                    unique[b1['File_Attribute_Name']]=unique_dict
                    
        print('uniqueeeeeeeeeeee')
        dict1={}
        l=[]

        for a,b in unique.items():
            for c,d in b.items():


                df=self.spark.createDataFrame(d,StringType())
                df=df.withColumn('column',lit(c))
                df=df.withColumn('Validationtype',lit(a))
                l.append(df)
        print('after lops')
        if len(l)>0:
            df_series = reduce(DataFrame.unionAll,l)
            print('reduced df_series')
            print(df_series.count())
            df_series=df_series.withColumnRenamed('value','id')
            error_df=df_series
            df1=df_series.withColumn('combined',concat(col('Validationtype'),lit('_',),col('column'))).drop('Validationtype','column')
            df2=df1.groupBy(col('id')).agg(collect_list(col('combined')).alias('column_success'))
            df=df2.withColumn('column_success',df2.column_success.cast(StringType()))
            df.persist()
            print('dict for baddf')            
            print('converting tuple to dataframe')
            print('main dataframe')
            print('before baddf')
            data.printSchema()
            df=df.withColumn('id',df.id.cast(LongType()))
            df.printSchema()
            good_df=data.join(df, data.id == df.id, "left_outer").where(df.id.isNull()).drop(df.id)
            print('after filtering good_df')
            good_df.show()
            baddf=data.join(df,on='id')
            good_df=good_df.cache()
            print('aftering filtering baddf')
            baddf=baddf.withColumn('tracking_id',lit(self.job_run_id))
            print('baadf with tracking id')
        else:
            good_df=data
            baddf= self.spark.createDataFrame([], StructType([]))
            error_df=self.spark.createDataFrame([], StructType([]))
        return baddf,good_df,error_df
  
    

