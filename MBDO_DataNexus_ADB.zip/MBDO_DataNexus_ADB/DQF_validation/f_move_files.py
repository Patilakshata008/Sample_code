
from pyspark.sql.types import StringType,StructField,StructType,LongType,DecimalType,DateType,TimestampType,FloatType,BooleanType
import json
from common_func.f_logs import *
from pyspark.sql.functions import *
from pyspark.sql import functions as func
from functools import reduce  
class Movefiles:
    def __init__(self,dbasecon,uf,config,source_dl_layer,dest_dl_layer,path,fileTemplate,spark,FNT_ID,dbwriter,SourceSystem):
        """
            Initializes an instance for processing Delta Lake data and performing database operations.

            This constructor initializes the necessary configurations, schema, and connections for loading data from a source data lake layer to a destination data lake layer, and for interacting with a Delta table in a database. The method accepts a variety of configuration parameters related to the Delta table, schema, file handling, and source/destination layers.

            Args:
                dbasecon (obj): A database connection or utility function for interacting with the database.
                uf (obj): A utility function or class for managing the database connection.
                config (dict): A dictionary containing configuration settings such as Delta table names, database name, and schema.
                source_dl_layer (str): The source data lake layer from which data will be loaded.
                dest_dl_layer (str): The destination data lake layer to which data will be written.
                path (str): The file path where data will be stored or retrieved.
                fileTemplate (str): The template for files, often used for file naming or path construction.
                spark (SparkSession): An active Spark session used for reading and processing data.
                FNT_ID (str): An identifier for the current data processing task or batch.
                dbwriter (obj): A database writer object or utility for writing data to the database.
                SourceSystem (str): The name or identifier of the source system from which data originates.

            Attributes:
                dbcon (obj): The database connection object used for interacting with the database.
                config (dict): The configuration settings for the Delta table and other parameters.
                SourceSystem (str): The name of the source system for data.
                dbname (str): The database name, prefixed with 'silver.'.
                tablename (str): The name of the table in the database.
                spark (SparkSession): The Spark session used for processing.
                schema (dict): The schema used for defining the data structure.
                sc (SparkContext): The SparkContext object used by the Spark session.
                schema_df (DataFrame): The schema as a DataFrame.
                columns (list): The list of expected column names from the schema.
                source_dl_layer (str): The source data lake layer.
                dest_dl_layer (str): The destination data lake layer.
                path (str): The file path for storing or retrieving data.
                FNT_ID (str): The identifier for the data processing task.
                dbasecon (obj): The utility function or class for managing the database connection.
                FileTemplate (str): The file template for constructing file paths or names.
                dbw (obj): The database writer utility for writing data to the database.
        """

        self.dbcon=dbasecon
        self.config=config
        self.SourceSystem=SourceSystem
        self.dbname='mbdo_silver_dev.'+self.config['deltalake_configs']['DbName']
        self.tablename=self.config['deltalake_configs']['TabelName']
        self.spark=spark
        self.schema=config['schema']
        self.sc=self.spark.sparkContext
        self.schema_df=self.spark.read.json(self.sc.parallelize([json.dumps(self.schema)]))
        self.columns=self.schema_df.filter("operation='column'").rdd.map(lambda a:a['Expected_Columnname']).collect()
        self.source_dl_layer=source_dl_layer
        self.dest_dl_layer=dest_dl_layer
        self.path=path
        self.FNT_ID=FNT_ID
        self.dbasecon=uf
        self.FileTemplate=fileTemplate
        self.dbw=dbwriter
    
    
    def get_dbutils(self):
        """
            Retrieves the dbutils object for interacting with the Databricks environment.

            This method attempts to import the necessary dbutils module for managing Databricks utilities. If the environment is not Databricks, it falls back to using IPython's `user_ns` to retrieve `dbutils`. The `dbutils` object is used for various operations like file management, secret management, and job-related tasks in Databricks.

            Returns:
                dbutils (obj): The dbutils object, which provides utility functions for working with Databricks services.

            Raises:
                ImportError: If the necessary modules cannot be imported.
        """

        try:
            from pyspark.dbutils import DBUtils
            dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython
            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils
    
    def fn_move_file(self,srcpath,destPath):
        """
            Moves a file from the source path to the destination path in the Databricks File System (DBFS).

            This method checks the format of the source and destination paths, ensuring they are in the correct `dbfs:/` format. If the paths start with `/dbfs/`, they are adjusted to the appropriate `dbfs:/` format. The file is then moved using the `dbutils.fs.mv` function.

            Args:
                srcpath (str): The source path of the file to be moved. Can be either a local or DBFS path.
                destPath (str): The destination path where the file should be moved. Should be a DBFS path.

            Returns:
                tuple: A tuple containing the source and destination paths (`srcpath`, `destPath`).

            Raises:
                AttributeError: If the `dbutils` module cannot be imported or accessed.
                FileNotFoundError: If the source file does not exist.
        """
        dbutils=self.get_dbutils()
        print('src and dest are',srcpath ,destPath)
        if srcpath.startswith('/dbfs/'):
            actual_src_path=srcpath.replace("/dbfs/","dbfs:/")
        else:
            actual_src_path='dbfs:'+srcpath

        if destPath.startswith('dbfs:'):
            actual_destpath=destPath
        else:
            actual_destpath='dbfs:'+destPath  
        
        dbutils.fs.mv(actual_src_path,actual_destpath)
        return srcpath,destPath
    
    def fn_move_error_files(self,filepath,ref_tracking_id,file_id):
        """
                Moves a file to an error folder and logs an alert when there is a data quality failure.

                This method handles moving a file that has encountered a data quality issue to an error directory. It constructs the error file path based on the provided source file path, file details, and a date partition. The method also triggers an alert with the reference tracking ID indicating a data quality failure.

                Args:
                    filepath (str): The source file path of the file that has encountered a data quality issue.
                    ref_tracking_id (str): The reference tracking ID associated with the file being moved.
                    file_id (str): The ID of the file being moved.

                Returns:
                    dict: A dictionary containing the `filename`, `destpath`, `ref_tracking_id`, and `file_id` for the moved file.

                Raises:
                    FileNotFoundError: If the source file does not exist at the specified location.
                    AttributeError: If the `fn_move_file` or other functions cannot be accessed properly.
                    Exception: If there is an error during the alert creation process or while moving the file.
        """

        dict_mv={}
        srcpath=filepath
        file=filepath[1]
        
        x=file.split("/")
        print('x is',x)
        filename= x[len(x)-1]
        hie_folder=self.dbasecon.fn_put_datepartition()

        dest_reqpath=self.path['Bronze-Error']
        destpath=dest_reqpath+self.FileTemplate+hie_folder+filename
        print("src and dest path are",srcpath,destpath)
        srcpath,destpath= self.fn_move_file(srcpath[1],destpath)
        print("File moved to error path")
        dict_mv['filename']=filename
        dict_mv['destpath']=destpath
        dict_mv['ref_tracking_id']=ref_tracking_id
        dict_mv['file_id']=file_id
        
        self.dbw.fn_add_alerts(self.FNT_ID,'DQF_FAILURE_RECORDS','The tracking id is '+(ref_tracking_id))
        print("Error alerts updated successfully")
        return dict_mv
  
    def fn_consolidateErrors(self,baddf):
        """
            Consolidates error data from multiple DataFrames and ensures required columns are present.

            This method processes a dictionary of DataFrames containing error records. It checks for missing columns (success flags and column-specific success indicators) and adds any missing columns with a default value of `True`. The DataFrames are then merged into one by unioning them, while ensuring that the columns are sorted consistently.

            Args:
                baddf (dict): A dictionary where keys are identifiers for error categories and values are DataFrames containing error records. Each DataFrame should have columns representing the columns being checked for errors.

            Returns:
                DataFrame: A consolidated DataFrame containing all the error records from the input DataFrames, with missing success columns added and columns sorted in a consistent order.

            Raises:
                KeyError: If the expected structure of the input DataFrame does not match the expected keys.
                Exception: If there is an error while merging the DataFrames or adding missing columns.
        """

        print('keys are',baddf.keys())
        allkeys=[a+'_success' for a in baddf.keys()]
        allkeys.append('Column_success')
        newbaddf={}
        for k,v  in baddf.items():
            print('key is',k)
            missed=set(allkeys)-set(v.columns)
            print('missed is',missed)
            for val in missed:
                v=v.withColumn(val,lit(True))
                
            newbaddf[k]=v

            print('after adding',v.columns)
            add_col=['Source_file','Tracking_Id']
        return reduce(DataFrame.unionByName,[a.select(sorted(self.columns+allkeys+add_col)) for a in newbaddf.values()])

    def fn_move_baddf_silver(self,badrows_df,path,FileTemplate,uf):
        """
            Moves error records (bad rows) to the Silver layer in Delta format.

            This method takes a DataFrame of bad rows, processes it by ensuring all columns are cast to strings, 
            and then writes the processed DataFrame to the Silver layer of the Delta Lake, appending it to an 
            existing table. The table's path is dynamically constructed using a template and partitioning strategy 
            based on the current date.

            Args:
                badrows_df (DataFrame): A DataFrame containing error records (bad rows) to be moved to the Silver layer.
                path (dict): A dictionary containing various path configurations, including the Silver layer error path.
                FileTemplate (str): A string template used for constructing the file path in the Silver layer.
                uf (object): A database connection or utility object used for partitioning or other operations (not directly used in this method).

            Returns:
                None: This function performs a side-effect by writing the error records to a Delta table in the Silver layer.

            Raises:
                Exception: If there is an error while processing or writing the DataFrame to the Delta table.
        """

        errpath=self.path['Silver-Error']
        folder_date=self.dbasecon.fn_put_datepartition()

        path1=errpath+FileTemplate
        print("FileTemplate--------->>>>",FileTemplate)
        print("path1--------->>>>",path1)
        for column in badrows_df.columns:
            print("bad column is",column)
   
        badrows_df=badrows_df.select([func.col(f"`{column}`").cast('string') for column in badrows_df.columns])
        badrows_df.repartition(100).write.format("delta").mode("append").option('path',path1).option('overwriteSchema','true').saveAsTable(self.dbname+'.'+self.tablename+'_baddfdata')