
import json
from f_csvtxt_reader import *
from f_json_reader import *
from f_xml_reader import *
from f_move_files import *
from f_xlsx_reader import xlsxreader
from f_pdf_reader import *
from f_parquet_reader import *
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType,StructField,StructType,LongType,DecimalType,DateType,TimestampType,FloatType,BooleanType
from pyspark.sql import functions as func
from functools import reduce  # For Python 3.x
from pyspark.sql import DataFrame
from f_json_2reader import *
import operator
from pyspark.sql.functions import input_file_name

class masterdata:
    def __init__(self,dbwrite,dbread,tracking_id,ref_tracking_ids,config,list_of_files,IOTFlag,spark,mvfl,track_id):
        """
                Initializes the class with configurations for reading and processing various file types.

                This constructor method sets up all the necessary configurations for reading data from different 
                file formats (e.g., JSON, CSV, Parquet, XML) based on provided configuration parameters. It also 
                initializes various objects needed for reading files and processing data, such as schema definitions, 
                delimiter handling, and function mappings for processing specific file formats.

                Args:
                    dbwrite (object): Database writer object for writing processed data.
                    dbread (object): Database reader object for reading data.
                    tracking_id (str): Unique ID for tracking the current job run.
                    ref_tracking_ids (str): Reference IDs for tracking related jobs.
                    config (dict): A dictionary containing all the configuration settings (e.g., file read configs, delta lake configs).
                    list_of_files (list): A list of file paths to be processed.
                    IOTFlag (bool): A flag indicating whether the process involves IoT data.
                    spark (SparkSession): The Spark session object used for distributed data processing.
                    mvfl (object): An object related to the movement of files (e.g., file mover or management).
                    track_id (str): The unique tracking ID for the file processing operation.

                Attributes:
                    dbwrite (object): The database writer object.
                    dbread (object): The database reader object.
                    spark (SparkSession): The Spark session object.
                    track_id (str): The tracking ID for the current job.
                    duplicate_rows (int): Counter for duplicate rows (initialized to 0).
                    fnt_id (str): The file processing ID retrieved from config.
                    File_Schema (str): Expected file schema as per the configuration.
                    Duplicatecheck_Needed (bool): A flag indicating if duplicate check is needed.
                    expected_timestamp_col (str): Expected timestamp column name.
                    configs (dict): Delta Lake configuration settings.
                    key (list): List of key columns, if specified in the config.
                    mov (object): File management or movement handler.
                    job_run_id (str): Job run ID.
                    ref_tracking_ids (str): Reference tracking IDs for related jobs.
                    header (bool): Flag indicating whether the file has a header.
                    delimiter (str): The delimiter used in the files.
                    schema (dict): Schema configuration.
                    repartition (int): Number of partitions for repartitioning.
                    IOTFlag (bool): Flag for IoT data processing.
                    xmlroottag (str): Root tag for XML data, if applicable.
                    xmldetailstag (str): Detail tags for XML data, if applicable.
                    list_of_files (list): List of file paths for processing.
                    columns (list): List of expected column names as per the schema.
                    fileType (str): Type of file being processed (e.g., CSV, JSON, etc.).
                    file_read_configs (dict): Configurations specific to reading files.
                    csv_obj (object): CSV file reader object.
                    json_obj (object): JSON file reader object.
                    json_obj2 (object): Another JSON reader object for a specific format.
                    xml_obj (object): XML file reader object.
                    parquet_obj (object): Parquet file reader object.
                    function_mapper (dict): Dictionary of functions for handling different JSON formats.
                    function_mapper_parq (dict): Dictionary of functions for handling different Parquet formats.
                    schema1 (StructType): Schema for file metadata (e.g., file ID, file path).
                    id_path (RDD): Spark RDD containing the list of file paths to process.

                Returns:
                    None: This method does not return any value. It initializes the instance with necessary configurations and objects.
        """

        self.dbwrite=dbwrite
        self.dbread=dbread
        self.spark = spark
        self.track_id=track_id
        self.duplicate_rows=0
        self.fnt_id=config['file_read_configs']['FNT_Id']
        self.File_Schema=config['file_read_configs']['Expected_Schema']
        self.Duplicatecheck_Needed=config['file_read_configs']['Duplicatecheck_Needed']
        self.expected_timestamp_col=config['file_read_configs']['expected_timestamp_col']
        self.configs=config['deltalake_configs']
        if self.configs['KeyColumns'] is not None and self.configs['KeyColumns']!='':
            self.key=self.configs['KeyColumns'].split(',')
        self.mov=mvfl

        self.job_run_id=tracking_id
        self.ref_tracking_ids=ref_tracking_ids
        self.header=config['file_read_configs']['is_header_present']
        self.delimiter=config['file_read_configs']['delimiter']
        self.schema=config['schema']
        self.repartition=config['file_read_configs']['repartition']
        self.IOTFlag=IOTFlag
        self.spark = spark
        self.sc=self.spark.sparkContext
        self.schema_df=self.spark.read.json(self.sc.parallelize([json.dumps(self.schema)]))
        self.xmlroottag=config['file_read_configs']['xmlroottag']
        self.xmldetailstag=config['file_read_configs']['xmldetailstag']

        self.list_of_files=list_of_files

        self.columns=self.schema_df.filter("operation='column'").rdd.map(lambda a:a['Expected_Columnname']).collect()
        self.fileType=config['file_read_configs']['File_Type']
        self.file_read_configs=config['file_read_configs']
        self.csv_obj=csvtxtdatareader(self.header,self.delimiter,self.spark)
        self.xlsx_obj = xlsxreader(self.header, self.spark,self.schema)
        self.pdf_obj = pdfreader(self.header, self.spark)
        self.json_obj=jsonreader(self.schema_df,self.IOTFlag)
        self.json_obj2=json2reader(self.spark,self.sc)
        self.xml_obj=xmldatareader(self.xmlroottag,self.xmldetailstag,self.File_Schema,self.fnt_id,self.spark)
        self.parquet_obj=parquetreader(self.header,self.spark,self.schema)
        self.function_mapper={'jsondata_32':self.json_obj2.jsondata_32,'jsondata_55':self.json_obj2.jsondata_55,'jsondata_96':self.json_obj2.jsondata_96}
        self.function_mapper_parq={'api_1_109':self.parquet_obj.api_1_109, 
                                   'api_4_113':self.parquet_obj.api_4_113, 
                                   'api_7_115':self.parquet_obj.api_7_115, 
                                   'api_3_112':self.parquet_obj.api_3_112,
                                   'api_6_114':self.parquet_obj.api_6_114,
                                   'api_9_116':self.parquet_obj.api_9_116,
                                   'api_8_117':self.parquet_obj.api_8_117,
                                   'db_1':self.parquet_obj.db_1,
                                   'fn_read_parquet':self.parquet_obj.fn_read_parquet
                                   }
        self.schema1=StructType([StructField('file_id',StringType(),True),StructField('filepath',StringType(),True)])
        self.id_path=self.spark.sparkContext.parallelize(self.list_of_files)

    def fn_readFiles(self):
        """
            Reads and processes files using the master data function.

            This method invokes the `fn_masterdata()` function to retrieve and process the master data. 
            It returns the processed data as a DataFrame.

            Returns:
                DataFrame: The processed data returned by the `fn_masterdata()` function.
        """
        dataframe=None
        data=self.fn_masterdata()
        return data
    
    def fn_masterdata(self):
        """
            The function to process and transform data from various file types (json, csv, txt, xml, parquet),
            aggregate metadata, and update row count and error statistics in the database.
        
            Parameters:
                None
            Returns:
                final_df (DataFrame): The transformed DataFrame with added columns for source file, tracking ID,
                                    and necessary aggregations.
        """

        expected_length=self.dbread.fn_get_no_columns_new(self.fnt_id)
        all_files=[]
        dict_error={}
        json_data=[]
        error_data=[]
        for file in self.list_of_files:
            all_files.append(file[1])
        print('all file paths are---',all_files)
        if self.fileType=='json':
            print('inside filereader at json function')
            tempdat=self.function_mapper[self.file_read_configs['data_func']](all_files)
            print('data in temp data')
        elif self.fileType=='csv' or self.fileType=='txt':
            tempdat=self.csv_obj.fn_readcsv_txt(all_files)
        elif self.fileType=='xlsx':
            print('Inside filereader at xlsx function')
            tempdat = self.xlsx_obj.fn_read_excel(all_files)
        elif self.fileType=='pdf':
            print('Inside filereader at pdf function')
            tempdat = self.pdf_obj.fn_read_pdf(all_files)
        elif self.fileType=='xml':
            tempdat=self.xml_obj.fn_readxml(all_files)
        elif self.fileType=='parquet':
            tempdat=self.function_mapper_parq[self.file_read_configs['data_func']](all_files)
        print('data in tempdata')
        
        #add source filename for each row
        print('temp dataframe is')
        if self.fileType=='parquet':
            tempdata1=tempdat.withColumn("Source_file",input_file_name())
            tempdata1=tempdata1.withColumn("Source_file",func.regexp_replace(f.col('Source_file'),"dbfs:",""))
            tempdata1=tempdata1.withColumn('Source_file',func.regexp_replace(col('Source_file'),'/part.*$','/'))
            row_cnt=tempdata1.count()
            print('total rows',row_cnt)
            tempdata2=tempdata1.groupBy('Source_file').agg(func.count("*").alias('row_cnt'))
            tempdata2=tempdata2.withColumn('filename',concat(func.expr("reverse(split(Source_file,'/'))[1]"),lit('/')))


        else:
            tempdata1=tempdat.withColumn("Source_file",input_file_name())

            tempdata1=tempdata1.withColumn("Source_file",func.regexp_replace(f.col('Source_file'),"dbfs:",""))

            row_cnt=tempdata1.count()
            print('total rows',row_cnt)
            #aggregating row count for each source file
            tempdata2=tempdata1.groupBy('Source_file').agg(func.count("*").alias('row_cnt'))
            #extracting file name
            tempdata2=tempdata2.withColumn('filename',func.expr("reverse(split(Source_file,'/'))[0]"))
            #creating new df based on file id and filepath
        id_path_df=self.spark.createDataFrame(self.id_path,self.schema1)

        joined_df=tempdata2.join(id_path_df,tempdata2['Source_file']==id_path_df['filepath'],'inner')
        print('df is')
        print(self.list_of_files)

        final_tempdata=tempdata1.withColumn("Tracking_Id",lit(str(self.job_run_id)))
        final_df=final_tempdata
        rows=joined_df.collect()
        list_of_dicts=[]
        for row in rows:
            dict_row=row.asDict()
            list_of_dicts.append(dict_row)
        print('list_of_dicts info:',list_of_dicts)
        for i in list_of_dicts:
            dict_data={}
            dict_data['filename']=i['filename']
            dict_data['row_cnt']=i['row_cnt']
            dict_data['file_id']=i['file_id']
            json_data.append(dict_data)
        print('json_data',json_data)
        self.dbwrite.fn_update_row_cnt_new(json_data)
        if self.Duplicatecheck_Needed==1:
            w = Window.partitionBy(self.key).orderBy(func.desc(self.expected_timestamp_col))
            final_tempdata=final_tempdata.withColumn("rn", func.row_number().over(w)).filter("rn = 1").drop("rn")
            self.duplicate_rows=final_df.count()-final_tempdata.count()
            final_df=final_tempdata
        dict_error['ref_tracking_ids']=self.ref_tracking_ids
        dict_error['error_row_cnt']=0
        dict_error['duplicate_data_cnt']=self.duplicate_rows
        dict_error['expected_length']=expected_length
        dict_error['Tracking_Id']=self.track_id
        error_data.append(dict_error)
        print('error_data',error_data)
        self.dbwrite.fn_update_error_row_cnt_new(error_data)
        final_df.persist()
        return final_df
