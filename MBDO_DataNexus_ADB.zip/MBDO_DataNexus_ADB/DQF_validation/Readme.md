# Data Quality Framework (DQF) Validation

## Overview

The Data Quality Framework (DQF) module is designed to perform data validation checks and apply various rules to ensure the integrity and quality of the data. The rules are defined in the metadata layer and are applied at the column level. The framework ensures that the data meets predefined standards before being processed further.

## Modules

### DQF_validation

This module contains the code for data quality validation. DQF rules are maintained in the Metadata Layer and can be applied at the column level (e.g., Missing Mandatory values, Value range check, Date formats, Datatype checks, etc.). Configured checks are validated against the valid files from the Bronze Layer.

---

### f_attribute_validator4.py

The `AttributeValidator` class performs various data validation checks on a given dataset using PySpark.

#### Imports and Setup:
- Import necessary libraries such as `pyspark.sql.functions`, `itertools`, `builtins`, `functools`, and `operator`.
- Define the `AttributeValidator` class with an `__init__` method to initialize configuration, schema, and other parameters.

#### Main Validation Functions:
- **fn_filternulls**: Checks for null values in non-nullable columns.
- **fn_checklength**: Validates the length of column values.
- **fn_check_date_time_format**: Validates the date and time format of column values.
- **fn_validate_schema_precision_Scale**: Validates the schema precision and scale.
- **fn_checkregex**: Validates column values against a regex pattern.
- **fn_check_column_value_length**: Checks the length of column values.
- **fn_check_unique_column_values**: Checks for unique values in columns.
- **fn_check_column_values**: Validates required values in columns.
- **fn_checkcolumnsum**: Checks the sum of column values.
- **fn_checkcolumn_value_range**: Validates the range of column values.

#### Helper Functions:
- **fn_write_to_temp_path**: Writes data to a temporary path and constructs a schema.
- **fn_constructStruct**: Constructs a schema from the configuration.
- **fn_consolidateSchema**: Consolidates the schema.
- **fn_map_dtype**: Maps data types to Spark data types.

#### Main Validation Function:
- **fn_getattributesValidation**: Main function that performs all validations in a specified order, collects validation results, and identifies bad and good data rows.

---

### f_csvtxt_reader.py

The code defines the `AttributeValidator` class for validating datasets using PySpark. Similar functions and operations to `f_attribute_validator4.py` are applied here for reading and validating CSV and text files.

---

### f_data_masking.py

This module handles data masking operations on a given dataset using PySpark.

#### Imports and Setup:
- Import necessary libraries such as `pyspark.sql.functions`, `cryptography.fernet`, `random`, and `json`.

#### Data Masking Functions:
- **mask_token_func**: Masks a portion of the string with 'x'.
- **mask_encrypt_func**: Encrypts the string using Fernet encryption.
- **mask_scrumbling**: Shuffles characters in the string.

#### Data Masking Method:
- **data_mask**: Applies the appropriate masking function to specified columns based on the configuration and returns the masked DataFrame.

---

### f_data_unmasking.py

This module handles data unmasking operations using PySpark.

#### Unmasking Functions:
- **data_mask**: Decrypts values using Fernet encryption, applying the decryption function based on the configuration and returning the decrypted DataFrame.

---

### f_db_configreader.py

This module retrieves various database configurations.

#### Methods:
- **Get Schema**: Retrieves schema details from the database using a stored procedure.
- **Get List of Attributes**: Retrieves a list of attributes from the database.
- **Get Delta Lake Configurations**: Retrieves Delta Lake configurations from the database.
- **Get Paths**: Retrieves file paths from the database.
- **Get IoT Data Configurations**: Retrieves IoT data configurations from the database.
- **Get Kafka Metadata**: Retrieves Kafka metadata from the database.

---

### f_db_reader.py

This class interacts with a database to retrieve specific information.

#### Methods:
- **Get XML Tags**: Retrieves XML tags from the database.
- **Get Files for DQF**: Retrieves files for DQF from the database.
- **Get Number of Columns**: Retrieves the number of columns for a given file.
- **Get Number of Rows**: Retrieves the number of rows for a given tracking ID and file template ID.

---

### f_db_writers.py

This class updates the status, row counts, and logs in the database using stored procedures.

#### Methods:
- **Update Error Status**: Updates error status in the database.
- **Update Row Count**: Updates row count in the database.
- **Insert Delta Summary Logs**: Inserts delta summary logs into the database.

---

### f_delta_table_load.py

The `DeltaTableLoad` class handles loading data into Delta tables using different strategies.

#### Methods:
- **Delta Load Append**: Appends data to the Delta table.
- **Delta Load Full**: Performs a full load (overwrite) to the Delta table.
- **Delta Load Merge**: Merges data into the Delta table using the merge operation.
- **Table Load**: Determines the type of load (append, full, or merge) and calls the corresponding function.

---

### f_extract_channels.py

The `ChannelExtractor` class extracts timestamps and values (samples) from a specific channel in an MDF (Measurement Data Format) file.

#### Methods:
- **Extract Channel Timestamp**: Extracts timestamps from the specified channel in the MDF file.
- **Extract Channel Values**: Extracts values (samples) from the specified channel in the MDF file.

---

### f_file_reader.py

This module handles reading, validating, and processing various file types using PySpark.

#### Methods:
- **Read Files**: Reads files based on the file type (CSV, JSON, etc.) and processes them.
- **Master Data Processing**: Processes the master data by reading files, validating columns, and handling errors.

---

### f_file_reader2.py

The code defines the `masterdata` class that handles file reading, validation, and processing using PySpark. It includes various methods for reading and processing files (JSON, CSV, TXT, XML, Parquet), adding tracking IDs, checking for duplicates, and updating the row counts in the database.

---

### f_json_reader.py

This class reads and processes JSON files using PySpark. It handles various JSON-related tasks such as reading and parsing JSON files, validating columns, and processing the data for further use.
