
from delta.tables import *
import pyspark.sql.functions  as F
from pyspark.sql import Window
from pyspark.sql.functions import spark_partition_id, asc, desc
import uuid
from pyspark.sql.functions import lit,current_timestamp

class DeltaTableLoad:
    def __init__(self,config,targetpath,gooddf,spark):
        """
            Initializes the class with configuration values, a DataFrame, and the Spark session.

            Parameters:
                config (dict): Configuration dictionary containing delta lake configurations, file read configurations, and other necessary parameters.
                targetpath (str): Path where data will be stored or loaded.
                gooddf (DataFrame): The DataFrame to be processed and loaded into the database.
                spark (SparkSession): The Spark session used for data processing.

            Attributes:
                targetpath (str): Path for storing or loading data.
                databasename (str): The name of the database with the 'silver.' prefix.
                tablename (str): The name of the table in the Delta Lake.
                mod_df (DataFrame): Modified DataFrame with an additional column for the current timestamp.
                DbLoadType (str): Type of load to be used for database loading.
                Duplicate_Check (str): Flag for whether duplicate check is needed.
                spark (SparkSession): Spark session used for data processing.
                configs (dict): The configuration dictionary for Delta Lake settings.
                fnt_id (str): The FNT ID extracted from the configuration.
                scd_enabled (bool): Whether Slowly Changing Dimension (SCD) is enabled.
                key (list): List of key columns to be used for partitioning or deduplication.
                partitioncolumn (list): List of partition columns, if any.
                WaterMarkColumns (list): List of watermark columns, if any.
                scdcolumn (list): List of SCD columns, if any.
        """
        self.targetpath=targetpath
        self.databasename='mbdo_silver_dev.'+config['deltalake_configs']['DbName']
        print(self.databasename)
        self.tablename=config['deltalake_configs']['TabelName']
        print(self.tablename)
        self.mod_df= gooddf.withColumn("current_time",F.current_timestamp())
        self.DbLoadType=config['deltalake_configs']['DbLoadType']
        self.Duplicate_Check=config['dqf_needed']['Duplicatecheck_Needed']
        print("Duplicate check value ",self.Duplicate_Check)
        self.spark = spark
        self.configs=config['deltalake_configs']
        self.fnt_id=config['file_read_configs']['FNT_Id']
        self.scd_enabled=config['file_read_configs']['SCD_Enabled']
        if self.configs['KeyColumns'] is not None and self.configs['KeyColumns']!='':
            self.key=self.configs['KeyColumns'].split(',')
        else:
            self.key=None
        if self.configs['PartitionColumns'] is not None and self.configs['PartitionColumns']!='':
            self.partitioncolumn=self.configs['PartitionColumns'].split(',')
        else:
            self.partitioncolumn=None                        
            print("partitioncolumn is ",self.partitioncolumn)
        if self.configs['WaterMarkColumns'] is not None and self.configs['WaterMarkColumns']!='':
            self.WaterMarkColumns=self.configs['WaterMarkColumns'].split(',')
        else:
            self.WaterMarkColumns=None
        if self.configs['SCD_Column'] is not None and self.configs['SCD_Column']!='':
            self.scdcolumn=self.configs['SCD_Column'].split(',')
        else:
            self.scdcolumn=None
            
    def fn_get_key(self):
        """
            Generates a key comparison expression for use in SQL operations.

            This method constructs a SQL expression that compares key columns between two DataFrames (d and dt) for use in merge operations or similar scenarios.
            The key columns are determined based on the configuration provided during initialization.

            Returns:
                str: A SQL key comparison string constructed by comparing columns from 'd' and 'dt'.
        """

        Key=""
        for i in range(len(self.key)):
            if len(self.key) == 1 or i == len(self.key)-1:
                Key += 'd.'+ self.key[i] +' = '+'dt.'+ self.key[i]
            else:
                Key += 'd.'+ self.key[i] +' = '+'dt.'+ self.key[i] + ' and '     
        print(Key)
        return Key
    
    def fn_get_scd_key(self):
        """
            Generates a Slowly Changing Dimension (SCD) key comparison expression for use in SQL operations.

            This method constructs a SQL expression that compares SCD columns between two DataFrames (d and dt), ensuring that the values in these columns are different.
            This is typically used to identify changes in Slowly Changing Dimensions (SCD) in ETL processes.

            Returns:
                str: A SQL SCD key comparison string constructed by comparing columns from 'd' and 'dt'.
        """
        Key=""
        for i in range(len(self.scdcolumn)):
            if len(self.scdcolumn) == 1 or i == len(self.scdcolumn)-1:
                Key += 'd.'+ self.scdcolumn[i] +' != '+'dt.'+ self.scdcolumn[i]
            else:
                Key += 'd.'+ self.scdcolumn[i] +' != '+'dt.'+ self.scdcolumn[i] + ' or '     
        print(Key)
        return '('+Key+')'

    def fn_delta_load_append(self):
        """
            Performs an append load operation to a Delta table.

            This method appends data to an existing Delta table either with or without partitioning. It first drops columns that are not required for the load and then writes the modified DataFrame to the specified Delta table. If partition columns are provided, the data is repartitioned before the append load operation.

            If partition columns are provided:
                - The DataFrame is repartitioned by the specified columns before writing.

            If partition columns are not provided:
                - The data is directly appended to the Delta table without repartitioning.

            Args:
                None

            Returns:
                dict: A dictionary containing the load statistics.
        """
        cols=['Source_file','Tracking_Id','Id','column_success','current_time']
        
        self.mod_df=self.mod_df.drop(*cols)

        
        batch_uuid = str(uuid.uuid4())

        #adding uuid to the batch of files processing at once
        self.mod_df = self.mod_df.withColumn("unq_id", lit(batch_uuid))

        #adding datetime to the processed time column
        self.mod_df = self.mod_df.withColumn("processed_time", current_timestamp())

        if self.partitioncolumn is None:
                    print("append load without partioning is to be done")
                    print('insde  append load')
                    self.mod_df.write.format("delta").mode("append")\
                            .option("path",self.targetpath).saveAsTable(self.databasename+'.'+self.tablename)
        else:
            print("append load with partioning is to be done")
            
            self.mod_df.repartition(*self.partitioncolumn).write.format("delta").partitionBy(self.partitioncolumn).mode("append")\
                            .option("path",self.targetpath).saveAsTable(self.databasename+'.'+self.tablename)

        loadStats=self.fn_get_stats()
        return loadStats


    def fn_delta_load_full(self):
        """
                Performs a full load operation to a Delta table by overwriting the existing data.

                This method overwrites the existing data in a Delta table with new data. It first drops columns that are not required for the load and then writes the modified DataFrame to the specified Delta table. If partition columns are provided, the data is repartitioned before the full load operation.

                If partition columns are provided:
                    - The DataFrame is repartitioned by the specified columns before writing.

                If partition columns are not provided:
                    - The entire Delta table is overwritten without repartitioning.

                Args:
                    None

                Returns:
                    dict: A dictionary containing the load statistics.
        """

        cols=['Source_file','Tracking_Id','id','column_success','current_time']
        self.mod_df=self.mod_df.drop(*cols)
        print('insde full load')
        if self.partitioncolumn is None:
                    print("Full load without partioning is to be done")
                    self.mod_df.write.format("delta").mode("overwrite")\
                            .saveAsTable(self.databasename+'.'+self.tablename)
        else:
            print("Full load with partioning is to be done")
            self.mod_df.repartition(*self.partitioncolumn).write.format("delta").partitionBy(self.partitioncolumn).mode("overwrite")\
                            .saveAsTable(self.databasename+'.'+self.tablename)
        loadStats=self.fn_get_stats()
        return loadStats
    
    def fn_delta_load_merge(self):
        """
            Performs a merge operation between a new DataFrame and an existing Delta table.

            This method compares the records from the input DataFrame (stored as a global temporary view) with the existing records in the Delta table. It performs different actions depending on whether the record exists (based on a key column) and whether Slowly Changing Dimension (SCD) is enabled.

            The function performs the following operations:
            1. If SCD is enabled:
            - Updates existing records where the keys match and the SCD condition is met.
            - Updates records if they are marked with `current_status=1`.
            - Inserts new records when no match is found.
            2. If SCD is not enabled:
            - Updates existing records where the keys match.
            - Inserts new records where no match is found.

            Args:
                None

            Returns:
                dict: A dictionary containing the load statistics.
        """

        Key=self.fn_get_key()
        
        temp_table='newtesttable'+self.fnt_id
        print("Output----------------->>")
        self.mod_df.show()
        self.mod_df.createOrReplaceGlobalTempView(temp_table)
        app=SparkSession.builder.getOrCreate()
        print(app.__dict__)

        self.spark.sql("show tables in  default").show()

        col_query=f"show columns from {self.databasename}.{self.tablename}"
        df_cols=self.spark.sql(col_query)
        pyLst = df_cols.select('col_name').toPandas()['col_name'].tolist()
        print("pyLst is ",pyLst)

        update_qry=",".join([f"d.{a}=dt.{a}" for a in pyLst if a not in ['created_time','modified_time','start_date','end_date','current_status','processed_time','unq_id']])

        print("update_qry ",update_qry)
        insert_qry_colpart=",".join([f"{a}" for a in pyLst if a not in ['created_time','modified_time','start_date','end_date','current_status','processed_time','unq_id']])
        insert_qry_colpart=insert_qry_colpart+','+'start_date'+','+'end_date'+','+'current_status'
        insert_qry_valpart=",".join([f"dt.{a}" for a in pyLst if a not in ['created_time','modified_time','start_date','end_date','current_status','processed_time','unq_id']])
        insert_qry_valpart=insert_qry_valpart+','+'current_timestamp()'+','+'null'+','+'1'
        update_scd_qry='d.end_date=current_timestamp(),current_status=0'

        unique_key=self.key[0]
        print('Unique key is---',unique_key)
        print(self.scd_enabled)
        print(type(self.scd_enabled))
        # self.scd_enabled = int(self.scd_enabled)
        print(type(self.scd_enabled))
        if self.scd_enabled==1:
            scd_Key=self.fn_get_scd_key()
            print('scd_Key is ---',scd_Key)
            full_qry=f"MERGE INTO {self.databasename}.{self.tablename} d USING ( select {unique_key} as mergekey,* from global_temp.{temp_table} \
                     union all\
                     select null as mergekey,d.* from  global_temp.{temp_table} d join {self.databasename}.{self.tablename} dt on {Key} and {scd_Key} and\
                     current_status=1)dt \
                        ON d.{unique_key}=dt.mergekey \
                        WHEN MATCHED AND {scd_Key} then\
                        update set {update_scd_qry}\
                        WHEN MATCHED AND CURRENT_STATUS=1 THEN \
                          UPDATE SET {update_qry} \
                        WHEN NOT MATCHED \
                          THEN INSERT ({insert_qry_colpart}) VALUES ({insert_qry_valpart}) \
                        "
                        
        else:

            full_qry=f"MERGE INTO {self.databasename}.{self.tablename} d USING global_temp.{temp_table} dt \
                        ON {Key} \
                        WHEN MATCHED THEN \
                            UPDATE SET {update_qry} \
                        WHEN NOT MATCHED \
                            THEN INSERT ({insert_qry_colpart}) VALUES ({insert_qry_valpart}) \
                        WHEN  NOT MATCHED BY SOURCE THEN \
                            DELETE \
                        "
        
            
            
        print('complete qry is',full_qry)
        self.spark.sql(full_qry)
        loadStats=self.fn_get_stats()
        return loadStats
    
    def fn_delta_load_upsert(self):
        """
            Performs a upsert operation between a new DataFrame and an existing Delta table.

            This method compares the records from the input DataFrame (stored as a global temporary view) with the existing records in the Delta table. It performs different actions depending on whether the record exists (based on a key column) and whether Slowly Changing Dimension (SCD) is enabled.

            The function performs the following operations:
            1. If SCD is enabled:
            - Updates existing records where the keys match and the SCD condition is met.
            - Updates records if they are marked with `current_status=1`.
            - Inserts new records when no match is found.
            2. If SCD is not enabled:
            - Updates existing records where the keys match.
            - Inserts new records where no match is found.

            Args:
                None

            Returns:
                dict: A dictionary containing the load statistics.
        """

        Key=self.fn_get_key()
        
        temp_table='newtesttable'+self.fnt_id
        print("Output----------------->>")
        self.mod_df.show()
        self.mod_df.createOrReplaceGlobalTempView(temp_table)
        app=SparkSession.builder.getOrCreate()
        print(app.__dict__)

        self.spark.sql("show tables in  default").show()

        col_query=f"show columns from {self.databasename}.{self.tablename}"
        df_cols=self.spark.sql(col_query)
        pyLst = df_cols.select('col_name').toPandas()['col_name'].tolist()
        print("pyLst is ",pyLst)

        update_qry=",".join([f"d.{a}=dt.{a}" for a in pyLst if a not in ['created_time','modified_time','start_date','end_date','current_status','processed_time','unq_id']])

        print("update_qry ",update_qry)
        insert_qry_colpart=",".join([f"{a}" for a in pyLst if a not in ['created_time','modified_time','start_date','end_date','current_status','processed_time','unq_id']])
        insert_qry_colpart=insert_qry_colpart+','+'start_date'+','+'end_date'+','+'current_status'
        insert_qry_valpart=",".join([f"dt.{a}" for a in pyLst if a not in ['created_time','modified_time','start_date','end_date','current_status','processed_time','unq_id']])
        insert_qry_valpart=insert_qry_valpart+','+'current_timestamp()'+','+'null'+','+'1'
        update_scd_qry='d.end_date=current_timestamp(),current_status=0'

        unique_key=self.key[0]
        print('Unique key is---',unique_key)
        print(self.scd_enabled)
        print(type(self.scd_enabled))
        # self.scd_enabled = int(self.scd_enabled)
        print(type(self.scd_enabled))
        if self.scd_enabled==1:
            scd_Key=self.fn_get_scd_key()
            print('scd_Key is ---',scd_Key)
            full_qry=f"MERGE INTO {self.databasename}.{self.tablename} d USING ( select {unique_key} as mergekey,* from global_temp.{temp_table} \
                     union all\
                     select null as mergekey,d.* from  global_temp.{temp_table} d join {self.databasename}.{self.tablename} dt on {Key} and {scd_Key} and\
                     current_status=1)dt \
                        ON d.{unique_key}=dt.mergekey \
                        WHEN MATCHED AND {scd_Key} then\
                        update set {update_scd_qry}\
                        WHEN MATCHED AND CURRENT_STATUS=1 THEN \
                          UPDATE SET {update_qry} \
                        WHEN NOT MATCHED \
                          THEN INSERT ({insert_qry_colpart}) VALUES ({insert_qry_valpart}) \
                        "
                        
        else:

            full_qry=f"MERGE INTO {self.databasename}.{self.tablename} d USING global_temp.{temp_table} dt \
                        ON {Key} \
                        WHEN MATCHED THEN \
                            UPDATE SET {update_qry} \
                        WHEN NOT MATCHED \
                            THEN INSERT ({insert_qry_colpart}) VALUES ({insert_qry_valpart}) \
                        "
        
            
            
        print('complete qry is',full_qry)
        self.spark.sql(full_qry)
        loadStats=self.fn_get_stats()
        return loadStats
    
    def fn_delta_load(self):
        """
                Handles the incremental load into a Delta table based on the specified load type.

                This method performs the data load into a Delta table, either appending new data, overwriting the table, or performing a merge operation depending on the specified load type (`DbLoadType`).

                The function will:
                1. Enable schema auto-merge in Delta tables using the `spark.databricks.delta.schema.autoMerge.enabled` configuration.
                2. If the `DbLoadType` is 'append':
                - Calls the `fn_delta_load_append()` method to append new records to the Delta table.
                3. If the `DbLoadType` is 'full':
                - Calls the `fn_delta_load_full()` method to perform a full overwrite of the Delta table.
                4. If the `DbLoadType` is neither 'append' nor 'full':
                - Assumes it's an incremental load and calls the `fn_delta_load_merge()` method to perform a merge operation.

                Args:
                    None

                Returns:
                    dict: A dictionary containing the load statistics based on the type of load performed.
        """

        print('inside inc load')
        self.spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled=true")
       

        if self.DbLoadType=='append':
            print('calliing append function')
            deltaLoad=self.fn_delta_load_append()
            print('completed apped load type')
        elif self.DbLoadType=='full':
            deltaLoad=self.fn_delta_load_full()
            
        elif self.DbLoadType=='merge':
            deltaLoad=self.fn_delta_load_merge()
        
        else :
            deltaLoad=self.fn_delta_load_upsert()
            
            print("Delta table incremental load completed")
        
    def table_load(self):
        """
            Checks if a Delta table exists and performs a load operation based on the table's existence.

            This method checks whether a Delta table exists in the specified database and table name. If the table exists, it invokes the `fn_delta_load` method to load the data into the table. If the table does not exist, it logs a message indicating that the Delta table does not exist.

            The function:
            1. Verifies the existence of the Delta table using `catalog().tableExists()`.
            2. If the table exists:
            - Calls the `fn_delta_load()` method to perform the specified data load (append, full, or merge).
            3. If the table does not exist:
            - Logs a message stating that the Delta table does not exist.

            Args:
                None

            Returns:
                None
        """
        print("table name ---->>>",self.databasename+'.'+self.tablename)

        print('does table exist',self.spark._jsparkSession.catalog().tableExists(self.databasename+'.'+self.tablename))    
        if self.spark._jsparkSession.catalog().tableExists(self.databasename+'.'+self.tablename):
            self.fn_delta_load()    
        else:
            print("Delta Table does not exist")


    def fn_get_stats(self):
        """
                Fetches the statistics of the last operation on a Delta table.

                This method retrieves the operation metrics for the most recent operation performed on a Delta table. It uses the Delta Lake `history()` function to get the history of operations on the specified Delta table and extracts relevant metrics such as the number of rows inserted, updated, or deleted in the last operation.

                The function:
                1. Retrieves the Delta table specified by the `self.databasename` and `self.tablename` attributes.
                2. Fetches the history of operations performed on the table using the `history(1)` method, which returns the most recent operation.
                3. Extracts and processes operation metrics from the `operationMetrics` field.
                4. Returns a dictionary containing key statistics related to the operation, including the number of output rows, rows inserted, rows updated, and rows deleted.

                Args:
                    None

                Returns:
                    dict: A dictionary containing the statistics of the last Delta operation. The dictionary includes the following keys:
                        - 'numOutputRows': Number of rows outputted by the operation.
                        - 'numTargetRowsInserted': Number of rows inserted into the table.
                        - 'numTargetRowsUpdated': Number of rows updated in the table.
                        - 'numTargetRowsDeleted': Number of rows deleted from the table.
        """
        print(f'inside merge stats {self.databasename}.{self.tablename}')

        deltatable=DeltaTable.forName(self.spark,f'{self.databasename}.{self.tablename}')

        stats=deltatable.history(1)
        ls=stats.select(F.col('operationMetrics')).collect()
  
        print('listrr-----',ls)
        return ({a:b.strip() for a,b in ls[0][0].items() if a in ['numOutputRows','numTargetRowsInserted','numTargetRowsUpdated','numTargetRowsDeleted']})
