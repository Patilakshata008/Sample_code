from pyspark.sql import functions as f
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode
import json
import pyspark

class json2reader:
    def __init__(self,spark,sc):
        """
        Initializes the class with Spark session and SparkContext.
    
        This constructor initializes the instance with the Spark session (`spark`) and 
        SparkContext (`sc`) to facilitate operations with PySpark. These objects are essential 
        for performing distributed data processing in Spark.
    
        Args:
            spark (pyspark.sql.SparkSession): The active Spark session to be used for DataFrame operations.
            sc (pyspark.SparkContext): The Spark context used for low-level Spark operations and managing distributed resources.
    
        Returns:
            None
        """
        self.spark = spark
        self.sc=sc

    def jsondata_32(self,filepath):
        """
        Processes a JSON file by reading its content and converting it into a DataFrame.

        This method reads a JSON file from the given file path using Spark's `wholeTextFiles` 
        function, splits its content into individual JSON records, and then loads these records 
        into a DataFrame. It processes each record to handle the `EnqueuedTimeUtc` field and 
        returns the resulting DataFrame with selected fields.

        Args:
            filepath (str): The path to the JSON file to be processed.

        Returns:
            pyspark.sql.DataFrame: A DataFrame containing the parsed JSON data, with only the "Body" column's fields.
        """
        print('jsondata_32')      
        vals=self.sc.wholeTextFiles(filepath).values().flatMap(lambda a:['{"EnqueuedTimeUtc":'+val if i>0 else val for i,val in enumerate(a.split('\r\n{"EnqueuedTimeUtc":'))])
        df=self.spark.read.json(vals).select( "Body.*") 
        return df
    
    def jsondata_55(self,filepath):
        """
        Reads a JSON file, extracts and flattens a nested array, and returns a DataFrame.

        This method reads a JSON file from the given file path into a DataFrame, selects the 
        'people' array, and flattens it into individual rows. It then extracts the columns 
        from the nested structure and returns the resulting DataFrame.

        Args:
            filepath (str): The path to the JSON file to be processed.

        Returns:
            pyspark.sql.DataFrame: A DataFrame containing the flattened data from the 'people' array.
        """
        print('jsondata_55')
        df1 = self.spark.read.format("json").option('multiLine',True).load(filepath)
        df2=df1.select(explode(f.col('people')))
        df3=df2.select(f.col('col.*'))
        return df3
    
    def jsondata_96(self,filepath):
        """
        Reads a JSON file into a DataFrame with multi-line support.
    
        This method reads a JSON file from the specified file path and loads it into a 
        Spark DataFrame. The file is expected to be in JSON format, with support for 
        multi-line records.
    
        Args:
            filepath (str): The path to the JSON file to be processed.
    
        Returns:
            pyspark.sql.DataFrame: A DataFrame containing the JSON data from the file.
        """
        print('jsondata_96')
        df1 = self.spark.read.format("json").option('multiLine',True).load(filepath)
        print('return from jsondata_96 function')
        return df1
        
    
        