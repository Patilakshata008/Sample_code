import json
class Dbwriters:
    def __init__(self,dbcon):  
        """
            Initializes the class with a database connection.

            Args:
                dbcon (object): A database connection object that will be used for executing SQL queries.

            Attributes:
                con (object): Stores the provided database connection for use in subsequent methods.
        """     
        self.con=dbcon
        
    def fn_update_error_status_new(self,final_json):
        """
            Updates the error status in the database using the provided JSON data.
        Args:
            final_json (dict): A dictionary containing the error status data to be updated in the database.
        This method prepares and executes a stored procedure to update the error status, passing the provided 
        JSON data as a parameter to the procedure. It also prints the update statement and a success message 
        upon completion.
        Raises:
            Exception: If there is an error during the execution of the database update.
        """
        statement = f"""EXEC dbo.sp_Update_Error_Status_new @json = '{json.dumps(final_json)}'"""
        print("update statement for error is ",statement)
        exec_statement = self.con.prepareCall(statement)
        res=exec_statement.execute()
        print("Error file status updated")

        exec_statement.close()
        
    def fn_update_row_cnt_new(self,final_json):
        """
            Updates the row count in the database using the provided JSON data.

            Args:
                final_json (dict): A dictionary containing the row count data to be updated in the database.

            This method prepares and executes a stored procedure to update the row count, passing the provided 
            JSON data as a parameter to the procedure.

            Raises:
                Exception: If there is an error during the execution of the database update.
        """       
        statement = f"""EXEC dbo.sp_update_row_cnt_new @json = '{json.dumps(final_json)}'"""
        exec_statement = self.con.prepareCall(statement)
        res=exec_statement.execute()
        
        exec_statement.close()
            
    def fn_update_error_row_cnt_new(self,final_json):
        """
            Inserts error row count summary into the delta summary logs table.

            Args:
                final_json (dict): A dictionary containing the error row count data to be inserted into the delta 
                                    summary logs table.

            This method prepares and executes a stored procedure to insert the provided JSON data into the database 
            for tracking error row counts.

            Raises:
                Exception: If there is an error during the execution of the insert operation.
        """        
        statement = f"""EXEC dbo.sp_insert_delta_summary_logs_new @json = '{json.dumps(final_json)}'"""
        exec_statement = self.con.prepareCall(statement)
        res=exec_statement.execute()

        exec_statement.close()


    def fn_update_error_row_cnt_mdf(self,final_json):
        """
            Inserts error row count summary into the delta summary logs MDF table.

            This method takes a JSON object containing error row count data and passes it to a stored procedure 
            for insertion into the database. The stored procedure `sp_insert_delta_summary_logs_mdf1` is 
            called to handle this operation.

            Args:
                final_json (dict): A dictionary containing the error row count data to be inserted into the MDF table.
                                The dictionary is serialized to JSON before being passed to the stored procedure.

            Returns:
                None: This method does not return any value.

            Raises:
                Exception: If there is an error during the execution of the stored procedure.
        """
        statement = f"""EXEC dbo.sp_insert_delta_summary_logs_mdf1 @json = '{json.dumps(final_json)}'"""
        exec_statement = self.con.prepareCall(statement)
        res=exec_statement.execute()

        exec_statement.close()

    def fn_file_info_mdf(self,final_json):
        """
            Inserts file information into the T_file_info MDF table.

            This method takes a JSON object containing file information and passes it to a stored procedure 
            for insertion into the `T_file_info_mdf` table. The stored procedure `sp_insert_T_file_info_mdf1` 
            is called to handle this operation.

            Args:
                final_json (dict): A dictionary containing the file information to be inserted into the MDF table.
                                The dictionary is serialized to JSON before being passed to the stored procedure.

            Returns:
                None: This method does not return any value.

            Raises:
                Exception: If there is an error during the execution of the stored procedure.
        """
        statement = f"""EXEC dbo.sp_insert_T_file_info_mdf1 @json = '{json.dumps(final_json)}'"""
        exec_statement = self.con.prepareCall(statement)
        res=exec_statement.execute()

        exec_statement.close()

        
    def fn_insert_delta_summary_logs_mdf(self,delta_tracking_id,expected_rows,gooddf_count,baddf_count,group_number):
        """
            Inserts or updates delta summary logs in the MDF table.

            This method is used to call the stored procedure `sp_update_delta_summary_logs_mdf` to insert or 
            update the delta summary logs in the database. It tracks the delta data processing status including 
            the number of expected rows, good data frame count, bad data frame count, and group number.

            Args:
                delta_tracking_id (str): The unique identifier for the delta tracking.
                expected_rows (int): The number of rows expected to be processed.
                gooddf_count (int): The count of good data frames processed.
                baddf_count (int): The count of bad data frames encountered.
                group_number (str): The group number associated with the delta processing.

            Returns:
                None: This method does not return any value.

            Raises:
                Exception: If there is an error during the execution of the stored procedure.
        """

        statement = f"""EXEC dbo.sp_update_delta_summary_logs_mdf @delta_tracking_id='{delta_tracking_id}',@expected_rows='{expected_rows}',@gooddf_count='{gooddf_count}',@baddf_count='{baddf_count}',@group_number='{group_number}'"""
        exec_statement = self.con.prepareCall(statement)
        res=exec_statement.execute()
        print("Delta Summary logs updated")
        exec_statement.close()



    def fn_insert_delta_summary_logs(self,delta_tracking_id,expected_rows,gooddf_count,baddf_count,track_id):
        """
            Inserts or updates delta summary logs in the tracking table.

            This method calls the stored procedure `sp_update_delta_summary_logs` to insert or update the delta 
            summary logs in the database. It tracks the delta data processing status including the number of 
            expected rows, good data frame count, bad data frame count, and tracking ID.

            Args:
                delta_tracking_id (str): The unique identifier for the delta tracking process.
                expected_rows (int): The number of rows expected to be processed.
                gooddf_count (int): The count of good data frames processed.
                baddf_count (int): The count of bad data frames encountered.
                track_id (str): The tracking ID associated with the delta processing.

            Returns:
                None: This method does not return any value.

            Raises:
                Exception: If there is an error during the execution of the stored procedure.
        """
        statement = f"""EXEC dbo.sp_update_delta_summary_logs @delta_tracking_id='{delta_tracking_id}',@expected_rows='{expected_rows}',@gooddf_count='{gooddf_count}',@baddf_count='{baddf_count}',@Tracking_Id1='{track_id}'"""
        exec_statement = self.con.prepareCall(statement)
        res=exec_statement.execute()
        print("Delta Summary logs updated")
        exec_statement.close()
        
              