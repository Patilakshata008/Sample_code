
import msal
import os
import os.path, time
import datetime
import pyspark
import time
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.functions import row_number

class utilityfunction:
    def __init__(self,dbcon,source_dl_layer,dest_dl_layer,sourcename):
        """
            Initializes the class with the necessary database connection and data layer details.

            Parameters:
                dbcon: Database connection object used for interacting with the database.
                source_dl_layer: The source data lake layer to fetch the data from.
                dest_dl_layer: The destination data lake layer to store the transformed data.
                sourcename: Name of the source dataset or data file.
                
            Returns:
                None
                
            Notes:
                - This initialization method sets up the required parameters for database interaction and data movement between source and destination data lake layers.
        """
        self.source_dl_layer=source_dl_layer
        self.dest_dl_layer=dest_dl_layer
        self.con=dbcon
        self.sourceName=sourcename
                      
            
    def fn_get_list_of_paths(self,path,start,end):
        """
            Retrieves a list of file paths within a specified directory, optionally filtered by a time range.

            Parameters:
                path (str): The root directory path to start listing files from.
                start (str or None): The start time in 'YYYY-MM-DD HH:MM:SS' format for filtering files. If None, all files are listed.
                end (str or None): The end time in 'YYYY-MM-DD HH:MM:SS' format for filtering files. Ignored if start is None.
                
            Returns:
                list: A list of dictionaries containing file information. Each dictionary includes:
                    - 'CreatedTime': The creation time of the file in 'YYYY-MM-DD HH:MM:SS' format.
                    - 'FileName': The name of the file.
                    - 'FilePath': The full path of the file.
        """
        lst_files=[]
        def get_dir_content(ls_path):
            print('ls path is',ls_path)
            dir_paths = dbutils.fs.ls(ls_path)
            print('dir path is',dir_paths)
            subdir_paths = [get_dir_content(p.path) for p in dir_paths if p.isDir() and p.path != ls_path]
            flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
            final_list=[p.path for p in dir_paths if not p.isDir()] + flat_subdir_paths           
            return final_list
        if start is None:
            lst_files.extend(get_dir_content(path))        
            list_of_name_time=[{'CreatedTime':datetime.fromtimestamp(os.path.getctime('/'+str(f).replace(':',''))).strftime('%Y-%m-%d %H:%M:%S'),'FileName':os.path.split(f)[1],'FilePath':('/'+str(f).replace(':',''))} for f in lst_files]
        else:
            time_range = pandas.date_range(start, end, freq='H')
            for val in time_range:
                day=str(val.day).zfill(2)
                month=str(val.month).zfill(2)
                year=str(val.year).zfill(4)
                hour=str(val.hour).zfill(2)
                print(f'{path}/{year}/{month}/{day}/{hour}')
                fullpath=f'{path}/{year}/{month}/{day}/{hour}'
                try:
                    lst_files.extend(get_dir_content(fullpath))
                    list_of_name_time=[{'CreatedTime':datetime.fromtimestamp(os.path.getctime('/'+str(f).replace(':',''))).strftime('%Y-%m-%d %H:%M:%S'),'FileName':os.path.split(f)[1],'FilePath':('/'+str(f).replace(':',''))} for f in lst_files]
                except Exception as e:
                    pass
        return list_of_name_time
    
    def fn_put_datepartition(self):
        """
            Generates a date partition string based on the current timestamp.

            The partition is structured in the format '/YYYY/MM/DD/HH/' where:
            - YYYY: The 4-digit year.
            - MM: The 2-digit month.
            - DD: The 2-digit day.
            - HH: The 2-digit hour.

            Returns:
                str: A string representing the date partition in the format '/YYYY/MM/DD/HH/' based on the current system time.

            Example:
                If the current date and time is '2025-01-02 14:30:00', the returned string will be '/2025/01/02/14/'.
        """
        current_time=datetime.datetime.now()
        return f'/{str(current_time.year).zfill(4)}/{str(current_time.month).zfill(2)}/{str(current_time.day).zfill(2)}/{str(current_time.hour).zfill(2)}/'
    
    def fn_addindex(self, data):
        """
            Adds a monotonically increasing index (ID) column to the input DataFrame.
            This function generates a new DataFrame where an "id" column is added with monotonically increasing values.
            
            Parameters:
                data (DataFrame): The input DataFrame to which the index column will be added.

            Returns:
                DataFrame: A new DataFrame with the added "id" column containing monotonically increasing values.
        """
        data1=data.withColumn("id", monotonically_increasing_id())
        return data1
        