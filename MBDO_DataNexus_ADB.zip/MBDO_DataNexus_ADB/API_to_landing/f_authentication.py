from f_refresh_token import RefreshToken


def get_dbutils(spark):
    try:
        # from pyspark.dbutils import DBUtils
        # from pyspark import DBUtils

        dbutils = DBUtils(spark)  # noqa: F821
    except ImportError:
        import IPython

        dbutils = IPython.get_ipython().user_ns["dbutils"]  # noqa: F821
    return dbutils  # noqa: F821


class Authentication:
    def __init__(self, API_meta, spark, fnt_id):
        self.API_meta = API_meta
        self.spark = spark
        self.fnt_id = fnt_id

    # check the type of authentication of the api
    def getAuth(self):
        try:
            if self.API_meta["Auth_method"] == "API Keys":
                apikey = self.getAPIKey()
                return self.API_meta["Auth_val"] + "=" + apikey
            elif self.API_meta["Auth_method"] == "OAuth 2.0":
                return self.getOauth()
            else:
                return ""
        except Exception as e:
            print("Authentication.py getAuth()")
            print(e)
            return None

    # process all apis with key-based authentication
    def getAPIKey(self):
        try:
            dbutils = get_dbutils(self.spark)  # noqa: F821
            keyname = "EDA-APIKEY-" + str(self.fnt_id)
            print("Keyname", keyname)
            accesskey = dbutils.secrets.get(scope="eda-dev-adb-scope", key=keyname)  # noqa: F821
            # print('accesskey',accesskey)
            return accesskey
        except Exception as e:
            print("Authentication.py getAPIKey()")
            print(e)
            return None

    # process all apis with token or oauth 2 based authnetication
    def getOauth(self):
        try:
            dbutils = get_dbutils(self.spark)  # noqa: F821
            print(dbutils)  # noqa: F821
            refresh = RefreshToken(self.API_meta, self.spark, self.fnt_id)
            token = refresh.refreshtoken()
            return token
        except Exception as e:
            print("Authentication.py getOAuth()")
            print(e)
            return None
