auth_dict = {}
