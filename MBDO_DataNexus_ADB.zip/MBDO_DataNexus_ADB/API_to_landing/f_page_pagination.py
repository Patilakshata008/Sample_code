from f_authentication_dictionary import auth_dict
from f_accessory_functions import AccessoryFunctions
import requests
import json
from pyspark.sql.functions import udf, col

# from pyspark.sql.functions import explode_outer, explode
# from pyspark.sql import functions as sf
from pyspark.sql import Row
import math as m
import sys


# function for actual data extraction
def API_Page(API_meta, page, path, size, key, param, auth_dict, fnt_id):
    try:
        # build the query
        base_q = (
            API_meta["API"]
            + API_meta["Endpoint"]
            + path
            + "?"
            + API_meta["Pagination_Param"]
            + "="
            + str(page)
        )
        if size != "fixed":
            query = base_q + "&" + API_meta["Variable_page_size"]
        else:
            query = base_q

        if key != "":
            query += "&" + key
        if param != "":
            query += "&" + param
        if API_meta["Auth_method"] != "NA" and API_meta["Auth_method"] != "OAuth 2.0":
            query += "&" + auth_dict[fnt_id]

        # check authentication methods
        # different methods have different query building and request type
        if API_meta["Auth_method"] == "OAuth 2.0":
            token = auth_dict[fnt_id]
            headers = {"Authorization": f"Bearer {token}"}
            # get the data
            response = requests.get(query, headers=headers, timeout=5)
        else:
            # get the data
            response = requests.get(query, timeout=5)

        # if it is a valid response
        if response.status_code == 200:
            # access the actual data if additional metadata in response
            if API_meta["Data"] != "NA":
                # convert data to json format
                json_dict = json.loads(response.text)
                val = json_dict[API_meta["Data"]]
                # if the data is not of list type
                if isinstance(val,list):
                    val = [val]
                # return a dictionary
                data = {"data": val}
                return data
            # when no additional metadata in response
            else:
                data = json.loads(response.text)
                if isinstance(data,list):
                    data = [data]
                data = {"data": data}
                return data
    except Exception as e:
        print(e)
        return None


class PagePagination:
    def __init__(self, API_meta, spark):
        self.API_meta = API_meta
        self.spark = spark

    # dynamically get the number of pages and items
    def getTotalPagesItems(self):
        try:
            # in case variable page size is suppoted
            if self.API_meta["Variable_page_size"] != "NA":
                items = self.API_meta["Variable_page_size"].split("=")[1]
                # ensure that the number of items per page given is valid
                # if items.isdigit() != True:
                if items.isdigit() is not True:
                    print("Invalid")
                    sys.exit()
                else:
                    items = int(items)
                    # if items per page more than total items available
                    if items > int(self.API_meta["Items_per_EP"]):
                        print("Not sufficient number of items")
                        sys.exit()
                    # if items per page greater than the allowed items per page
                    if int(self.API_meta["max_per_call"]) != -1:
                        if items > int(self.API_meta["max_per_call"]):
                            print("Exceeds max items per page")
                            sys.exit()
                if self.API_meta["Items_per_EP"] == -1:
                    print("Cannot compute total pages")
                    sys.exit()
                total_pages = m.ceil(int(self.API_meta["Items_per_EP"]) / items)

            # if items per page is fixed
            else:
                items = "fixed"
                total_pages = int(self.API_meta["No_of_pages"])
            return total_pages, items

        except Exception as e:
            print("page.py get total()")
            print(e)
            return None, None

    def getPagePaginationData(self, requestAPIdf, schema):

        try:
            # build a udf with the schema and data extraction function
            udf_page = udf(API_Page, schema)

            print("partition: ", requestAPIdf.rdd.getNumPartitions())
            # number of partitions equal to number of rows
            # increases processing speed
            requestAPIdf = requestAPIdf.repartition(min(requestAPIdf.count(), 16000))
            print("after repartition: ", requestAPIdf.rdd.getNumPartitions())

            # udf call and get the resulting data in the "data" column
            df = requestAPIdf.withColumn(
                "data",
                udf_page(
                    col("meta"),
                    col("page"),
                    col("path"),
                    col("size"),
                    col("key"),
                    col("param"),
                    col("auth_dict"),
                    col("fnt_id"),
                ),
            )
            return df

        except Exception as e:
            print(e)
            print("page.py get data()")
            return None

    def PagePaginationHead(self, fnt_id):
        try:
            # create dataframe to pass rows as parameters for udf
            requestAPI = Row(
                "meta", "page", "path", "size", "key", "param", "auth_dict", "fnt_id"
            )
            metapage = []

            # get all the details from the metadata for building the query
            func = AccessoryFunctions(self.API_meta)
            path = func.getPath()
            key = func.getKey()
            param = func.getParam()
            time = func.getDateTime()

            if param == "":
                param = time
            elif time != "":
                param += "&" + time

            # get total pages and items per page
            total_pages, items = self.getTotalPagesItems()

            # populate the requestAPI dataframe
            # each of these rows corresponds to an API call's parameters
            # all columns will have the same values in all rows
            # only page number changes
            for page in range(int(self.API_meta["First_page"]), total_pages):
                metapage.append(
                    requestAPI(
                        self.API_meta, page, path, items, key, param, auth_dict, fnt_id
                    )
                )
            requestAPIdf = self.spark.createDataFrame(metapage)
            query = "?" + self.API_meta["Pagination_Param"] + "=1"

            # extract the schema
            if param != "":
                schema = func.getSchema(
                    path, query, key, "&" + param, self.spark, fnt_id
                )
            else:
                schema = func.getSchema(path, query, key, param, self.spark, fnt_id)

            # if schema function returned an error
            if isinstance(schema, str):
                return schema
            else:
                # extract data from the requestapidf dataframe
                finalAPIdata = self.getPagePaginationData(requestAPIdf, schema)
                return finalAPIdata
        except Exception as e:
            print("page.py head()")
            print(e)
