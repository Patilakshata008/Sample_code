from f_authentication_dictionary import auth_dict
from f_accessory_functions import AccessoryFunctions
import requests
import json
from pyspark.sql.functions import udf, col

# from pyspark.sql.functions import explode_outer, explode
# from pyspark.sql import functions as sf
from pyspark.sql import Row
import sys


# function where the actual data extraction happens
def API_Offset(API_meta, offset, path, limit, key, param, auth_dict, fnt_id):
    try:
        # build the query
        p_param = API_meta["Pagination_Param"].split(",")
        offset_param = p_param[0]
        limit_param = p_param[1]
        query = (
            API_meta["API"]
            + API_meta["Endpoint"]
            + path
            + "?"
            + offset_param
            + "="
            + str(offset)
            + "&"
            + limit_param
            + "="
            + str(limit)
        )
        if key != "":
            query += "&" + key
        if param != "":
            query += "&" + param

        # based on authentication method make the request call
        if API_meta["Auth_method"] != "NA" and API_meta["Auth_method"] != "OAuth 2.0":
            query += "&" + auth_dict[fnt_id]
        if API_meta["Auth_method"] == "OAuth 2.0":
            token = auth_dict[fnt_id]
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.get(query, headers=headers, timeout=5)
        else:
            response = requests.get(query, timeout=5)

        # if the request call returned valid data
        if response.status_code == 200:
            if API_meta["Data"] != "NA":
                json_dict = json.loads(response.text)
                val = json_dict[API_meta["Data"]]
                if isinstance(val,list):
                    val = [val]
                data = {"data": val}
                return data
            else:
                data = json.loads(response.text)
                if isinstance(data,list):
                    data = [data]
                data = {"data": data}
                return data
    except Exception as e:
        print(e)
        return None


class OffsetPagination:
    def __init__(self, API_meta, spark):
        self.API_meta = API_meta
        self.spark = spark

    # get the start offset and limit (items per page)
    def getOffsetLimit(self):
        try:
            vals = self.API_meta["Variable_page_size"].split(",")
            start_offset, limit = int(vals[0]), int(vals[1])
            return limit, start_offset
        except Exception as e:
            print(e)
            print("offset error")
            sys.exit()

    # extract offset pagination data
    def getOffsetPaginationData(self, requestAPIdf, schema):
        try:
            udf_page = udf(API_Offset, schema)

            # repartition the dataframe to improve the processing speed
            print("start extracting the data")
            print("partition: ", requestAPIdf.rdd.getNumPartitions())
            requestAPIdf = requestAPIdf.repartition(min(requestAPIdf.count(), 16000))
            print("after partition: ", requestAPIdf.rdd.getNumPartitions())

            # get the data with udf
            df = requestAPIdf.withColumn(
                "data",
                udf_page(
                    col("meta"),
                    col("offset"),
                    col("path"),
                    col("limit"),
                    col("key"),
                    col("param"),
                    col("auth_dict"),
                    col("fnt_id"),
                ),
            )
            return df
        except Exception as e:
            print(e)
            return None

    def OffsetPaginationHead(self, fnt_id):
        try:
            # create dataframe to pass rows as parameters for udf
            requestAPI = Row(
                "meta", "offset", "path", "limit", "key", "param", "auth_dict", "fnt_id"
            )
            metapage = []

            # get all the details from the metadata for building the query
            func = AccessoryFunctions(self.API_meta)
            path = func.getPath()
            key = func.getKey()
            param = func.getParam()
            time = func.getDateTime()

            if param == "":
                param = time
            elif time != "":
                param += "&" + time

            # get start offset and limit
            limit, offset = self.getOffsetLimit()
            # 10, 0
            if offset == -1:
                print("offset limit error")
                return None

            # populate the requestAPI dataframe
            # each of these rows corresponds to an API call's parameters
            # all columns will have the same values in all rows
            # only start offset number changes
            while True:
                metapage.append(
                    requestAPI(
                        self.API_meta,
                        offset,
                        path,
                        limit,
                        key,
                        param,
                        auth_dict,
                        fnt_id,
                    )
                )
                print(offset, limit)
                offset += limit
                # for the final calls when the limit is greater than total available
                if (offset + limit) > int(func.API_meta["Items_per_EP"]):
                    if offset < int(func.API_meta["Items_per_EP"]):
                        metapage.append(
                            requestAPI(
                                self.API_meta,
                                offset,
                                path,
                                (int(self.API_meta["Items_per_EP"]) - offset),
                                key,
                                param,
                                auth_dict,
                                fnt_id,
                            )
                        )
                        break
                    else:
                        break

            requestAPIdf = self.spark.createDataFrame(metapage)

            # get the data schema
            p_param = self.API_meta["Pagination_Param"].split(",")
            offset = p_param[0]
            limit = p_param[1]
            query = "?" + offset + "=1" + "&" + limit + "=1"
            if param != "":
                schema = func.getSchema(
                    path, query, key, "&" + param, self.spark, fnt_id
                )
            else:
                schema = func.getSchema(path, query, key, param, self.spark, fnt_id)

            # if schema function returns an error
            if isinstance(schema,str):
                return schema
            else:
                finalAPIdata = self.getOffsetPaginationData(requestAPIdf, schema)
                return finalAPIdata
        except Exception as e:
            print(e)
