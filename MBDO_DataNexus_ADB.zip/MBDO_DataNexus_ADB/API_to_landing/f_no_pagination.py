from f_authentication_dictionary import auth_dict
from f_accessory_functions import AccessoryFunctions
import requests
import json
from pyspark.sql.functions import udf, col

# from pyspark.sql.types import  *
from pyspark.sql import Row


# function where the actual data extraction happens
def API_NoPage(API_meta, path, key, param, auth_dict, fnt_id):
    try:
        # build the query
        base_q = API_meta["API"] + API_meta["Endpoint"] + path + "?"
        if key != "":
            base_q += key
        if param != "":
            if base_q[-1] != "?":
                base_q += "&" + param
            else:
                base_q += param

        # based on authentication method make the request call
        if API_meta["Auth_method"] != "NA" and API_meta["Auth_method"] != "OAuth 2.0":
            if base_q[-1] != "?":
                base_q += "&" + auth_dict[fnt_id]
            else:
                base_q += auth_dict[fnt_id]
        if API_meta["Auth_method"] == "OAuth 2.0":
            token = auth_dict[fnt_id]
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.get(base_q, headers=headers, timeout=5)
        else:
            response = requests.get(base_q, timeout=5)

        # if the request call returned valid data
        if response.status_code == 200:
            if API_meta["Data"] != "NA":
                json_dict = json.loads(response.text)
                val = json_dict[API_meta["Data"]]
                if isinstance(val,list):
                    val = [val]
                data = {"data": val}
                return data
            else:
                data = json.loads(response.text)
                if isinstance(data,list):
                    data = [data]
                data = {"data": data}
                return data
    except Exception as e:
        print(e)
        return None


class NoPagination:
    def __init__(self, API_meta, spark):
        self.API_meta = API_meta
        self.spark = spark

    # extract offset pagination data
    def getNoPaginationData(self, requestAPIdf, schema):
        try:
            # get the data with udf
            udf_page = udf(API_NoPage, schema)
            df = requestAPIdf.withColumn(
                "data",
                udf_page(
                    col("meta"),
                    col("path"),
                    col("key"),
                    col("param"),
                    col("auth_dict"),
                    col("fnt_id"),
                ),
            )
            return df
        except Exception as e:
            print(e)
            return None

    def NoPaginationHead(self, fnt_id):
        try:
            # create dataframe to pass rows as parameters for udf
            requestAPI = Row("meta", "path", "key", "param", "auth_dict", "fnt_id")
            metapage = []

            # get all the details from the metadata for building the query
            func = AccessoryFunctions(self.API_meta)
            path = func.getPath()
            key = func.getKey()
            param = func.getParam()
            time = func.getDateTime()

            if param == "":
                param = time
            elif time != "":
                param += "&" + time

            metapage.append(
                requestAPI(self.API_meta, path, key, param, auth_dict, fnt_id)
            )
            requestAPIdf = self.spark.createDataFrame(metapage)

            # get the data schema
            if param != "":
                schema = func.getSchema(path, "", key, "&" + param, self.spark, fnt_id)
            else:
                schema = func.getSchema(path, "", key, param, self.spark, fnt_id)

            # if schema function returns an error
            if isinstance(schema,str):
                return schema
            else:
                finalAPIdata = self.getNoPaginationData(requestAPIdf, schema)
                return finalAPIdata
        except Exception as e:
            print(e)
