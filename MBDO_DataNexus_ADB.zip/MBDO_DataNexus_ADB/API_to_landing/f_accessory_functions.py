import json
import requests
from pyspark import SparkContext
import sys
import re
import ast
import datetime
from f_authentication_dictionary import auth_dict


class AccessoryFunctions:
    def __init__(self, API_meta):
        self.API_meta = API_meta

    # in case of parameterized path after the endpoint
    # api.com/endpoint/pathval1/pathval2?.....
    def getPath(self):
        try:
            if self.API_meta["Path"] != "NA":
                params = self.API_meta["Path"].strip().split(",")
                path = "/" + "/".join(params)
            else:
                path = ""
            return path
        except Exception as e:
            print(e)
            return None

    # for key based extraction
    # api/endpoint?key=value
    def getKey(self):
        try:
            if self.API_meta["keys"] != "NA":
                key = self.API_meta["keys"]
                # cannot request data without the key
                if key == "":
                    print("Key cannot be empty")
                    sys.exit()
            else:
                key = ""
            return key
        except Exception as e:
            print(e)
            return None

    # optional parameters when extraction data
    def getParam(self):
        try:
            # parameter is optional
            if self.API_meta["EP_Param"] != "NA":
                param_query = self.API_meta["EP_Param"]
            else:
                param_query = ""
            return param_query
        except Exception as e:
            print(e)
            return None

    def getDateTime(self):
        try:
            if self.API_meta["Timeframe"] != "":
                t_param = self.API_meta["Timeframe"].strip().split(",")
                self.API_meta["Timeframe_cur"] = re.sub(
                    " ", ",", self.API_meta["Timeframe_cur"]
                )
                self.API_meta["Timeframe_next"] = re.sub(
                    " ", ",", self.API_meta["Timeframe_next"]
                )
                x_cur = ast.literal_eval(self.API_meta["Timeframe_cur"])
                x_next = ast.literal_eval(self.API_meta["Timeframe_next"])
                dates_cur = [
                    datetime.strptime(date, self.API_meta["DateTimeFormat"])
                    for date in x_cur
                ]
                dates_next = [
                    datetime.strptime(date, self.API_meta["DateTimeFormat"])
                    for date in x_next
                ]
                print(dates_next)

                if len(t_param) != len(dates_cur):
                    print("Metadata entry format not supported")
                    return "Metadata entry format not supported"

                param = (
                    t_param[0]
                    + "="
                    + dates_cur[0].strftime(self.API_meta["DateTimeFormat"])
                    + "&"
                    + t_param[1]
                    + "="
                    + dates_cur[1].strftime(self.API_meta["DateTimeFormat"])
                )
                """
                duration=dates_next[1]-dates_next[0]
                gap=dates_next[0]-dates_cur[1]

                dates_cur=dates_next
                dates_next=[(dates_next[1]+gap), (dates_next[1]+duration+gap)]
                converted_dates_cur = [date.strftime(self.API_meta["DateTimeFormat"]) for date in dates_cur]
                converted_dates_next = [date.strftime(self.API_meta["DateTimeFormat"]) for date in dates_next]         
                self.API_meta["Timeframe_cur"]=str(np.array(converted_dates_cur))
                self.API_meta["Timeframe_next"]=str(np.array(converted_dates_next))
                for index in range(len(metadata_df)):
                    if metadata_df.loc[index,'API_id'] == int(self.API_meta["API_id"]):
                        metadata_df.at[index,'Timeframe_cur'] = converted_dates_cur
                        metadata_df.at[index,'Timeframe_next'] = converted_dates_next
                        break"""

                return param
            else:
                return ""
        except Exception as e:
            print(e)
            return None

    # get the schema of the data dynamically
    def getSchema(self, path, query, key, param, spark, fnt_id):
        # build the query to extract data from API
        try:
            if query == "":
                q = (
                    self.API_meta["API"]
                    + self.API_meta["Endpoint"]
                    + path
                    + query
                    + "?"
                    + key
                    + param
                )
            else:
                q = (
                    self.API_meta["API"]
                    + self.API_meta["Endpoint"]
                    + path
                    + query
                    + key
                    + param
                )
            if self.API_meta["Auth_method"] != "OAuth 2.0":
                if q[-1] == "?":
                    q += auth_dict[fnt_id]
                else:
                    if auth_dict[fnt_id] != "":
                        q += "&" + auth_dict[fnt_id]
                response = requests.get(q, timeout=10)

            else:
                token = auth_dict[fnt_id]
                headers = {"Authorization": f"Bearer {token}"}
                response = requests.get(q, headers=headers, timeout=10)

            if response.status_code == 200:
                response = response.json()
                if self.API_meta["Data"] == "NA":
                    if not isinstance (response , list):
                        response = [response]
                    jsonData = {"data": response}
                else:
                    data = response[self.API_meta["Data"]]
                    if not isinstance (data, list):
                        data = [data]
                    jsonData = {"data": data}

                # convert the dictionary to json
                jsonData = json.dumps(jsonData)
                sc = SparkContext.getOrCreate()
                # create dataframe from the json object
                df = spark.read.json(sc.parallelize([jsonData]))
                # get the dataframe schema
                schema = df.schema
                return schema

            elif response.status_code == 404:
                return "The link does not exist"
            elif response.status_code == 204:
                return "No content exisits in the link"
            else:
                print(q)
                return f"Error accessing the query link {response.status_code}"
        except Exception as e:
            print(e)
            return "Error accessing the query link"
