class DBMetaDataReader:
    def __init__(self, dbcon):
        self.con = dbcon

    def fn_get_api_metadata(self, fnt_id):
        try:
            statement = f"""EXEC dbo.sp_get_api_metadata @fntid={fnt_id}"""
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            resultSet = exec_statement.getResultSet()
            result_dict = []
            while resultSet.next():
                vals = {}
                vals["API_id"] = resultSet.getString("API_id")
                vals["API"] = resultSet.getString("API")
                vals["Endpoint"] = resultSet.getString("Endpoint")
                vals["EP_Param"] = resultSet.getString("EP_Param")
                vals["Path"] = resultSet.getString("Path")
                vals["Pagination_Method"] = resultSet.getString("Pagination_Method")
                vals["Pagination_Param"] = resultSet.getString("Pagination_Param")
                vals["Variable_page_size"] = resultSet.getString("Variable_page_size")
                vals["No_of_pages"] = resultSet.getString("No_of_pages")
                vals["First_page"] = resultSet.getString("First_page")
                vals["Items_per_EP"] = resultSet.getString("Items_per_EP")
                vals["keys"] = resultSet.getString("keys")
                vals["max_per_call"] = resultSet.getString("max_per_call")
                vals["Auth_method"] = resultSet.getString("Auth_method")
                vals["Auth_val"] = resultSet.getString("Auth_val")
                vals["Data"] = resultSet.getString("Data")
                vals["Timeframe"] = resultSet.getString("Timeframe")
                vals["Timeframe_cur"] = resultSet.getString("Timeframe_cur")
                vals["Timeframe_next"] = resultSet.getString("Timeframe_next")
                vals["DateTimeFormat"] = resultSet.getString("DateTimeFormat")
                vals["scope"] = resultSet.getString("scope")
                vals["redirect_url"] = resultSet.getString("redirect_url")
                vals["authorization_base_url"] = resultSet.getString(
                    "authorization_base_url"
                )
                vals["token_url"] = resultSet.getString("token_url")
                vals["output_path"] = resultSet.getString("output_path")

                result_dict.append(vals)
            # Close connections
            exec_statement.close()
            # self.con.close()
            return result_dict
        except Exception as e:
            print(e)

    def fn_update_connector_logs(self, job_run_id, row_count, file_path):
        try:
            statement = f"""EXEC dbo.sp_update_connector_logs @job_run_id='{job_run_id}', @row_count={row_count}, @filepath='{file_path}'"""
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            exec_statement.close()
        except Exception as e:
            print(statement)
            print(e)

    def fn_insert_connector_logs(self, job_run_id, fk_fnt_id):
        try:
            statement = f"""EXEC dbo.sp_insert_connector_logs @job_run_id='{job_run_id}', @fk_fnt_id={fk_fnt_id}"""
            exec_statement = self.con.prepareCall(statement)
            exec_statement.execute()
            exec_statement.close()
        except Exception as e:
            print(statement)
            print(e)
