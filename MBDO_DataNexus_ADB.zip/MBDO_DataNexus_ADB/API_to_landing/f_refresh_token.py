import requests
import base64
import os

os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"


def get_dbutils(spark):
    try:
        # from pyspark.dbutils import DBUtils

        dbutils = DBUtils(spark)  # noqa: F821
    except ImportError:
        import IPython

        dbutils = IPython.get_ipython().user_ns["dbutils"]  # noqa: F821
    return dbutils  # noqa: F821


class RefreshToken:
    def __init__(self, API_meta, spark, fnt_id):
        self.API_meta = API_meta
        self.spark = spark
        self.fnt_id = fnt_id

    def refreshtoken(self):
        try:
            dbutils = get_dbutils(self.spark)  # noqa: F821

            # get the refresh token, client id and client secret from key vault
            refresh_token_id = "api-oauth-token-" + str(self.fnt_id)
            refresh_token = dbutils.secrets.get(
                scope="fof-prd-scope", key=refresh_token_id
            )  # noqa: F821
            client_id = "api-clientid-" + str(self.fnt_id)
            clientidval = dbutils.secrets.get(scope="fof-prd-scope", key=client_id)  # noqa: F821
            client_secret = "api-clientsecret-" + str(self.fnt_id)
            clientsecret = dbutils.secrets.get(scope="fof-prd-scope", key=client_secret)  # noqa: F821

            # client id needs to be displayed when printing the authorization url
            # store client id with extra char in the beginning in keyvault
            # and print after removing it
            clientid = clientidval[1:]

            # get access token using the refresh token
            data = {"grant_type": "refresh_token", "refresh_token": refresh_token}
            headers = {
                "Authorization": f"Basic {base64.b64encode((clientid + ':' + clientsecret).encode()).decode()}",
            }
            new_token = requests.post(
                self.API_meta["token_url"], data=data, headers=headers
            ).json()

            return new_token["access_token"]
        except Exception as e:
            print(e)
            return None
