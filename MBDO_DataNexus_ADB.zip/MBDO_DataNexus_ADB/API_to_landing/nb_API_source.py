# COMMAND ----------

# MAGIC %sh
# MAGIC pip install requests_oauthlib

# COMMAND ----------

import requests

# import pandas as pd
import json
import math as m

# import time
import ast
from datetime import datetime
import numpy as np
import re
from requests_oauthlib import OAuth2Session
from requests.auth import HTTPBasicAuth

# import copy
import os
from pyspark import SparkSession
from common_func.databaseconnect import DBconnection
from F_DataGenerationScriptsFolder import apiconfigs
from pyspark.sql.functions import udf, col

# from pyspark.sql.functions import explode_outer, explode
# from pyspark.sql import functions as sf
from pyspark.sql import Row

# from pyspark.sql.types import *
# from collections.abc import MutableMapping

os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"

# Databricks notebook source
global auth_dict
auth_dict = {}

# COMMAND ----------

fnt_id = 117

# COMMAND ----------

"""config=  {
    "1": {
        "api_id": "1"
    },

    "2": {
        "api_id":"2"
    },
    "3": {
        "api_id":"3",
        #country=us&year=2010
        "path_param":"2009,us"
    },
    "4": {
        "api_id":"4",
        "path_param":"2010,us"
    },
    "5" : {
        "api_id": "5",
        "param_query": "embed",
        "items": "10"
    },
    "6" : {
        "api_id": "6",
        "limit":"5",
        "start_offset": "23800"
    },
    "7" : {
        "api_id":"7",
        "key": "name=karuna"
    },
    "8" : {
        "api_id": "8",
        "key":"country=us&year=2020"
    },
    "9": {
        "api_id" :9
    }
}"""

# COMMAND ----------

# dbasecon=Dtbaseconnect(database='FOF_config-db_Copy_SSC',server='sql-dia-fof-dev-01.database.windows.net')
# database='fof-prd-eus-sql-db'
# server='fof-prd-eus-sql-server.database.windows.net:1433'

spark = (
    SparkSession.builder.appName("integrity-tests")
    .config("spark.sql.legacy.timeParserPolicy", "EXCEPTION")
    .getOrCreate()
)
spark.conf.set("spark.sql.legacy.timeParserPolicy", "EXCEPTION")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
server = dbutils.secrets.get(scope="eda-dev-adb-scope", key="EDA-SQLDB-ServerName")  # noqa: F821
database = dbutils.secrets.get(scope="eda-dev-adb-scope", key="EDA-SQLDB-DBName")  # noqa: F821
spark1 = (
    SparkSession.builder.appName("integrity-tests")
    .config("spark.sql.legacy.timeParserPolicy", "EXCEPTION")
    .getOrCreate()
)
source_dl_layer = "Bronze"
dest_dl_layer = "Silver"
dbasecon = DBconnection(database=database, server=server, spark1=spark1)
con = dbasecon.fn_get_connection()
api_obj = apiconfigs.DBMetaDatRreader(con)

# COMMAND ----------


def getOauth(API_meta):
    scope = ast.literal_eval(API_meta["scope"])
    if fnt_id not in auth_dict:
        client_id = "api-clientid-" + str(fnt_id)
        clientid = dbutils.secrets.get(scope="eda-dev-adb-scope", key=client_id)  # noqa: F821
        client_secret = "api-clientsecret-" + str(fnt_id)
        clientsecret = dbutils.secrets.get(scope="eda-dev-adb-scope", key=client_secret)  # noqa: F821
        clientid_val = ""
        for i in range(1, len(clientid)):
            clientid_val += clientid[i]

        oauth = OAuth2Session(
            clientid_val, redirect_uri=API_meta["redirect_url"], scope=scope
        )
        authorization_url, state = oauth.authorization_url(
            API_meta["authorization_base_url"]
        )

        print(f"Please go here and authorize: {authorization_url}")

        redirect_response = input("Paste the full redirect URL here:")
        auth = HTTPBasicAuth(clientid_val, clientsecret)
        token = oauth.fetch_token(
            API_meta["token_url"], auth=auth, authorization_response=redirect_response
        )
        token = token["access_token"]
        return token
    else:
        return auth_dict[fnt_id]
        print("Authorization already complete")


# COMMAND ----------


def getPath(API_meta):
    if API_meta["Path"] != "NA":
        params = API_meta["Path"].strip().split(",")
        # take input for each path parameter
        # params=config[API_meta["API_id"]]["path_param"].split(",")
        path = "/" + "/".join(params)
        # /2020/us
    else:
        path = ""
    return path


def getKey(API_meta):
    if API_meta["keys"] != "NA":
        # print("Compulsory keys: "+ API_meta["keys"])
        key = API_meta["keys"]
        if key == "":
            print("Key cannot be empty")
            quit()
    else:
        key = ""

    return key


def getParam(API_meta):

    if API_meta["EP_Param"] != "NA":
        # print("Optional Parameters: "+ API_meta["EP_Param"])
        param_query = API_meta["EP_Param"]
    else:
        param_query = ""
    return param_query


def getAuth(API_meta):
    if API_meta["Auth_method"] == "API Keys":
        apikey = getAPIKey(fnt_id)
        return API_meta["Auth_val"] + "=" + apikey

    elif API_meta["Auth_method"] == "OAuth 2.0":
        return getOauth(API_meta)
    else:
        return ""


def getAPIKey(fnt_id):
    keyname = "apikey-" + str(fnt_id)
    accesskey = dbutils.secrets.get(scope="eda-dev-adb-scope", key=keyname)  # noqa: F821
    return accesskey


def getDateTime(API_meta):

    if API_meta["Timeframe"] != "":
        t_param = API_meta["Timeframe"].strip().split(",")
        API_meta["Timeframe_cur"] = re.sub(" ", ",", API_meta["Timeframe_cur"])
        API_meta["Timeframe_next"] = re.sub(" ", ",", API_meta["Timeframe_next"])
        x_cur = ast.literal_eval(API_meta["Timeframe_cur"])
        x_next = ast.literal_eval(API_meta["Timeframe_next"])
        dates_cur = [
            datetime.strptime(date, API_meta["DateTimeFormat"]) for date in x_cur
        ]
        dates_next = [
            datetime.strptime(date, API_meta["DateTimeFormat"]) for date in x_next
        ]

        if len(t_param) != len(dates_cur):
            print("Metadata entry format not supported")
            return "Metadata entry format not supported"

        param = (
            t_param[0]
            + "="
            + dates_cur[0].strftime(API_meta["DateTimeFormat"])
            + "&"
            + t_param[1]
            + "="
            + dates_cur[1].strftime(API_meta["DateTimeFormat"])
        )

        duration = dates_next[1] - dates_next[0]
        gap = dates_next[0] - dates_cur[1]

        dates_cur = dates_next
        dates_next = [(dates_next[1] + gap), (dates_next[1] + duration + gap)]
        converted_dates_cur = [
            date.strftime(API_meta["DateTimeFormat"]) for date in dates_cur
        ]
        converted_dates_next = [
            date.strftime(API_meta["DateTimeFormat"]) for date in dates_next
        ]

        API_meta["Timeframe_cur"] = str(np.array(converted_dates_cur))
        API_meta["Timeframe_next"] = str(np.array(converted_dates_next))
        for index in range(len(metadata_df)):
            if metadata_df.loc[index, "API_id"] == int(API_meta["API_id"]):
                metadata_df.at[index, "Timeframe_cur"] = converted_dates_cur
                metadata_df.at[index, "Timeframe_next"] = converted_dates_next
                break

        return param
    else:
        return ""


def getTotalPagesItems(API_meta):
    if API_meta["Variable_page_size"] != "NA":
        # print("Total Number of Items: ", (API_meta["Items_per_EP"]))
        # print("Maximum Number of Items per page: ", (API_meta["max_per_call"]))
        # items=config[API_meta["API_id"]]["items"]
        items = API_meta["Variable_page_size"].split("=")[1]
        # if items.isdigit() != True:
        if items.isdigit() is not True:
            print("Invalid")
            quit()
        else:
            items = int(items)
            if items > int(API_meta["Items_per_EP"]):
                print("Not sufficient number of items")
                quit()
            if int(API_meta["max_per_call"]) != -1:
                if items > int(API_meta["max_per_call"]):
                    print("Exceeds max items per page")
                    quit()
        if API_meta["Items_per_EP"] == -1:
            print("Cannot compute total pages")
            quit()
        total_pages = m.ceil(int(API_meta["Items_per_EP"]) / items)
        """
        return API_meta["Variable_page_size"] """

    else:
        items = "fixed"  # variable size
        total_pages = int(API_meta["No_of_pages"])
        # return ""
    return total_pages, items


# offset pagination
def getOffsetLimit(API_meta):
    # the limit remains fixed throughout
    """if int(API_meta["max_per_call"])!=-1:
        print("Maximum items per call: " + (API["max_per_call"]))


    limit=config[API_meta["API_id"]]["limit"]
    start_offset=config[API_meta["API_id"]]["start_offset"]
    if limit.isdigit()!=True or start_offset.isdigit()!=True:
        print("invalid inputs")
        quit()
    else:
        if int(limit)>int(API_meta["Items_per_EP"]) or int(start_offset)>int(API_meta["Items_per_EP"]):
            print("Exceeds the number of items available")
            quit()
        else:
            return int(limit), int(start_offset)"""
    try:
        vals = API_meta["Variable_page_size"].split(",")
        start_offset, limit = int(vals[0]), int(vals[1])
        return start_offset, limit
    except Exception as ex:
        print("offset error")
        print(ex)
        quit()


# COMMAND ----------


def getSchema(API_meta, path, query, key, param):
    if query == "":
        q = API_meta["API"] + API_meta["Endpoint"] + path + query + "?" + key + param
    else:
        q = API_meta["API"] + API_meta["Endpoint"] + path + query + key + param
        # print(q)

    # try:
    if API_meta["Auth_method"] != "OAuth 2.0":
        if q[-1] == "?":
            q += auth_dict[fnt_id]
        else:
            if auth_dict[fnt_id] != "":
                q += "&" + auth_dict[fnt_id]
        response = requests.get(q, timeout=10)

    else:
        token = auth_dict[fnt_id]
        headers = {"Authorization": f"Bearer {token}"}
        response = requests.get(q, headers=headers, timeout=10)

    if response.status_code == 200:
        response = response.json()
        if API_meta["Data"] == "NA":
            if isinstance(type(response)) != list:
                response = [response]
            jsonData = {"data": response}
        else:
            data = response[API_meta["Data"]]
            if isinstance(type(data)) != list:
                data = [data]
            jsonData = {"data": data}

        jsonData = json.dumps(jsonData)
        df = spark.read.json(sc.parallelize([jsonData]))
        schema = df.schema
        df.unpersist()
        return schema

    elif response.status_code == 404:
        return "The link does not exist"
    elif response.status_code == 204:
        return "No content exisits in the link"
    else:
        print(q)
        return f"Error accessing the query link {response.status_code}"


# except:
# return f"Error accessing the query link"
# return "There was some error extract data during schema definition"

# COMMAND ----------


def API_Page(API_meta, page, path, size, key, param):

    try:
        base_q = (
            API_meta["API"]
            + API_meta["Endpoint"]
            + path
            + "?"
            + API_meta["Pagination_Param"]
            + "="
            + str(page)
        )
        if size != "fixed":
            # api/endpoint/{path}?page=1&size=10
            query = base_q + "&" + API_meta["Variable_page_size"]
        else:
            # api/endpoint/{path}?page=1
            query = base_q

        if key != "":
            # api/endpoint/{path}?page=1&key=abc
            query += "&" + key
        if param != "":
            # api/endpoint/{path}?page=1&key=abc&param=1&param2=3
            query += "&" + param
        if API_meta["Auth_method"] != "NA" and API_meta["Auth_method"] != "OAuth 2.0":
            # api/endpoint/{path}?page=1&key=abc&param=1&param2=3&api_key=suskey
            query += "&" + auth_dict[fnt_id]
    except Exception:
        return "Error building query"

    try:
        if API_meta["Auth_method"] == "OAuth 2.0":
            token = auth_dict[fnt_id]
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.get(query, headers=headers, timeout=5)
        else:
            response = requests.get(query, timeout=5)

        if response.status_code == 200:

            if API_meta["Data"] != "NA":
                json_dict = json.loads(response.text)
                # {"page": 1, "data":[] }
                val = json_dict[API_meta["Data"]]
                if isinstance(type(val)) != list:
                    val = [val]
                data = {"data": val}
                # {"data": ["key":"val"]}
                return data
            else:
                data = json.loads(response.text)
                if isinstance(type(data)) != list:
                    data = [data]
                data = {"data": data}
                return data
        return {"data": [{"msg": "Some issues in Page Pagination"}]}
    except Exception:
        return {"data": [{"msg": "Some issues in Page Pagination"}]}


# COMMAND ----------


def API_Offset(API_meta, offset, path, limit, key, param):

    p_param = API_meta["Pagination_Param"].split(",")
    offset_param = p_param[0]
    limit_param = p_param[1]
    # api/endpoint/{path}?offset=1&limit=10
    query = (
        API_meta["API"]
        + API_meta["Endpoint"]
        + path
        + "?"
        + offset_param
        + "="
        + str(offset)
        + "&"
        + limit_param
        + "="
        + str(limit)
    )
    if key != "":
        # api/endpoint/{path}?offset=1&limit=10&key=abc
        query += "&" + key
    if param != "":
        # api/endpoint/{path}?offset=1&limit=10&key=abc&param=2
        query += "&" + param
    if API_meta["Auth_method"] != "NA" and API_meta["Auth_method"] != "OAuth 2.0":
        # api/endpoint/{path}?page=1&key=abc&param=1&param2=3&api_key=suskey
        query += "&" + auth_dict[fnt_id]

    try:
        if API_meta["Auth_method"] == "OAuth 2.0":
            token = auth_dict[fnt_id]
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.get(query, headers=headers, timeout=5)
        else:
            response = requests.get(query, timeout=5)

        if response.status_code == 200:
            if API_meta["Data"] != "NA":
                json_dict = json.loads(response.text)
                val = json_dict[API_meta["Data"]]
                if isinstance(type(val)) != list:
                    val = [val]
                data = {"data": val}
                return data
                # return val
            else:
                data = json.loads(response.text)
                if isinstance(type(data)) != list:
                    data = [data]
                data = {"data": data}
                return data

        else:
            return None
    except Exception:
        return None


# COMMAND ----------


def API_NoPage(API_meta, path, key, param):
    # api/endpoint/{path}?
    base_q = API_meta["API"] + API_meta["Endpoint"] + path + "?"
    if key != "":
        base_q += key
    if param != "":
        if base_q[-1] != "?":
            base_q += "&" + param
        else:
            base_q += param

    if API_meta["Auth_method"] != "NA" and API_meta["Auth_method"] != "OAuth 2.0":
        # api/endpoint/{path}?page=1&key=abc&param=1&param2=3&api_key=suskey
        if base_q[-1] != "?":
            base_q += "&" + auth_dict[fnt_id]
        else:
            base_q += auth_dict[fnt_id]

    try:
        if API_meta["Auth_method"] == "OAuth 2.0":
            token = auth_dict[fnt_id]
            headers = {"Authorization": f"Bearer {token}"}
            response = requests.get(base_q, headers=headers, timeout=5)
        else:
            response = requests.get(base_q, timeout=5)

        if response.status_code == 200:
            if API_meta["Data"] != "NA":
                json_dict = json.loads(response.text)
                val = json_dict[API_meta["Data"]]
                if isinstance(type(val)) != list:
                    val = [val]
                data = {"data": val}
                return data
            else:
                data = json.loads(response.text)
                if isinstance(type(data)) != list:
                    data = [data]
                data = {"data": data}
                return data
        else:
            return None
    # except:
    except Exception:
        return None


# COMMAND ----------


def getPagePaginationData(API_meta, requestAPIdf, schema):
    if API_meta["API_id"] == "1":
        udf_page = udf(API_Page, schema)
        df = requestAPIdf.withColumn(
            "data",
            udf_page(
                col("meta"),
                col("page"),
                col("path"),
                col("size"),
                col("key"),
                col("param"),
            ),
        )
        df = df.drop("meta", "page", "path", "size", "key", "param")
        # df=explodeDataAPI1()
        return df
    elif API_meta["API_id"] == "2":
        udf_page = udf(API_Page, schema)
        df = requestAPIdf.withColumn(
            "data",
            udf_page(
                col("meta"),
                col("page"),
                col("path"),
                col("size"),
                col("key"),
                col("param"),
            ),
        )
        df = df.drop("meta", "page", "path", "size", "key", "param")
        return df
    elif API_meta["API_id"] == "5":
        udf_page = udf(API_Page, schema)
        df = requestAPIdf.withColumn(
            "data",
            udf_page(
                col("meta"),
                col("page"),
                col("path"),
                col("size"),
                col("key"),
                col("param"),
            ),
        )
        df = df.drop("meta", "page", "path", "size", "key", "param")
        return df
    else:
        return "not yet defined"


# COMMAND ----------


def getOffsetPaginationData(API_meta, requestAPIdf, schema):

    if API_meta["API_id"] == "6":
        udf_page = udf(API_Offset, schema)
        df = requestAPIdf.withColumn(
            "data",
            udf_page(
                col("meta"),
                col("offset"),
                col("path"),
                col("limit"),
                col("key"),
                col("param"),
            ),
        )
        df = df.drop("meta", "path", "param", "offset", "limit", "key")
        return df
    else:
        return "not yet defined"


# COMMAND ----------


def getNoPaginationData(API_meta, requestAPIdf, schema):
    if API_meta["API_id"] == "3":
        udf_page = udf(API_NoPage, schema)
        df = requestAPIdf.withColumn(
            "data", udf_page(col("meta"), col("path"), col("key"), col("param"))
        )
        df = df.drop("meta", "path", "key", "param")
        return df

    elif API_meta["API_id"] == "4":
        udf_page = udf(API_NoPage, schema)
        df = requestAPIdf.withColumn(
            "data", udf_page(col("meta"), col("path"), col("key"), col("param"))
        )
        df = df.drop("meta", "path", "key", "param")
        return df
    elif API_meta["API_id"] == "7":
        udf_page = udf(API_NoPage, schema)
        df = requestAPIdf.withColumn(
            "data", udf_page(col("meta"), col("path"), col("key"), col("param"))
        )
        df = df.drop("meta", "path", "key", "param")
        return df
    elif API_meta["API_id"] == "8":
        udf_page = udf(API_NoPage, schema)
        df = requestAPIdf.withColumn(
            "data", udf_page(col("meta"), col("path"), col("key"), col("param"))
        )
        df = df.drop("meta", "path", "key", "param")
        return df
    elif API_meta["API_id"] == "9":
        udf_page = udf(API_NoPage, schema)
        df = requestAPIdf.withColumn(
            "data", udf_page(col("meta"), col("path"), col("key"), col("param"))
        )
        df = df.drop("meta", "path", "key", "param")
        return df
    else:
        return "not yet defined"


# COMMAND ----------


def PagePaginationHead(API_meta):
    # define the structure for the requestDF
    requestAPI = Row("meta", "page", "path", "size", "key", "param")
    metapage = []
    # parameterized paths ex: api/endpoint/{param1}/{param2}/?{query=value}/startAt=20june
    path = getPath(API_meta)
    key = getKey(API_meta)
    param = getParam(API_meta)
    time = getDateTime(API_meta)
    if param == "":
        param = time
    elif time != "":
        param += "&" + time
    # check if pagination allows variable number of pages based on size
    total_pages, items = getTotalPagesItems(API_meta)
    # run for loop to populate that dataframe
    for page in range(int(API_meta["First_page"]), 5):
        if items != "fixed" and page == total_pages:
            items = int(API_meta["Items_per_EP"]) - ((page - 1) * items)
        metapage.append(requestAPI(API_meta, page, path, items, key, param))
    requestAPIdf = spark.createDataFrame(metapage)
    query = "?" + API_meta["Pagination_Param"] + "=1"

    if param != "":
        schema = getSchema(API_meta, path, query, key, "&" + param)
    else:
        schema = getSchema(API_meta, path, query, key, param)

    if isinstance(type(schema)) == str:
        return schema
    else:
        finalAPIdata = getPagePaginationData(API_meta, requestAPIdf, schema)
        return finalAPIdata


# COMMAND ----------


def OffsetPaginationHead(API_meta):
    # define the structure for the requestDF
    requestAPI = Row("meta", "offset", "path", "limit", "key", "param")
    metapage = []
    # parameterized paths ex: api/endpoint/{param1}/{param2}/?{query=value}
    path = getPath(API_meta)
    key = getKey(API_meta)
    param = getParam(API_meta)
    time = getDateTime(API_meta)
    if param == "":
        param = time
    elif time != "":
        param += "&" + time
    limit, offset = getOffsetLimit(API_meta)

    if offset == -1:
        print("offset limit error")
        return None

    while True:
        metapage.append(requestAPI(API_meta, offset, path, limit, key, param))
        offset += limit
        if (offset + limit) > int(API_meta["Items_per_EP"]):
            if offset < int(API_meta["Items_per_EP"]):
                metapage.append(
                    requestAPI(
                        API_meta,
                        offset,
                        path,
                        (int(API_meta["Items_per_EP"]) - offset),
                        key,
                        param,
                    )
                )
                break
            else:
                break

    requestAPIdf = spark.createDataFrame(metapage)
    p_param = API_meta["Pagination_Param"].split(",")
    offset = p_param[0]
    limit = p_param[1]

    query = "?" + offset + "=1" + "&" + limit + "=1"
    if param != "":
        schema = getSchema(API_meta, path, query, key, "&" + param)
    else:
        schema = getSchema(API_meta, path, query, key, param)

    if isinstance(type(schema)) == str:
        return schema
    else:
        finalAPIdata = getOffsetPaginationData(API_meta, requestAPIdf, schema)
        return finalAPIdata


# COMMAND ----------


def NoPaginationHead(API_meta):
    requestAPI = Row("meta", "path", "key", "param")
    metapage = []
    # parameterized paths ex: api/endpoint/{param1}/{param2}/?{query=value}
    path = getPath(API_meta)
    key = getKey(API_meta)
    param = getParam(API_meta)
    time = getDateTime(API_meta)
    if param == "":
        param = time
    elif time != "":
        param += "&" + time
    metapage.append(requestAPI(API_meta, path, key, param))
    requestAPIdf = spark.createDataFrame(metapage)

    if param != "":
        schema = getSchema(API_meta, path, "", key, "&" + param)
    else:
        schema = getSchema(API_meta, path, "", key, param)
    if isinstance(type(schema)) == str:
        return schema
    else:
        finalAPIdata = getNoPaginationData(API_meta, requestAPIdf, schema)
        return finalAPIdata


# COMMAND ----------


def APIDataExtraction():
    # for api_id, vals in config.items():

    API_meta = api_obj.fn_get_api_metadata(fnt_id)[0]
    print("API: " + API_meta["API_id"])

    auth_dict[fnt_id] = getAuth(API_meta)

    if isinstance(type(API_meta)) == str:
        print(API_meta)
    else:
        if API_meta["Pagination_Method"] == "Pages":
            df = PagePaginationHead(API_meta)
        elif API_meta["Pagination_Method"] == "Offset":
            df = OffsetPaginationHead(API_meta)
        elif API_meta["Pagination_Method"] == "NA":
            df = NoPaginationHead(API_meta)
        else:
            print("not defined yet")

        if isinstance(type(df)) != str:
            df2 = df.select("data.*")
            df2 = (
                df2.selectExpr("*", "explode(data)")
                .select("*", "col.*")
                .drop("data", "col")
            )
            df2.display()
            """
                    save_location= "dbfs:/mnt/landing/APIMetadata/IN/"
                    parquet_location = save_location+"temp"
                    file_location = save_location+"API_"+API_meta["API_id"]+'.parquet'

                    df2.coalesce(1).write.parquet(path=parquet_location, mode="append")

                    file = dbutils.fs.ls(parquet_location)[-1].path  # noqa: F821
                    dbutils.fs.cp(file, file_location)  # noqa: F821
                    dbutils.fs.rm(parquet_location, recurse=True)"""  # noqa: F821

        else:
            print(df)


# COMMAND ----------

APIDataExtraction()

# COMMAND ----------
