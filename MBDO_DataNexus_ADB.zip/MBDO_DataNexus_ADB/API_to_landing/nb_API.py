# Databricks notebook source
# fnt id and job run id from adf pipeline
# fnt_id = dbutils.widgets.get("FNT_ID")
# job_run_id=dbutils.widgets.get('job_run_id')

# COMMAND ----------

import uuid

fnt_id = 112
job_run_id=str(uuid.uuid4())
print(job_run_id)


# COMMAND ----------

# authentication and pagination methods files
from f_authentication_dictionary import auth_dict
from f_page_pagination import PagePagination
from f_offset_pagination import OffsetPagination
from f_no_pagination import NoPagination
from f_authentication import Authentication
from f_accessory_functions import AccessoryFunctions

# COMMAND ----------

# database connection
from common_func.f_database_connect import * 
from F_API_configs import DBMetaDataReader
from pyspark.sql.functions import col,explode_outer,explode
from datetime import datetime
from pyspark.sql import SparkSession


import os 
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy","EXCEPTION")
spark.conf.set("spark.sql.shuffle.partitions",'auto')

server = dbutils.secrets.get(scope="fof-prd-scope",key="EDA-SQLDB-ServerName")
database = dbutils.secrets.get(scope="fof-prd-scope",key="EDA-SQLDB-DBName")
spark1 = SparkSession.builder.appName('integrity-tests').config("spark.sql.legacy.timeParserPolicy","EXCEPTION").getOrCreate()

dbasecon=DBconnection(database=database,server=server,spark1=spark1)
con=dbasecon.fn_get_connection()
api_obj=DBMetaDataReader(con)

# COMMAND ----------

def APIDataExtraction():
    try:
        # get metadata from the metadata layer SQL table
        API_meta=api_obj.fn_get_api_metadata(fnt_id)[0]
        print("API: "+API_meta["API_id"])

        # insert row for logs of the job run
        api_obj.fn_insert_connector_logs(job_run_id, fnt_id)

        # perform authentication and store keys / tokens
        # in the dictionary to be used by all functions
        auth=Authentication(API_meta, spark1, fnt_id)
        auth_dict[fnt_id]=auth.getAuth()

        if type(API_meta)==str:
            print(API_meta)
        else:
            # check for the different pagination methods
            if API_meta["Pagination_Method"]=="Pages":
                page=PagePagination(API_meta, spark1)
                df=page.PagePaginationHead(fnt_id)

            elif API_meta["Pagination_Method"]=="Offset":
                offset=OffsetPagination(API_meta, spark1)
                df=offset.OffsetPaginationHead(fnt_id)

            elif API_meta["Pagination_Method"]=="NA":
                nopage=NoPagination(API_meta, spark1)
                df=nopage.NoPaginationHead(fnt_id)
            else:
                print ("not defined yet")
            
            if type(df)!=str:
                # explode the dataframe (1st level)
                df2=df.select("data.*").selectExpr("*","explode(data)").select("*","col.*").drop("data","col")

                parquet_location= "dbfs:/mnt/landing/APIMetadata/IN/"+API_meta["output_path"]+f'_{datetime.now().strftime("%Y_%m_%d_%H_%M_%S")}'

                # update the job run logs with row count and output file path
                api_obj.fn_update_connector_logs (job_run_id , df2.count(), parquet_location)
                
                # store the data in the parquet location
                partition_size=min(df.rdd.getNumPartitions(), 8)
                df2.coalesce(partition_size).write.parquet(path=parquet_location, mode="append")
                dbutils.fs.rm('dbfs:/mnt/landing/APIMetadata/IN/temp', recurse=True)

            else:
                api_obj.fn_update_connector_logs (job_run_id , -1, '')
                print(df)
    except Exception as e:
        print (e)

# COMMAND ----------

APIDataExtraction()

# COMMAND ----------

# MAGIC %md
# MAGIC dbutils.fs.ls('dbfs:/mnt/landing/APIMetadata/IN/')

# COMMAND ----------

# df=spark.read.parquet('dbfs:/mnt/landing/APIMetadata/IN/API_8_2023_11_03_12_12_44/')
# df.display()

# COMMAND ----------

# df.count()

# COMMAND ----------

'''import pyspark.sql.functions as sf
import re
from pyspark.sql.functions import explode_outer, col

def flatten_df(nested_df):
    flat_cols = [c[0] for c in nested_df.dtypes if c[1][:6] != 'struct']
    nested_cols = [c[0] for c in nested_df.dtypes if c[1][:6] == 'struct']
    pattern = '.'
    flat_df = nested_df.select(flat_cols +
                            [sf.col(nc+'.'+c).alias(nc+'_'+c)
                                for nc in nested_cols
                                for c in nested_df.select(nc+'.*').columns if not re.search(r'\.', c)])
    return flat_df


df=flatten_df(df)
df=flatten_df(df)
array_col = [c[0] for c in df.dtypes if c[1][:5] == 'array']
array_col

for i in array_col:
    df=df.withColumn(i, explode_outer(col(i)))

df=flatten_df(df)
df=flatten_df(df)
array_col = [c[0] for c in df.dtypes if c[1][:5] == 'array']
array_col

for i in array_col:
    df=df.withColumn(i, explode_outer(col(i)))

df=flatten_df(df)'''

# COMMAND ----------

