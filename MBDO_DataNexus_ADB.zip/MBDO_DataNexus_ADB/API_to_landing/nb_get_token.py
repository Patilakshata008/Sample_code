# COMMAND ----------

# import requests
import ast
import os
import spark
from pyspark import SparkSession
from common_func.databaseconnect import DBconnection
from F_DataGenerationScriptsFolder import apiconfigs
from requests_oauthlib import OAuth2Session
from requests.auth import HTTPBasicAuth

# Databricks notebook source
fnt_id = 109

os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"

# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy", "EXCEPTION")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
server = dbutils.secrets.get(scope="fof-prd-scope", key="sqlSever")  # noqa: F821
database = dbutils.secrets.get(scope="fof-prd-scope", key="sqlDB")  # noqa: F821
spark1 = (
    SparkSession.builder.appName("integrity-tests")
    .config("spark.sql.legacy.timeParserPolicy", "EXCEPTION")
    .getOrCreate()
)
source_dl_layer = "Bronze"
dest_dl_layer = "Silver"
dbasecon = DBconnection(database=database, server=server, spark1=spark1)
con = dbasecon.fn_get_connection()
api_obj = apiconfigs.DBMetaDatRreader(con)

# COMMAND ----------

# get the API metdata from the SQL table
API_meta = api_obj.fn_get_api_metadata(fnt_id)[0]
scope = ast.literal_eval(API_meta["scope"])

# get the client id and the client secret from the keyvault
client_id = "api-clientid-" + str(fnt_id)
clientid = dbutils.secrets.get(scope="fof-prd-scope", key=client_id)  # noqa: F821
client_secret = "api-clientsecret-" + str(fnt_id)
clientsecret = dbutils.secrets.get(scope="fof-prd-scope", key=client_secret)  # noqa: F821
# client id needs to be displayed when printing the authorization url
# store client id with extra char in the beginning in keyvault
# and print after removing it
clientid_val = clientid[1:]

# create oauth2session object
oauth = OAuth2Session(clientid_val, redirect_uri=API_meta["redirect_url"], scope=scope)
# generate the authorization url
authorization_url, state = oauth.authorization_url(API_meta["authorization_base_url"])

print(f"Please go here and authorize: {authorization_url}")

redirect_response = input("Paste the full redirect URL here:")

# create http authentication object
auth = HTTPBasicAuth(clientid_val, clientsecret)
# fetch token using redirected response and authentication object
token = oauth.fetch_token(
    API_meta["token_url"], auth=auth, authorization_response=redirect_response
)

# COMMAND ----------

# store the refresh token
refresh_token = token["refresh_token"]
refresh_token

# COMMAND ----------
