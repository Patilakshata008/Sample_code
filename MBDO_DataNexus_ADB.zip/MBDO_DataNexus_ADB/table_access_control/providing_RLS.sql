-- Databricks notebook source
-- MAGIC %md #Providing Row Level Security

-- COMMAND ----------

-- DBTITLE 1,Provide the relevant details needed for Row Level security
-- MAGIC %python
-- MAGIC dbutils.widgets.text("Full_table_name","")
-- MAGIC dbutils.widgets.text("column_name","")
-- MAGIC dbutils.widgets.text("group_name","")
-- MAGIC dbutils.widgets.text("List_of_values","")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC Full_table_name = dbutils.widgets.get("Full_table_name")
-- MAGIC column_name = dbutils.widgets.get("column_name")
-- MAGIC group_name = dbutils.widgets.get("group_name")
-- MAGIC List_of_values = dbutils.widgets.get("List_of_values")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC print("Full_table_name:",Full_table_name)
-- MAGIC print("column_name:",column_name)
-- MAGIC print("group_name:",group_name)
-- MAGIC print("List_of_values:",List_of_values)

-- COMMAND ----------

-- DBTITLE 1,Insert the an Entry into RLS config table if already exists
-- MAGIC %python
-- MAGIC sql1=f"""delete from access_control_catalog.access_control_Schema.rlsconfig where columnname='{column_name}' and groupname='{group_name}' and Tablename='{Full_table_name}' """
-- MAGIC spark.sql(sql1)

-- COMMAND ----------

-- DBTITLE 1,Insert the an Entry into RLS config table
-- MAGIC %python
-- MAGIC sql=f"""Insert into access_control_catalog.access_control_Schema.rlsconfig 
-- MAGIC select '{Full_table_name}','{column_name}','{group_name}',{List_of_values}"""
-- MAGIC
-- MAGIC spark.sql(sql)

-- COMMAND ----------

-- MAGIC %run "/Repos/access_control/access_control/access_control/RLS_CLS_access_control_sql_executor" $type="RLS"

-- COMMAND ----------

select * from landing.organisationdata.employee

-- COMMAND ----------

