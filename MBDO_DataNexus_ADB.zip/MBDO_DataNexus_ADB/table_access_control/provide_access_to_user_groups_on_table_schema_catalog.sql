-- Databricks notebook source
-- %python
-- group='employee_grp'   #The name of the user group  to which the access is needed
-- object_name='employee'  #The name of the table,schema for which the access is needed
-- object_type='table'  # the type of the object(table,schema) for which access is needed
-- access_level='read'
-- table='employee'    #The name of the table for which object is needed(if the target object is schema,then leave this as None)
-- schema='organisationdata'   #The name of the Schema,schema of the table for which object is needed
-- catalog='landing'  # the name of the catalog under which the relevant schema is present
-- action='add'    # add- if you are trying to provide access,remove-if you are trying to remove access

-- COMMAND ----------

group : The name of the user group  to which the access is needed
object_name : The name of the table,schema for which the access is needed
object_type : the type of the object(table,schema) for which access is needed
access_level : read
table : The name of the table for which object is needed(if the target object is schema,then leave this as None)
schema : The name of the Schema,schema of the table for which object is needed
catalog : the name of the catalog under which the relevant schema is present
action :  add- if you are trying to provide access,remove-if you are trying to remove access

-- COMMAND ----------

-- DBTITLE 1,Enter the details of the object and  access level in the cell
-- %python
-- group='Tester_grp'   #The name of the user group  to which the access is needed
-- object_name='testtable'  #The name of the table,schema for which the access is needed
-- object_type='table'  # the type of the object(table,schema) for which access is needed
-- access_level='read'
-- table='testable'    #The name of the table for which object is needed(if the target object is schema,then leave this as None)
-- schema='testschema'   #The name of the Schema,schema of the table for which object is needed
-- catalog='testcatalog'  # the name of the catalog under which the relevant schema is present
-- action='add'    # add- if you are trying to provide access,remove-if you are trying to remove access

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.widgets.text("group","")
-- MAGIC dbutils.widgets.text("object_name","")
-- MAGIC dbutils.widgets.text("object_type","")
-- MAGIC dbutils.widgets.text("access_level","")
-- MAGIC dbutils.widgets.text("table","")
-- MAGIC dbutils.widgets.text("schema","")
-- MAGIC dbutils.widgets.text("catalog","")
-- MAGIC dbutils.widgets.text("action","")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC group = dbutils.widgets.get("group")
-- MAGIC object_name = dbutils.widgets.get("object_name")
-- MAGIC object_type = dbutils.widgets.get("object_type")
-- MAGIC access_level = dbutils.widgets.get("access_level")
-- MAGIC table = dbutils.widgets.get("table")
-- MAGIC schema = dbutils.widgets.get("schema")
-- MAGIC catalog = dbutils.widgets.get("catalog")
-- MAGIC action = dbutils.widgets.get("action")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC print("group:",group)
-- MAGIC print("object_name:",object_name)
-- MAGIC print("object_type:",object_type)
-- MAGIC print("access_level:",access_level)
-- MAGIC print("table:",table)
-- MAGIC print("schema:",schema)
-- MAGIC print("catalog:",catalog)
-- MAGIC print("action:",action)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC sql=f"""
-- MAGIC insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
-- MAGIC select 'group','{group}','{object_name}','{object_type}','{access_level}',current_timestamp(),'approved','{catalog}','{schema}','{table}','{action}'"""

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(sql)

-- COMMAND ----------

-- DBTITLE 1,the request entry made by you will be shown with status approved
select * from access_control_catalog.access_control_schema.user_access_requests where status!='granted'

-- COMMAND ----------

-- MAGIC %run "/Repos/access_control/access_control/access_control/table_access_control_executor"

-- COMMAND ----------



-- COMMAND ----------

