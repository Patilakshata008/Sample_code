# table_access_control

This repository contains scripts to manage access control for user groups on tables, schemas, and catalogs in a Databricks environment. It includes steps for managing Row Level Security (RLS) and Column Level Security (CLS) for specific objects.

## Table of Contents

1. [Provide_access_to_User_groups_on_Table,schema,Catalog.sql](#provide_access_to_user_groups_on_tableschema_catalogsql)
2. [Providing_RLS_v1.sql](#providing_rls_v1sql)
3. [Providing_CLS_v1.sql](#providing_cls_v1sql)
4. [reset.py](#resetpy)

---

## Provide_access_to_User_groups_on_Table,schema,Catalog.sql

### Overview

This script manages access control for user groups on specific objects (tables, schemas, or catalogs) in the Databricks environment.

### Steps:
1. **Define Variables:**
   - Sets variables for group name, object name, object type, access level, table name, schema name, catalog name, and action (add or remove access).

2. **Create Widgets for Input:**
   - Creates text widgets to input values for group, object name, object type, access level, table, schema, catalog, and action.

3. **Retrieve Widget Values:**
   - Retrieves the values from the widgets and assigns them to variables.

4. **Print Retrieved Values:**
   - Prints the retrieved values to verify the inputs.

5. **Insert Access Control Request:**
   - Constructs an SQL query to insert a new access control request into the `user_access_requests` table with the provided details.

6. **Execute SQL Query:**
   - Executes the constructed SQL query to insert the access control request.

7. **Display Pending Requests:**
   - Displays entries in the `user_access_requests` table where the status is not 'granted'.

8. **Run Access Control Executor:**
   - Runs an additional notebook `table_access_control_executor` to process the access control requests.

---

## Providing_RLS_v1.sql

### Overview

This script sets up Row Level Security (RLS) for a specified table and user group.

### Steps:
1. **Define RLS Details:**
   - Sets variables for the full table name, column name, group name, and list of values to be filtered for RLS.

2. **Delete Existing RLS Configurations:**
   - Constructs and executes an SQL query to delete any existing RLS configurations for the specified column, group, and table.

3. **Insert New RLS Configuration:**
   - Constructs and executes an SQL query to insert the new RLS configuration into the `rlsconfig` table.

4. **Execute RLS Configuration:**
   - Runs an additional notebook `RLS_CLS_access_control_sql_executor` to apply the RLS configuration.

---

## Providing_CLS_v1.sql

### Overview

This script enables and disables Column Level Security (CLS) on a specified column for a user group.

### Steps:
1. **Define CLS Details:**
   - Sets variables for the full table name, column name, and group name for which CLS needs to be applied.

2. **Insert CLS Configuration:**
   - Constructs and executes an SQL query to insert the CLS configuration into the `clsconfig` table.

3. **Execute CLS Configuration:**
   - Runs an additional notebook `RLS_CLS_access_control_sql_executor` to apply the CLS configuration.

### Disabling CLS on a Column:
1. **Define CLS Details for Disabling:**
   - Sets variables for the full table name, column name, and group name for which CLS needs to be disabled.

2. **Delete CLS Configuration:**
   - Constructs and executes an SQL query to delete the CLS configuration from the `clsconfig` table.

3. **Drop Function:**
   - Drops a specific function related to access control.

4. **Alter Table to Drop Mask:**
   - Alters a table to drop the mask from a specified column.

5. **Alter Table to Set Mask:**
   - Alters a table to set a mask on a specified column.

---

## Reset.py

### Overview

This script resets the configurations related to Row Level Security (RLS), Column Level Security (CLS), and other access control settings.

### Steps:
1. **Drop Row Filter:**
   - Drops the row filter from the specified table.

2. **Drop Column Mask:**
   - Drops the mask from the specified column in the table.

3. **Drop Functions:**
   - Drops the specified functions related to access control.

4. **Insert Data:**
   - Inserts new rows into the `employee` table in the `organisationdata` schema under the `landing` catalog.
