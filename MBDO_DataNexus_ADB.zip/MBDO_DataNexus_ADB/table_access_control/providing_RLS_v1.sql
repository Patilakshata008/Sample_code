-- Databricks notebook source
-- MAGIC %md #Providing Row Level Security

-- COMMAND ----------

-- DBTITLE 1,Provide the relevant details needed for Row Level security
-- MAGIC %python
-- MAGIC Full_table_name="testcatalog.testschema.testable"     #Enter the tablename in which RLS column is present.Enter the table name in this format catalog.schema.table
-- MAGIC column_name="country"                #Enter the column name on which RLS need to be applied
-- MAGIC group_name="Tester_grp"                #Enter the group_name for which RLS need to be applied
-- MAGIC List_of_values="""Array("us","india")"""     #Enter the list of values in the column which will be filtered for RLS for this group

-- COMMAND ----------

-- MAGIC %python
-- MAGIC sql1=f"""delete from access_control_catalog.access_control_Schema.rlsconfig where columnname='{column_name}' and groupname='{group_name}' and Tablename='{Full_table_name}' """
-- MAGIC spark.sql(sql1)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC sql=f"""Insert into access_control_catalog.access_control_Schema.rlsconfig 
-- MAGIC select '{Full_table_name}','{column_name}','{group_name}',{List_of_values}"""

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(sql)

-- COMMAND ----------

-- MAGIC %run "/Repos/access_control/access_control/access_control/RLS_CLS_access_control_sql_executor" $type="RLS"

-- COMMAND ----------

