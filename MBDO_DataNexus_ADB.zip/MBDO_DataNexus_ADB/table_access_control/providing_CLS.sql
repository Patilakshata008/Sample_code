-- Databricks notebook source
-- MAGIC %md #Enabling CLS on a column

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.widgets.text("Full_table_name","")
-- MAGIC dbutils.widgets.text("column_name","")
-- MAGIC dbutils.widgets.text("group_name","")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC Full_table_name = dbutils.widgets.get("Full_table_name")
-- MAGIC column_name = dbutils.widgets.get("column_name")
-- MAGIC group_name = dbutils.widgets.get("group_name")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC print("Full_table_name:",Full_table_name)
-- MAGIC print("column_name:",column_name)
-- MAGIC print("group_name:",group_name)

-- COMMAND ----------

-- DBTITLE 1,Delete the table entry from CLS config if table already exists
-- MAGIC %python
-- MAGIC sql1=f"""delete from access_control_catalog.access_control_Schema.clsconfig where columnname='{column_name}' and groupname='{group_name}' and Tablename='{Full_table_name}' """
-- MAGIC spark.sql(sql1)

-- COMMAND ----------

-- DBTITLE 1,Insert an entry in CLS config 
-- MAGIC %python
-- MAGIC sql=f"""
-- MAGIC Insert into access_control_catalog.access_control_Schema.clsconfig 
-- MAGIC select '{Full_table_name}','{column_name}','{group_name}'"""
-- MAGIC
-- MAGIC spark.sql(sql)

-- COMMAND ----------

-- MAGIC %run "/Repos/access_control/access_control/access_control/RLS_CLS_access_control_sql_executor" $type="CLS"

-- COMMAND ----------

select * from access_control_catalog.access_control_Schema.clsconfig

-- COMMAND ----------

select * from landing.organisationdata.employee

-- COMMAND ----------

