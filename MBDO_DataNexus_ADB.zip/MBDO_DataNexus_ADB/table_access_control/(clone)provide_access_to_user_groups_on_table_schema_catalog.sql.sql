-- Databricks notebook source
-- DBTITLE 1,Enter the details of the object and  access level in the cell
-- MAGIC %python
-- MAGIC group='employee_test'   #The name of the user group  to which the access is needed
-- MAGIC object_name='employee2'  #The name of the table,schema for which the access is needed
-- MAGIC object_type='table'  # the type of the object(table,schema) for which access is needed
-- MAGIC access_level='read'
-- MAGIC table='employee2'    #The name of the table for which object is needed(if the target object is schema,then leave this as None)
-- MAGIC schema='organisationdata'   #The name of the Schema,schema of the table for which object is needed
-- MAGIC catalog='silver_test'  # the name of the catalog under which the relevant schema is present
-- MAGIC action='revoke'    # add- if you are trying to provide access,remove-if you are trying to remove access

-- COMMAND ----------

-- MAGIC %python
-- MAGIC sql=f"""
-- MAGIC insert into access_control_catalog.access_control_schema.user_access_requests(Requestor_type,Requestor_name,Target_object_name,Target_object_type,Access_type,create_time,status,catalog,schema,table,request_type)
-- MAGIC select 'group','{group}','{object_name}','{object_type}','{access_level}',current_timestamp(),'approved','{catalog}','{schema}','{table}','{action}'"""

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(sql)

-- COMMAND ----------

-- DBTITLE 1,the request entry made by you will be shown with status approved
select * from access_control_catalog.access_control_schema.user_access_requests where status!='granted'

-- COMMAND ----------

-- MAGIC %run "/Repos/access_control/access_control/access_control/table_access_control_executor"

-- COMMAND ----------

