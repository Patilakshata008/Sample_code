-- Databricks notebook source
-- MAGIC %md #Enabling CLS on a column

-- COMMAND ----------

-- MAGIC %python
-- MAGIC Full_table_name="testcatalog.testschema.testable"     #Enter the tablename in which CLS column is present.Enter the table name in this format catalog.schema.table
-- MAGIC column_name="salary"                #Enter the column name on which CLS need to be applied
-- MAGIC group_name="Tester_grp"                #Enter the group_name for which CLS need to be applied
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC sql=f"""
-- MAGIC Insert into access_control_catalog.access_control_Schema.clsconfig 
-- MAGIC select '{Full_table_name}','{column_name}','{group_name}'"""

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(sql)

-- COMMAND ----------

-- MAGIC %run "/Repos/access_control/access_control/access_control/RLS_CLS_access_control_sql_executor" $type="CLS"

-- COMMAND ----------

-- MAGIC %md # Disabling CLS  on a column 

-- COMMAND ----------

-- MAGIC %python
-- MAGIC Full_table_name="testcatalog.testschema.testable"     #Enter the tablename in which CLS column is present.Enter the table name in this format catalog.schema.table
-- MAGIC column_name="salary"                #Enter the column name on which CLS need to be applied
-- MAGIC group_name="Tester_grp"   

-- COMMAND ----------

-- MAGIC %python
-- MAGIC sql=f"""delete from access_control_catalog.access_control_Schema.clsconfig where tablename='{Full_table_name}' and columnname='{column_name}' and groupname='{group_name}'"""

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(sql)

-- COMMAND ----------

drop function access_control_catalog.access_control_Schema.travel_requiredmask;

-- COMMAND ----------

ALTER TABLE silver.organisationdata.t_department_data alter Column travel_required drop MASK;

-- COMMAND ----------

ALTER TABLE silver.organisationdata.t_department_data alter Column travel_required set MASK access_control_catalog.access_control_Schema.travel_requiredmask;

-- COMMAND ----------

