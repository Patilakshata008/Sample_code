# Databricks notebook source
# MAGIC %sql
# MAGIC alter table testcatalog.testschema.testable drop row filter;

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table testcatalog.testschema.testable alter column salary drop mask;

# COMMAND ----------

# MAGIC %sql
# MAGIC Drop function access_control_catalog.access_control_schema.country_filter;
# MAGIC drop function access_control_catalog.access_control_schema.salarymask

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO landing.organisationdata.employee (EmployeeID, FirstName, LastName, Location)
# MAGIC VALUES
# MAGIC     (1, 'John', 'Doe', 'New York'),
# MAGIC     (2,'Bob','Harry','Dubai')

# COMMAND ----------

