# Azure Function: Service Bus to Event Hub Integration

This Azure Function processes messages from an Azure Service Bus queue, extracts information from the message, and forwards the data to an Azure Event Hub for further processing or storage.

## Table of Contents
- [Project Structure](#project-structure)
- [Functionality](#functionality)
- [Setup](#setup)
  - [Environment Variables](#environment-variables)
  - [Azure Resources](#azure-resources)
- [Usage](#usage)
- [Logging](#logging)

## Project Structure
├── main.py # Main Azure Function code  
├── function.json # Azure Function configuration  
├── requirements.txt # Python dependencies (e.g., azure-functions, azure-eventhub) 

## Functionality

- The function listens for messages on an Azure Service Bus queue (`cbdetectedobj-sbq`).
- When a message is received, it:
  1. Extracts a URL pointing to a blob file.
  2. Parses the filename from the URL to get the camera name, detected object count, and epoch timestamp.
  3. Converts the timestamp to a human-readable UNIX timestamp format.
  4. Creates a unique event with a UUID and sends this data to an Azure Event Hub.

### Environment Variables
Ensure the following environment variables are set either in the Azure Function App settings or in your local environment for development:

- `EVENT_HUB_CONNECTION_STR_CAMERA`: Connection string for the Azure Event Hub namespace where the messages will be sent.
- `EVENT_HUB_NAME_CAMERA`: Name of the Azure Event Hub to send messages.
- `sbnshighfreqdevcentralindia_SERVICEBUS`: Service Bus connection string (this is automatically configured in the `function.json` file).

### Azure Resources
- **Azure Service Bus**: The function is triggered by messages in a Service Bus queue (`cbdetectedobj-sbq`).
- **Azure Event Hub**: The function sends the processed data to an Event Hub.

## Usage
Once the function is deployed:

- It automatically triggers whenever a new message is posted to the Service Bus queue `cbdetectedobj-sbq`.
- The function will:
  1. Parse the incoming message, extract information from the blob URL, and parse details from the filename.
  2. Forward the data, including the camera name, detected object count, timestamp, and blob URL, to the specified Event Hub.


## Logging
Logs will be captured during function execution, providing information about the processed messages and sent events.
Key log entries include:
- The parsed camera name, detected object count, and timestamp.
- Success messages indicating data has been successfully sent to Event Hub.

## Additional Notes

- The function uses the `uuid` module to ensure each event sent to Event Hub has a unique identifier.
- The function expects filenames in the format: `camX-Y-Z.jpg`, where:
  - `X`: Camera number/name
  - `Y`: Number of detected objects
  - `Z`: Epoch timestamp

  
### Example Message:

```json
{
  "data": {
    "url": "https://yourstorage.blob.core.windows.net/yourcontainer/cam1-5-1727089613.jpg"
  }
}


