import logging
import json
import uuid  # Import the UUID module
from datetime import datetime
from azure.functions import ServiceBusMessage
from azure.eventhub import EventHubProducerClient, EventData
import os

# Event Hub connection string and Event Hub name (replace with your actual values)
EVENT_HUB_CONNECTION_STR = os.getenv("EVENT_HUB_CONNECTION_STR_CAMERA")
EVENT_HUB_NAME = os.getenv("EVENT_HUB_NAME_CAMERA")

def parse_filename(filename: str):
    # Assuming the filename is in the format camX-Y-Z.jpg
    parts = filename.split("-")
    camera_name = parts[0]  # camX
    detected_obj_count = parts[1]  # Y
    timestamp = parts[2].split(".")[0]  # Z (without .jpg)
    
    return camera_name, detected_obj_count, timestamp

def convert_to_unix_timestamp(epoch_str: str):
    # Convert the string epoch timestamp to an integer
    epoch = int(epoch_str)
    # Convert epoch to UNIX timestamp (human-readable format)
    unix_timestamp = datetime.utcfromtimestamp(epoch).strftime('%Y-%m-%d %H:%M:%S')
    return unix_timestamp

def send_to_eventhub(camera_name: str, detected_obj_count: str, timestamp: str, url: str):
    # Create a new Event Hub producer client
    producer = EventHubProducerClient.from_connection_string(
        conn_str=EVENT_HUB_CONNECTION_STR, 
        eventhub_name=EVENT_HUB_NAME
    )
    
    # Generate a unique ID using uuid
    unique_id = str(uuid.uuid4())
    
    # Prepare the message with the parsed fields and URL
    event_data_dict = {
        "unique_id": unique_id,  # Add the unique ID to the event data
        "camera_name": camera_name,
        "detected_obj_count": detected_obj_count,
        "timestamp": timestamp,  # This is now the UNIX timestamp
        "blob_uri": url
    }

    # Convert dictionary to JSON string
    event_data_json = json.dumps(event_data_dict)

    # Send the message to Event Hub
    with producer:
        event_batch = producer.create_batch()
        event_batch.add(EventData(event_data_json))
        producer.send_batch(event_batch)

def main(msg: ServiceBusMessage):
    # Log the received message
    logging.info('Python ServiceBus queue trigger processed message: %s', msg.get_body().decode('utf-8'))
    
    # Parse the message body as JSON
    message_body = json.loads(msg.get_body().decode('utf-8'))
    
    # Extract the URL from the "data" section
    url = message_body["data"]["url"]
    
    # Extract the filename from the URL (the last part of the URL path)
    filename = url.split("/")[-1]  # cam1-5-1727089613.jpg
    
    # Parse the filename into camera_name, detected_obj_count, and timestamp
    camera_name, detected_obj_count, timestamp = parse_filename(filename)
    
    # Convert the timestamp from epoch to UNIX timestamp
    unix_timestamp = convert_to_unix_timestamp(timestamp)
    
    # Log the extracted details
    logging.info(f"Camera Name: {camera_name}, Detected Object Count: {detected_obj_count}, Timestamp: {unix_timestamp}, URL: {url}")
    
    # Send the message to Event Hub for ADX storage
    send_to_eventhub(camera_name, detected_obj_count, unix_timestamp, url)
