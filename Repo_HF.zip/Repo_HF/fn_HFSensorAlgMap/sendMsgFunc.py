import json
import re
import os
import logging
from fn_HFSensorAlgMap.cosmosdb_interface import MongoInterface
from bson.objectid import ObjectId
import asyncio
from azure.servicebus.aio import ServiceBusClient
from azure.servicebus import ServiceBusMessage
servicebus_client = None
algorithms = "algorithms"
sensors = "sensors"
assetalgorithmmappings = "assetalgorithmmappings"
class MsgCreation(MongoInterface):
    def __init__(self, message) -> None:
        super().__init__()
        # Check if `db` is initialized properly
        if not hasattr(self, 'db') or self.db is None:
            logging.error("MongoDB `db` attribute is not initialized.")
            raise ValueError("Database connection failed. `db` attribute is not set.")
        else:
            logging.info("MongoDB `db` attribute is initialized successfully.")
        self.msg_content = json.loads(message)
        self.bloburl = self.msg_content['data']['url']
        self.blob_full_path = "/".join(self.bloburl.split("/")[4:])
        self.container_name = self.bloburl.split("/")[3]
        logging.info(f"Blob URL: {self.bloburl}, Full Path: {self.blob_full_path}")

    def sendMessage(self, topic_name):
        self.filename = self.blob_full_path.split("/")[-1]
        self.service_bus_topic = topic_name

        # Extracting sensor_id and timestamp from filename
        self.sensor_id, timestamp_first = self.filename.split("-")
        logging.info(f"self.sensor_id: {self.sensor_id}")

        associated_algos = self.fetch_associated_algorithms(self.sensor_id)


    def get_sensors_properties(self,algorithm_name,asset_name):
        asset_algo_collection = self.db[assetalgorithmmappings]
        asset_algo_doc = asset_algo_collection.find_one({"algorithm.name": algorithm_name,"asset.name": asset_name})
        if asset_algo_doc:
            # Fetch the subcomponent name
            subcomponent_name = asset_algo_doc.get("subcomponent", {}).get("name")
                # Fetch the asset id
            asset_id = str(asset_algo_doc.get("asset", {}).get("id"))
            # Fetch the sensors list and extract ids and names into separate lists
            sensors = asset_algo_doc.get("sensors", [])
            sensor_ids = [str(sensor.get("id")) for sensor in sensors]
            sensor_names = [sensor.get("name") for sensor in sensors]

            # Print the fetched data
            logging.info(f"Subcomponent Name: {subcomponent_name}")
            logging.info(f"Asset ID: {asset_id}")
            logging.info(f"Sensor IDs: {sensor_ids}")
            logging.info(f"Sensor Names: {sensor_names}")

            return subcomponent_name,sensor_ids,sensor_names,asset_id
        else:
            logging.info("No document found matching the given algorithm and asset name.")
            return None,None,None,None

    def get_inference_properties(self,algorithm_name):
        algorithms_collection = self.db[algorithms] 
        # Query the document based on algorithm name
        algorithm_doc = algorithms_collection.find_one({'name': algorithm_name}) 
        if algorithm_doc:
            inference_properties = algorithm_doc.get('inferenceProperties', {})
            trainingParameter = algorithm_doc.get('trainingParameter',{})
            sf = trainingParameter.get('fs','None')
            d = trainingParameter.get('d','None')
            D = trainingParameter.get('D','None')
            n = trainingParameter.get('n','None')
            fi = trainingParameter.get('fi','None')
            endpoint = inference_properties.get('endpoint', 'None')
            accessKey = inference_properties.get('accessKey', 'None')
            path = inference_properties.get('path', 'None')
            doc_id = str(algorithm_doc.get('_id', 'Not Found'))
            algo_type = algorithm_doc.get('type', 'Not Found')
            algo_group = algorithm_doc.get('group','None')
            return algo_type,doc_id, endpoint, accessKey,sf,algo_group,d,D,n,fi,path
        else:
            logging.info(f"No document found for algorithm name: {algorithm_name}")
            return None, None, None, None, None, None, None , None, None, None, None

    def fetch_associated_algorithms(self, sensor_id):
        """
        This method returns the channels associated
        to a sensor from SENSORDETAILS collection
        """
        sensor_document = self.db[sensors].find_one({"id": sensor_id})

        if sensor_document:
            # Extract Algorithm Key Values and assetname
            algorithm_values = sensor_document.get('algorithms', {})
            asset_name = sensor_document.get('attachedAssetName',{})
        else:
            logging.info("No document found with the given sensor name.")
        
        service_bus_msg = []
        for algorithm_name in algorithm_values:
            algo_type,doc_id,endpoint, accessKey,sf,algo_group,d,D,n,fi,path= self.get_inference_properties(algorithm_name)
            subcomponent_name, sensor_ids, sensor_name,asset_id=self.get_sensors_properties(algorithm_name,asset_name)

            logging.info(f"Algorithm Name: {algorithm_name}")
            logging.info(f"Asset Name: {asset_name}")
            logging.info(f"Endpoint: {endpoint}")
            logging.info(f"Access Key: {accessKey}")
            logging.info(f"Doc ID: {doc_id}")
            logging.info(f"algo type: {algo_type}")
            logging.info(f"sampling Frequnecy: {sf}")
            logging.info("------------------------")

            algorithm_msg = {
                "algorithm_name":algorithm_name,
                "algorithm_id": doc_id,
                "algorithm_type": algo_type,
                "asset_name": asset_name,
                "asset_id": asset_id,
                "filepath": self.blob_full_path,
                "model": {
                    "url": endpoint,
                    "accesskey": accessKey,
                    "deployment": path
                },
                "sampling_frequency": sf,
                "container_name": self.container_name,
                "algorithm_group": algo_group,
                "sensor_ids": sensor_ids,
                "sensor_names": sensor_name,
                "subcomponent_name": subcomponent_name,
                "d":d,
                "D":D,
                "n":n,
                "fi":fi
            }

            # Create a message with the provided body and custom properties
            message = ServiceBusMessage(json.dumps(algorithm_msg))
            message.application_properties = {"algorithm_group": algo_group}
            message.content_type = 'application/json'

            service_bus_msg.append(message)

        asyncio.run(send_message_to_topic(self.service_bus_topic, service_bus_msg))

        return True
        # logging.info(f"Sensor ID: {self.sensor_id}")
        
        # # Create the message to be sent
        # algorithm_msg = {
        #     "algorithm_name": "resonating_mind",
        #     "sensor_id": self.sensor_id,
        #     "filepath": self.blob_full_path,
        #     "container_name": self.container_name
        # }

        # service_bus_msg = ServiceBusMessage(json.dumps(algorithm_msg))
        # service_bus_msg.application_properties = {"algorithm_type": "resonating_mind"}
        # service_bus_msg.content_type = 'application/json'

        # asyncio.run(send_message_to_topic(self.service_bus_topic, [service_bus_msg]))

# Utility functions
async def get_servicebus_client(connection_string=os.getenv('SBT_INSIGHT_ENGINE_CONNECTION_SETTING')):
    global servicebus_client
    if servicebus_client is None:
        servicebus_client = ServiceBusClient.from_connection_string(connection_string)
    return servicebus_client

async def send_message_to_topic(topic_name, message):
    client = await get_servicebus_client()
    sender = client.get_topic_sender(topic_name)

    try:
        await sender.send_messages(message)
        logging.info(f"Message sent successfully: {message}.")
    except Exception as e:
        logging.error(f"An error occurred while sending the message: {str(e)}")
    finally:
        await sender.close()
