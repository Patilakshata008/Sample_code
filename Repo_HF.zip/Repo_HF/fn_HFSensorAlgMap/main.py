import os
import logging
import json
import azure.functions as func
from fn_HFSensorAlgMap.sendMsgFunc import MsgCreation


def main(message: func.ServiceBusMessage):
    message_body = message.get_body().decode("utf-8")
    logging.info("Python ServiceBus topic trigger processed message.")
    logging.info("Message Body: " + message_body)
    msgCreate = MsgCreation(message_body)
    msgCreate.sendMessage(topic_name=os.environ["INSIGHT_ENGINE_TOPIC_NAME"])

