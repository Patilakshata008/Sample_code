import os
import logging
from pymongo import MongoClient
from pymongo.database import Database

MONGO_CONNECTION_URL = os.environ["MONGO_CONNECTION_URL"]
DB_NAME = os.getenv("MONGO_DATABASE_NAME")

class MongoInterface(object):
    def __init__(self) -> None:
        super().__init__()
        # Connection to MongoDB
        self.mongo_client: MongoClient = self.get_mongo_client()
        self.db: Database = self.get_database()
        logging.info("Connection to MongoDB is established successfully!!")

    def get_database(self) -> Database:
        """Method for returning Database object for easy interaction with MongoDB

        Returns:
            Database -- Database object for specific database in MongoDB
        """
        # Use get_database() method to get the database
        return self.mongo_client.get_database(DB_NAME)

    def get_mongo_client(self) -> MongoClient:
        """Method for returning MongoClient for connecting to MongoDB

        Returns:
            MongoClient -- MongoClient object
        """
        uri = MONGO_CONNECTION_URL
        return MongoClient(uri)
