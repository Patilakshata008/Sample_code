import os
import requests
import json
import logging
import re
import pandas as pd
import numpy as np
from io import BytesIO
from datetime import datetime
from azure.storage.blob import BlobServiceClient
from cryptography.fernet import Fernet
from azure.data.tables import TableServiceClient,TableEntity
from fn_HFSensorAlgMap.cosmosdb_interface import MongoInterface
from bson.objectid import ObjectId

algorithms = "algorithms"
sensors = "sensors"
assetalgorithmmappings = "assetalgorithmmappings"

# Connect to CosmosDB
mongo_interface = MongoInterface()
db = mongo_interface.db

class AzureBlobStorage():
    """
    A class for interacting with Azure Blob Storage to read sensor data.

    Attributes:
        blob_service_client: Azure Blob Service Client.
        container_client: Azure Blob Container Client.

    Methods:
        __init__: Initializes an instance of AzureBlobStorage.
        read_sensor_data: Read sensor data from Azure Blob Storage.
    """

    def __init__(self) -> None:
        """
        Initializes an instance of AzureBlobStorage.
        """
        super().__init__()
        self.blob_service_client = self._get_blob_service_client()
        self.table_service_client = self._get_table_service_client()
        # self.container_client = self._get_container_client()

    def _get_blob_service_client(self):
        """
        Get the Azure Blob Service Client.

        Returns:
            blob_service_client: Azure Blob Service Client.
        """
        BLOB_CONNECTION_STRING = os.environ["HF_SENSOR_DATA_CONNECTION_STRING"]
        return BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)


    def _get_table_service_client(self):
        """
        Get the Azure Blob Service Client.

        Returns:
            blob_service_client: Azure Blob Service Client.
        """
        TABLE_CONNECTION_STRING = os.environ["HF_SENSOR_DATA_CONNECTION_STRING"]
        return TableServiceClient.from_connection_string(TABLE_CONNECTION_STRING)

    def read_sensor_data(self,blob_location,container_name):

        """
        Read and decrypt sensor data from Azure Blob Storage.

        Args:
            blob_location (str): Location of the blob in Azure Blob Storage.
            fernet_key (bytes): The Fernet key used for decryption.

        Returns:
            data (dict or list): The decrypted JSON data.
        """

        blob_content = self._download_blob_content(blob_location,container_name)

        if blob_content is not None:
            # fernet_key = b"2vkr8xpRd8x_NNpfDnxl0ut5IIab7S5-piCZ8XYsxHY="
            # fernet = Fernet(fernet_key)
            # decrypted_content = fernet.decrypt(blob_content)
            # data = json.loads(decrypted_content.decode('utf-8'))
            data = pd.read_csv(BytesIO(blob_content))
            return data
        else:
            return None

    def _download_blob_content(self,blob_full_path, container_name):
        """
        Download blob content from Azure Blob Storage.

        Args:
            blob_full_path (str): Full path of the blob in Azure Blob Storage.
            container_name (str): The name of the Azure Blob Storage container.

        Returns:
            bytes: The content of the blob.
        """
        # Create a BlobClient
        blob_service_client = self._get_blob_service_client()
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_full_path)

        # Download the blob content
        blob_content = blob_client.download_blob().readall()

        return blob_content
    def store_file_metadata(self, base_id, blobname, timestamp):
        """
        Store metadata about the uploaded file in Azure Table Storage only if it does not already exist.
        """
        try:
            table_service_client = self._get_table_service_client()
            table_client = table_service_client.get_table_client(table_name=os.environ['TABLENAME'])

            # Check if the entity already exists
            try:
                existing_entity = table_client.get_entity(partition_key=base_id, row_key=timestamp)
                if existing_entity:
                    logging.info(f"Metadata for {base_id} with timestamp {timestamp} already exists.")
                    return f"Metadata for {base_id} with timestamp {timestamp} already exists."
            except Exception as e:
                # If entity does not exist, proceed to create or update it
                if "ResourceNotFound" in str(e):
                    pass  # Entity does not exist, proceed to create/update
                else:
                    raise e  # Re-raise if it's another kind of exception

            # Create or update the entity with the necessary fields
            entity = TableEntity()
            entity["PartitionKey"] = base_id
            entity["RowKey"] = timestamp
            entity["BlobName"] = blobname
            entity["Timestamp"] = timestamp
            entity["Processed"] = False  # Default value

            # Insert or update the entity in Azure Table Storage
            table_client.upsert_entity(entity)

            return f"Stored metadata for {base_id} with timestamp {timestamp} successfully."
        
        except Exception as e:
            logging.error(f"Failed to store metadata for {base_id}. Error: {str(e)}")
            return f"Failed to store metadata for {base_id}. Error: {str(e)}"


    def _check_if_processed(self, base_file, pair_file):
        """
        Check if the given base_file or pair_file has already been processed.
        """
        try:
            table_service_client = self._get_table_service_client()
            table_client = table_service_client.get_table_client(table_name=os.environ['TABLENAME'])

            # Query to check if the files have been marked as processed
            base_entity = table_client.get_entity(partition_key=base_file["PartitionKey"], row_key=base_file["RowKey"])
            pair_entity = table_client.get_entity(partition_key=pair_file["PartitionKey"], row_key=pair_file["RowKey"])

            # Log the queried entities
            logging.info(f"Base Entity: {base_entity}")
            logging.info(f"Pair Entity: {pair_entity}")

            # If either file is processed, return True to indicate that the pair shouldn't be processed
            if base_entity.get("Processed", False) or pair_entity.get("Processed", False):
                logging.info(f"Either base file {base_file['PartitionKey']} or pair file {pair_file['PartitionKey']} already processed.")
                return True

            # Otherwise, return False to indicate the pair can be processed
            return False
        
        except Exception as e:
            logging.error(f"Failed to check if files are processed. Error: {str(e)}")
            return False


    def _mark_as_processed(self, base_file, pair_file):
        """
        Mark the given base_file and pair_file as processed.
        """
        try:
            table_service_client = self._get_table_service_client()
            table_client = table_service_client.get_table_client(table_name=os.environ['TABLENAME'])

            # Prepare the entities with 'Processed' flag set to True
            base_entity = {
                "PartitionKey": base_file["PartitionKey"],
                "RowKey": base_file["RowKey"],
                "BlobName": base_file.get("BlobName", ""),
                "Timestamp": base_file.get("Timestamp", ""),
                "Processed": True
            }
            
            pair_entity = {
                "PartitionKey": pair_file["PartitionKey"],
                "RowKey": pair_file["RowKey"],
                "BlobName": pair_file.get("BlobName", ""),
                "Timestamp": pair_file.get("Timestamp", ""),
                "Processed": True
            }

            # Update the base file entity
            try:
                # Check if the entity exists before updating
                existing_base = table_client.get_entity(partition_key=base_entity["PartitionKey"], row_key=base_entity["RowKey"])
                if existing_base:
                    # Update entity if exists
                    table_client.update_entity(entity=base_entity)
                else:
                    # Insert entity if it does not exist
                    table_client.create_entity(entity=base_entity)
            except Exception as e:
                logging.error(f"Failed to update or insert base entity. Error: {str(e)}")

            # Update the pair file entity
            try:
                # Check if the entity exists before updating
                existing_pair = table_client.get_entity(partition_key=pair_entity["PartitionKey"], row_key=pair_entity["RowKey"])
                if existing_pair:
                    # Update entity if exists
                    table_client.update_entity(entity=pair_entity)
                else:
                    # Insert entity if it does not exist
                    table_client.create_entity(entity=pair_entity)
            except Exception as e:
                logging.error(f"Failed to update or insert pair entity. Error: {str(e)}")

            logging.info(f"Successfully marked files as processed: {base_file['RowKey']} and {pair_file['RowKey']}")
        
        except Exception as e:
            logging.error(f"Failed to mark files as processed. Error: {str(e)}")


    def check_and_process_latest_pair(self, base_id):
        """
        Check if both files for the given base ID and its pair are uploaded.
        Always select the files with the latest timestamp.
        Returns True if both files are present, otherwise False.
        """
        pair_ids = {
            'RM00000403': 'RM00000404',
            'RM00000404': 'RM00000403',
            'RM00000407': 'RM00000408',
            'RM00000408': 'RM00000407',
            'RM00000411': 'RM00000412',
            'RM00000412': 'RM00000411',
            'RM00000415': 'RM00000416',
            'RM00000416': 'RM00000415',
            'RM00000419': 'RM00000420',
            'RM00000420': 'RM00000419',
            'RM00000423': 'RM00000424',
            'RM00000424': 'RM00000423',
            'RM00000427': 'RM00000428',
            'RM00000428': 'RM00000427'
        }

        try:
            table_service_client = self._get_table_service_client()
            table_client = table_service_client.get_table_client(table_name=os.environ['TABLENAME'])

            if base_id in pair_ids:
                pair_id = pair_ids[base_id]
                logging.info(f"Looking for pair ID: {pair_id}")

                # Query Azure Table Storage to get all files for both base ID and pair ID
                base_files = list(table_client.query_entities(f"PartitionKey eq '{base_id}'"))
                pair_files = list(table_client.query_entities(f"PartitionKey eq '{pair_id}'"))

                # Sort files by RowKey (assumed as timestamp)
                base_files.sort(key=lambda x: x['RowKey'], reverse=True)
                pair_files.sort(key=lambda x: x['RowKey'], reverse=True)

                # Ensure both base and pair files exist
                if base_files and pair_files:
                    latest_base_file = base_files[0]  # Get the latest file for base ID
                    latest_pair_file = pair_files[0]  # Get the latest file for pair ID

                    if self._check_if_processed(latest_base_file, latest_pair_file):
                        logging.info("Files have already been processed.")
                        return False

                    logging.info(f"Latest base file: {latest_base_file}")
                    logging.info(f"Latest pair file: {latest_pair_file}")

                    return True

        except Exception as e:
            logging.error(f"Error occurred while checking files for base ID {base_id}: {e}")
        
        return False

    def process_latest_files(self, base_id):
        """
        Preprocess files once both parts of the pair are present.
        Reads the files from Azure Blob Storage and stores them in pandas DataFrames.
        """
        try:
            table_service_client = self._get_table_service_client()
            table_client = table_service_client.get_table_client(table_name=os.environ['TABLENAME'])
            blob_service_client = self._get_blob_service_client()

            pairs = {
                "RM00000403": "RM00000404",
                "RM00000404": "RM00000403",
                "RM00000407": "RM00000408",
                "RM00000408": "RM00000407",
                "RM00000411": "RM00000412",
                "RM00000412": "RM00000411",
                "RM00000415": "RM00000416",
                "RM00000416": "RM00000415",
                "RM00000419": "RM00000420",
                "RM00000420": "RM00000419",
                "RM00000423": "RM00000424",
                "RM00000424": "RM00000423",
                "RM00000427": "RM00000428",
                "RM00000428": "RM00000427",
            }

            paired_id = pairs.get(base_id)
            if not paired_id:
                logging.error(f"No paired ID found for base ID {base_id}")
                return None, None, None

            query_base = f"PartitionKey eq '{base_id}'"
            query_pair = f"PartitionKey eq '{paired_id}'"

            base_entities = sorted(table_client.query_entities(query_base), key=lambda x: x['RowKey'], reverse=True)
            pair_entities = sorted(table_client.query_entities(query_pair), key=lambda x: x['RowKey'], reverse=True)

            logging.info(f"Base entities: {base_entities}")
            logging.info(f"Pair entities: {pair_entities}")

            if not base_entities or not pair_entities:
                logging.error("No files found for base ID or pair ID.")
                return None, None, None

            latest_base_file = base_entities[0]
            latest_pair_file = pair_entities[0]

            if self._check_if_processed(latest_base_file, latest_pair_file):
                logging.info("Files have already been processed.")
                return None, None, None

            sensor_name = latest_base_file['PartitionKey'] + latest_pair_file['PartitionKey']
            sensor_name = ''.join([f'HS{id}' for id in sorted(re.findall(r'HS(\d+)', sensor_name), key=int)])

            logging.info(f"Sensor name: {sensor_name}")
            logging.info(f"Processing files: {latest_base_file['BlobName']} and {latest_pair_file['BlobName']}")

            # Construct blob paths
            container_name = "impellerdataanamoly"
            base_blob_name = latest_base_file['BlobName']
            pair_blob_name = latest_pair_file['BlobName']

            # Read the base file from Azure Blob Storage
            # base_blob_client = blob_service_client.get_blob_client(container=container_name, blob=base_blob_name)
            # base_stream = base_blob_client.download_blob().readall()
            # df1 = pd.read_csv(BytesIO(base_stream))

            df1 = self.read_sensor_data(base_blob_name,container_name)
            
            # Read the pair file from Azure Blob Storage
            # pair_blob_client = blob_service_client.get_blob_client(container=container_name, blob=pair_blob_name)
            # pair_stream = pair_blob_client.download_blob().readall()
            # df2 = pd.read_csv(BytesIO(pair_stream))

            df2 = self.read_sensor_data(pair_blob_name,container_name)
            # Mark the files as processed
            self._mark_as_processed(latest_base_file, latest_pair_file)

            return df1, df2, sensor_name

        except Exception as e:
            logging.error(f"Error occurred while processing files for base ID {base_id}: {e}")
            return None, None, None


    def copy_data(self, filepath, container_name):
        blob_service_client = self._get_blob_service_client()
        source_container_client = blob_service_client.get_container_client(container_name)
        destination_container_client = blob_service_client.get_container_client("impellerdataanamoly")
        
        source_blob_client = source_container_client.get_blob_client(filepath)
        
        destination_blob_client = destination_container_client.get_blob_client(filepath)
        
        copy_operation = destination_blob_client.start_copy_from_url(source_blob_client.url)
        
        props = destination_blob_client.get_blob_properties()

        while props.copy.status == 'pending':
            logging.info('Copy is still in progress...')
            props = destination_blob_client.get_blob_properties() 
        
        if props.copy.status == 'success':
            logging.info('Blob copied successfully.')
            return 'success'
        else:
            logging.info(f'Failed to copy blob. Status: {props.copy.status}')
            return props.copy.status

def json_to_csv(data):
    data_list = data["values"]["acceleration_high"]["data"]
    # Create a DataFrame from the acceleration data
    df = pd.DataFrame(data_list, columns=["x", "y", "z"])
    return df


def construct_feature_message(features, asset_id, asset_name, algorithm_id,algorithm_group,algorithm_type, algorithm_name, sensor_id, sensor_name, filepath) -> dict:
    Response = {}
    Response['type'] = "Feature"
    Response['features'] = features
    Response['timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    Response['asset_id'] = str(asset_id)
    Response['asset_name'] = asset_name
    Response['algorithm_id'] = str(algorithm_id)
    Response['algorithm_group'] = algorithm_group
    Response['algorithm_type'] = algorithm_type
    Response['algorithm_name'] = algorithm_name   
    Response['sensor_id'] = sensor_id     
    Response['sensor_name'] = sensor_name
    Response['filepath'] = filepath
    return Response


def extract_base_id_and_timestamp(blobname):
    """
    Extracts the base ID (e.g., RM00000403) and dynamic timestamp from the blob name.
    Assumes the blob name is in the format 'RM<ID>-<timestamp>.csv'.
    """
    match = re.search(r'RM(\d+)-(\d+)\.csv', blobname)
    if match:
        base_id = f"RM{match.group(1)}"
        timestamp = match.group(2)
        return base_id, timestamp
    return None, None


#newly added
def get_sensor_algorithm_info_by_name(sensor_name, prediction_value=None, filepath=None):
    """
    Fetches associated asset, sensor, and algorithm information from the asset_algorithm_mappings 
    and algorithm collections based on the sensor_name.
    If a prediction_value is provided, it fetches the corresponding prediction label.
    In case of multiple algorithms for the same sensor, it processes each algorithm.
    """
    # Fetch asset-algorithm mappings based on sensor_name (using find for multiple mappings)
    asset_mappings = db[assetalgorithmmappings].find({
        "sensors.name": sensor_name
    })

    payloads = []

    # Iterate over all asset mappings found
    for asset_mapping in asset_mappings:
        # Check if the mapping has the required fields
        if not asset_mapping or 'asset' not in asset_mapping or 'sensors' not in asset_mapping:
            logging.info(f"Incomplete asset-algorithm mapping for sensor_name: {sensor_name}")
            continue

        # Extract asset and sensor details
        asset_id = asset_mapping["asset"]["id"]
        asset_name = asset_mapping["asset"]["name"]
        subcomponent_name = asset_mapping["subcomponent"]["name"]

        # Fetch the associated algorithm
        algorithm_info = asset_mapping.get("algorithm")  # Directly getting the algorithm info

        if algorithm_info:  # Check if algorithm_info is not None
            # Fetch algorithm details
            algorithm = db[algorithms].find_one({
                "_id": algorithm_info["id"]  # Access the 'id' field directly
            })

            if not algorithm:
                logging.info(f"No algorithm found for algorithm_id: {algorithm_info['id']}")
                continue  # Skip to the next algorithm if not found

            # Extract algorithm details
            algorithm_group = algorithm["group"]
            algorithm_type = algorithm["type"]
            algorithm_name = algorithm["name"]
            fault_classification = algorithm.get("faultClassification", {})

            # Determine prediction label based on prediction value if provided
            if prediction_value is not None:
                prediction_label = fault_classification.get(str(prediction_value), "Unknown")
            else:
                prediction_label = "Unknown"

            # Construct the payload for the current algorithm
            payload = {
                "type": "Classification",  # Assuming a static value for this example
                "predictions": prediction_value,  # Set prediction value if available
                "prediction_probabilities": [],  # Assuming empty initially
                "confidence": 0,  # Example static confidence value
                "prediction_label": prediction_label,  # Set prediction label based on the mapping
                "insights": [],  # Assuming empty initially
                "additional_fields": {},  # Empty dictionary for additional fields
                "affected_components": subcomponent_name,  # Using extracted subcomponent name
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),  # Placeholder for timestamp
                "asset_id": str(asset_id),  # Asset ID as string
                "asset_name": asset_name,  # Asset name
                "algorithm_id": str(algorithm_info["id"]),  # Algorithm ID as string
                "algorithm_group": algorithm_group,  # Algorithm group
                "algorithm_type": algorithm_type,  # Algorithm type
                "algorithm_name": algorithm_name,  # Algorithm name
                "sensor_id": [str(asset_mapping["sensors"][0]["id"])],  # Sensor ID as a list
                "sensor_name": [sensor_name],  # Sensor name as a list
                "filepath": filepath  # Example filepath; replace as needed
            }

            # Add the current payload to the list of payloads
            payloads.append(payload)

            logging.info(f"Fetched associated algorithm and data for sensor_name: {sensor_name}, algorithm: {algorithm_name}")

    logging.info(f"Total payloads created for sensor_name {sensor_name}: {len(payloads)}")

    # Return the list of payloads (one for each algorithm)
    return payloads if payloads else None


def score_model(url, access_key, deployment, data):
    try:
        payload = json.dumps(data)

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + access_key,
            'azureml-model-deployment': deployment
        }

        response = requests.post(url, headers=headers, data=payload)

        # Check if the request was successful
        if response.status_code == 200:
            logging.info("Request successful.")
            return response.json()  # Return parsed JSON response
        else:
            logging.info(f"Error: {response.status_code}, {response.text}")
            return None

    except requests.exceptions.RequestException as e:
        logging.info(f"Request failed: {e}")
        return None