import json
import logging
import azure.functions as func
from fn_gearboxFaultDetector.gearbox import  get_gearbox_features
from fn_gearboxFaultDetector.helper import AzureBlobStorage ,construct_feature_message, score_model , get_sensor_algorithm_info_by_name



def main(message: func.ServiceBusMessage, feature: func.Out[str] , faults: func.Out[str]):
    message_body = message.get_body().decode("utf-8")
    logging.info("gearboxFaultDetector ServiceBus topic trigger processed message.")
    logging.info("gearboxFaultDetector processed message: %s", message_body)

    command = json.loads(message_body)
    logging.info("command body: %s", command)

    blob_storage = AzureBlobStorage()
    
    df = blob_storage.read_sensor_data(command['filepath'], command['container_name'])
    logging.info("command container_name: %s", command['container_name'])

    sf = command["sampling_frequency"]

    features = get_gearbox_features(df, sf, 3780)
    logging.info(f"all gearbox features {features}")
    features_out = construct_feature_message(features['data'], command['asset_id'], command['asset_name'], 
        command['algorithm_id'], command['algorithm_group'], command['algorithm_type'], 
        command['algorithm_name'], command['sensor_ids'], command['sensor_names'], command['filepath'])
    
    feature.set(json.dumps(features_out))

    #newly added
    response = score_model(command['model']['url'], command['model']['accesskey'], command['model']['deployment'], features)
    logging.info(f'gearboxFaultDetector prediction data : {response}')

    # Check if the response is valid and contains a 'Prediction' key
    prediction = response.get('Prediction') if response else None
    # Call your helper function, passing 'None' if no prediction is found
    faults_out = get_sensor_algorithm_info_by_name(command['sensor_names'][0], prediction, filepath=command.get('filepath', None))
    logging.info(f"Payload Message: {faults_out}")

    faults.set(json.dumps(faults_out))
