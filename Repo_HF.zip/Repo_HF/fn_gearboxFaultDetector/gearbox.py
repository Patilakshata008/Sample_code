import numpy as np
import pandas as pd
from scipy.stats import kurtosis, skew
from scipy.fft import fftfreq
import warnings
import logging
import numpy as np
import pandas as pd
from math import log, e
from scipy.fftpack import fft, fftfreq
from scipy.stats import kurtosis, skew, entropy

class GearboxFaults:
    HALF_LENGTH = 10
    FREQ_WIDTH = 3
    INPUT_TEETH = 38
    TIME_DOMAIN_FEATURES = ['mean', 'std', 'skew', 'kurtosis', 'entropy', 'rms', 'max', 'crest', 'p2p']
    AXIS_LIST = ['x', 'y', 'z']

    def extract_features(self, df, rpm: float, sf: int) -> dict:
        """
        Extracts features from the provided DataFrame.
        """
        data = self.load_data(df)
        if data.empty:
            return None
        if not rpm:
            logging.error("RPM is empty")
            return None
        try:
            data = data[self.AXIS_LIST]
        except KeyError as e:
            logging.error(f"KeyError: {e}. The DataFrame does not contain the required columns: {self.AXIS_LIST}.")
            return None
        try:
            data = data.replace(",", ".", regex=True).astype(float)
        except ValueError as e:
            logging.error(f"ValueError occurred during conversion: {e}")
            return None

        if len(data) >= sf:
            data = data.iloc[:sf, :]
        else:
            logging.error("The dataset contains fewer samples than the sampling frequency.")
            return None

        try:
            gear_params={'input_speed':rpm,'input_teeth':self.INPUT_TEETH}#gear parameters
            fault_frequency_list=self.get_fault_frequencies(gear_params)#claculating fault frequencies
            stats_features_list = self.calculate_statistical_features(df)#extracting statitical features
            fft_features_list = self.get_fft_data(df, fs=sf, half_length=self.HALF_LENGTH, freq_width=self.FREQ_WIDTH, freq_list=fault_frequency_list)#extracting FFT features
            features_df_list=[]
            for i in range(len(self.AXIS_LIST)):
                concat_features_1axis=pd.concat([stats_features_list[i],fft_features_list[i]],axis=1)
                features_df_list.append(concat_features_1axis)
            concat_features=pd.concat(features_df_list,axis=1)
        except Exception as e:
            logging.error(str(e))
            raise RuntimeError

        return {
            # "data": concat_features.iloc[0].to_dict()
           "data": concat_features[:1].to_dict(orient='list')
        }

    def load_data(self, df):
        """
        Load data from a CSV file into a DataFrame.
        """
        if df.empty:
            logging.error("The DF is empty.")
            return df
        return df

    def get_fault_frequencies(self,params):
        """
        Calculates fault frequencies based on gear parameters.

        Args:
            params (dict): Dictionary containing gear parameters, including RPM and input teeth count.

        Returns:
            np.ndarray: Array of fault frequencies.
        """
        one_x=params['input_speed']/60
        two_x=2*one_x
        three_x=3*one_x
        GMFint=one_x*params['input_teeth']
        fx11n=GMFint-(1*one_x)
        fx12n=GMFint-(2*one_x)
        fx13n=GMFint-(3*one_x)
        fx14n=GMFint-(4*one_x)
        fx15n=GMFint-(5*one_x)
        fx16n=GMFint-(6*one_x)
        fx11p=GMFint+(1*one_x)
        fx12p=GMFint+(2*one_x)
        fx13p=GMFint+(3*one_x)
        fx14p=GMFint+(4*one_x)
        fx15p=GMFint+(5*one_x)
        fx16p=GMFint+(6*one_x)
        GAPf=GMFint/2
        
        fault_freqs = np.array([one_x,two_x,three_x,GAPf,GMFint,fx11n,fx12n,fx13n,fx14n,fx15n,fx16n,fx11p,fx12p,fx13p,fx14p,fx15p,fx16p])
        
        return fault_freqs    
    

    def slidingWindow(self, dataset, slidingWindowSize, samplesBetweenWindows) -> pd.DataFrame:
        """
        Splits the input dataset into overlapping sliding windows.
        """
        outputWindows = []
        for idx in range(slidingWindowSize, len(dataset), samplesBetweenWindows):
            outputWindows.append(dataset.iloc[idx - slidingWindowSize:idx])
        return outputWindows[:-1]

    def take_closest(self,arr, search_num) -> float:
        """
        Finds the closest value in an array to a given number.

        Args:
            arr (np.array): Array of values.
            search_num (float): The number to find the closest match for.

        Returns:
            float: The closest value in the array.
        """

        return arr[np.argmin(np.abs(arr - search_num))]
    
    def calculate_rms(self,X: np.ndarray):
        
        """
        Calculates the Root Mean Square (RMS) of an array.

        Args:
            X (np.ndarray): Input array.

        Returns:
            float: RMS value.
        """
        # Calculate the absolute differences between each element in the array and the search number
        # Then return the value in 'arr' that has the smallest difference (i.e., closest value)
        return np.sqrt(np.sum((X**2))/len(X))

    # extract peak-to-peak features
    def calculate_p2p(self,X: np.ndarray):
        """
        Calculates the peak-to-peak (P2P) value of a signal.

        Args:
            X (np.ndarray): Input array.

        Returns:
            float: Peak-to-peak value.
        """

        # Calculate the peak-to-peak value as the sum of the absolute maximum and absolute minimum values of the array
        return np.abs(np.max(X)) + np.abs(np.min(X))

    def calculate_entropy(self,X: np.ndarray, base=None):
        """
        Calculates the entropy of an array.

        Args:
            X (np.ndarray): Input array.
            base (float, optional): Logarithmic base for entropy calculation.

        Returns:
            float: Entropy value.
        """

        entropy = []
        # Calculate the normalized value counts of the array elements.
        # The `normalize=True` argument gives relative frequencies (probabilities) instead of absolute counts.
        vc = pd.Series(X).value_counts(normalize=True, sort=False)
        #Set the logarithmic base to `e` (natural logarithm) if no base is provided.
        base = e if base is None else base
        #Calculate entropy using the formula: -Σ(p * log(p)).
        # The sum is taken over all unique values in the input array.
        return -(vc * np.log(vc) / np.log(base)).sum()

    def time_features(self,X: pd.DataFrame):
        """
        Extracts time-domain statistical features from input data.

        Args:
            X (pd.DataFrame): Input time-series data.

        Returns:
            list: List of time-domain features including mean, std, skewness, kurtosis, entropy, rms, max, crest, and P2P.
        """

        # Convert the dataframe to a 1D numpy array
        X = X.to_numpy().reshape(1,-1)[0]

        # time features
        mean = np.mean(X)
        std = np.std(X)
        skewness = skew(X)
        kurt = kurtosis(X)
        entropy = self.calculate_entropy(X)
        rms = self.calculate_rms(X)
        max_abs = np.max(np.abs(X))
        crest = max_abs / rms
        p2p = self.calculate_p2p(X)

        # Return the extracted features as a list
        return [mean, std, skewness, kurt, entropy, rms, max_abs, crest, p2p]

    def calculate_statistical_features(self,data):
        """
        Calculates statistical features for each axis of the input dataset.

        Args:
            data (pd.DataFrame): Input dataset containing data for each axis.

        Returns:
            list: List of DataFrames containing statistical features for each axis.
        """


        stats_feats_df_list= []
        #iterate for all the axes
        for c in self.AXIS_LIST:
            st_1axis=self.time_features(data[[c]])
            stats_col_names=[]
            for name in self.TIME_DOMAIN_FEATURES:
                stats_col_names.append(f'{name}_{c}')
            st_1axis_df=pd.DataFrame(data=[st_1axis],
                            columns=stats_col_names)#data frame of one axis
            stats_feats_df_list.append(st_1axis_df)

        return stats_feats_df_list

    def calculate_fft(self,inputData, fs):
        """
        Computes the FFT of the input signal and returns the frequency components and their amplitudes.

        Parameters:
        inputData (array-like): The input time-domain signal.
        fs (int or float): The sampling frequency of the signal.

        Returns:
        freqX (numpy.ndarray): Array of frequency components.
        calcfftY (numpy.ndarray): Array of amplitudes corresponding to the frequency components.
        """

        dt = 1 / fs # Calculate the time interval between samples
        N = len(inputData)  # Number of samples in the input signal
        # Compute the FFT of the input signal
        calcfftY = fft(np.array(inputData))
        # Take the magnitude of the FFT and normalize it
        calcfftY = 2*np.abs(calcfftY[1:N//2]) / N 
        # Generate the frequency axis for the positive frequencies
        freqX = fftfreq(N, dt)[1:N//2]

        return freqX, calcfftY

    def calculateFFtFeatures(self,inputData: pd.DataFrame, fs: int, half_length:int, freq_width:int, freq_list:list):
        """
        Calculates FFT-based features for each target frequency in the input data.

    Args:
        inputData (pd.DataFrame): The input time-series data for a specific axis.
        fs (int): The sampling frequency of the data.
        half_length (int): Half of the FFT length used to define the frequency range.
        freq_width (int): The width (in number of frequency bins) around the peak frequency to extract features.
        freq_list (list): A list of target fault frequencies for which features are to be extracted.

    Returns:
        list: A flattened list of FFT features for the given input data, corresponding to the specified frequency list.
        """
        
        
        fft_feats = np.array([])
        # Compute the FFT for the input data
        freqs, amplitudes = self.calculate_fft(inputData, fs=fs)
        
        for freq in freq_list:

            # Determine the upper and lower bounds around the target frequency
            up_value = freq + half_length
            down_value = freq - half_length
            
            # Find the closest actual frequency values in the FFT result
            up_value = self.take_closest(freqs, up_value)
            down_value = self.take_closest(freqs, down_value)

            # Identify the indices corresponding to the selected frequency range
            start_idx = np.where(freqs == down_value)[0][0]
            end_idx = np.where(freqs == up_value)[0][0]

            # Extract the amplitude values within the frequency range
            interval_vals = amplitudes[start_idx:end_idx]
            # Find the maximum amplitude in this range
            interval_max = interval_vals.max()
            max_index = np.where(amplitudes == interval_max)[0][0]

            # Extract a subset of frequency points around the peak value
            nearby_freqs = amplitudes[max_index-freq_width:max_index+freq_width]

            # Append these frequency-domain features to the overall feature array
            fft_feats = np.concatenate((fft_feats, nearby_freqs))

        return list(fft_feats)

    def get_fft_data(self,data, fs, half_length, freq_width, freq_list):
        """
        Extracts FFT-based features from the input data for each axis.

        Args:
            data (pd.DataFrame): Input dataset containing data for each axis.
            fs (float): Sampling frequency.
            half_length (int): Length parameter for FFT.
            freq_width (int): Frequency width for FFT processing.
            freq_list (np.ndarray): Array of fault frequencies.

        Returns:
            list: List of DataFrames containing FFT features for each axis.
        """
        

        fft_features_df_list = [] 
        #iterate by all the axis   
        for c in self.AXIS_LIST:
            arr = data[c].to_numpy()
            fft_1xis=self.calculateFFtFeatures(arr, fs, half_length, freq_width, freq_list)
            m=0
            cols = []
            for f in freq_list:
                cols.extend([f'fft_{m+x}_{c}' for x in range(1, 2*freq_width+1)])
                m=m+2*freq_width
            fft_1xis_df=pd.DataFrame(data=[fft_1xis], columns=cols)#dataframe for oneaxis
            fft_features_df_list.append(fft_1xis_df)
        return fft_features_df_list

def get_gearbox_features(data: pd.DataFrame, fs: int, speed: float):
    gearbox = GearboxFaults()
    extracted_features = gearbox.extract_features(data, speed, fs)
    return extracted_features
