import logging
import zipfile
import io
from azure.functions import InputStream
from azure.storage.blob import BlobServiceClient

# Blob service client to upload files
blob_service_client = BlobServiceClient.from_connection_string("DefaultEndpointsProtocol=https;AccountName=jswdevdthflf;AccountKey=2q1TkSQuyyEnJ/3jofrZ5wp/KN+3WhwlKaCkFrpii9lSRsc67S3kKUEAeV/fdDaSNxKpCa78Gcmr+ASt8ZU9yQ==;EndpointSuffix=core.windows.net")

def main(myblob: InputStream):
    logging.info(f"Processing blob: Name: {myblob.name}, Size: {myblob.length} bytes")
    
    try:
        # Extract blob path information
        blob_path = myblob.name  # Full blob path
        parts = blob_path.split('/')  # Split by "/"

        # Base folder and date/dataset folder extraction
        base_folder = parts[0]  # This is the container name
        date_str = parts[1]     # e.g., "2024-09-29"
        dataset_folder = parts[2]  # e.g., "Dataset-1727630960"
        zip_file_name = parts[4]  # e.g., "HS173FY1005406-1727630962.zip"

        # Create a ZipFile object to handle the zip file in memory
        with zipfile.ZipFile(io.BytesIO(myblob.read()), 'r') as zip_ref:
            for file_name in zip_ref.namelist():
                if file_name.endswith('.csv'):
                    # Create a new blob client for the CSV file
                    csv_blob_name = zip_file_name.replace('.zip', '.csv')

                    # Stream the CSV file directly to Blob Storage
                    with zip_ref.open(file_name) as extracted_file:
                        # Read the contents of the extracted CSV file
                        csv_content = extracted_file.read()

                        # Directly upload to the final destination
                        final_blob_path = f"{date_str}/{dataset_folder}/{csv_blob_name}"
                        final_blob_client = blob_service_client.get_blob_client(container=base_folder, blob=final_blob_path)
                        final_blob_client.upload_blob(csv_content, overwrite=True)  # Upload directly to final location
                        logging.info(f"Uploaded {csv_blob_name} to Blob Storage at {final_blob_path}")

        logging.info("All CSV files have been processed and uploaded to Blob Storage.")

    except zipfile.BadZipFile as e:
        logging.error(f"BadZipFile Error: {e}")
    except Exception as e:
        logging.error(f"An error occurred: {e}")
