import azure.functions as func
from azure.eventhub import EventHubConsumerClient

def main(event: func.EventHubEvent):
    # Connection string for your Event Hub namespace
    CONNECTION_STR = "Endpoint=sb://eventhub-ap-testing.servicebus.windows.net/;SharedAccessKeyName=iothubroutes_IOT-AP-Testing;SharedAccessKey=nJ6XA6wr61JpMJzB6hNyg6wwpHaMZcxj6+AEhAFx2rA=;EntityPath=event-hub-ap"
    # Event Hub name
    EVENTHUB_NAME = "event-hub-ap"
    # Consumer group name
    CONSUMER_GROUP = "$Default"

    # Define your event processing logic
    def on_event(partition_context, event):
        # Process received event
        print("Received event from partition: {}".format(partition_context.partition_id))
        print("Data: {}".format(event.body_as_str()))

    # Initialize the Event Hub consumer client
    client = EventHubConsumerClient.from_connection_string(
        conn_str=CONNECTION_STR,
        consumer_group=CONSUMER_GROUP,
        eventhub_name=EVENTHUB_NAME
    )

    # Start receiving events from all partitions
    with client:
        client.receive(on_event=on_event, starting_position="-1")




@app.event_hub_message_trigger(arg_name="azeventhub", event_hub_name="event-hub-ap",
                               connection="EventHubAPTesting_eventhubsend_EVENTHUB") 
def fn_sample_func(azeventhub: func.EventHubEvent):
    logging.info('Python EventHub trigger processed an event: %s',
                azeventhub.get_body().decode('utf-8'))



@app.event_hub_message_trigger(arg_name="azeventhub", event_hub_name="event-hub-ap",
                               connection="EventHubAPTesting_eventhubsend_EVENTHUB") 
def fn_sample(azeventhub: func.EventHubEvent):
    logging.info('Python EventHub trigger processed an event: %s',
                azeventhub.get_body().decode('utf-8'))



@app.event_hub_message_trigger(arg_name="azeventhub", event_hub_name="event-hub-ap",
                               connection="EventHubAPTesting_eventhubsend_EVENTHUB") 
def fn_sample(azeventhub: func.EventHubEvent):
    logging.info('Python EventHub trigger processed an event: %s',
                azeventhub.get_body().decode('utf-8'))
