import logging
import json
import azure.functions as func

app = func.FunctionApp()

@app.event_hub_message_trigger(arg_name="azeventhub", event_hub_name="testeventhub102",
                               connection="eventhubtest101_sendandlisten_EVENTHUB") 
def eventhub_trigger(azeventhub: func.EventHubEvent):
    logging.info('Python EventHub trigger processed an event: %s',
                azeventhub.get_body().decode('utf-8'))
    p=azeventhub.get_body().decode('utf-8')
    print(p)
    return func.HttpResponse(body=p, status_code=200)