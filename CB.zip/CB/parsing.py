from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, List, Optional

app = FastAPI()

# In-memory database
db: Dict[int, Dict[str, str]] = {}


class Item(BaseModel):
    name: str
    description: Optional[str] = None


# Create operation
@app.post("/items/", response_model=Item)
def create_item(item: Item):
    new_item_id = len(db) + 1
    db[new_item_id] = item.dict()
    return item


# Read operation
@app.get("/items/{item_id}", response_model=Item)
def read_item(item_id: int):
    if item_id not in db:
        raise HTTPException(status_code=404, detail="Item not found")
    return db[item_id]


# Update operation
@app.put("/items/{item_id}", response_model=Item)
def update_item(item_id: int, item: Item):
    if item_id not in db:
        raise HTTPException(status_code=404, detail="Item not found")
    db[item_id] = item.dict()
    return item


# Delete operation
@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    if item_id not in db:
        raise HTTPException(status_code=404, detail="Item not found")
    del db[item_id]
    return {"message": "Item deleted successfully"}
