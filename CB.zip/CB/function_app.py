import datetime
import logging
import azure.functions as func
from azure.servicebus import ServiceBusClient, ServiceBusMessage

# Define your Service Bus connection string and queue name
SERVICE_BUS_CONNECTION_STR = "Endpoint=sb://ym-adnoc-timeseries-demo.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=2/cKRySwG3YzTS/Dkr0E1TihJ80X1Sjr6+ASbFY9VRQ="
QUEUE_NAME = "adnoctimeseriesqueuedemo"

app = func.FunctionApp()

@app.function_name(name="mytimer")
@app.schedule(schedule="0 */1 * * * *", arg_name="mytimer", run_on_startup=True,
              use_monitor=False) 
def test_function(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    # Create a Service Bus client
    servicebus_client = ServiceBusClient.from_connection_string(conn_str=SERVICE_BUS_CONNECTION_STR, logging_enable=True)

    # Create a sender for the queue
    with servicebus_client:
        sender = servicebus_client.get_queue_sender(queue_name=QUEUE_NAME)
        with sender:
            # Create a message to send to the queue
            message = ServiceBusMessage(f'Function ran at {utc_timestamp}')
            # Send the message
            sender.send_messages(message)
            logging.info('Message sent to Service Bus queue')

# This is necessary for local execution
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test_function(func.TimerRequest(past_due=False))
