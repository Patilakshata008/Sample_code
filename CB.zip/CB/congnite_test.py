import datetime
import logging
import azure.functions as func
from cognite.client import CogniteClient
from cognite.client.credentials import OAuthClientCredentials

# Configuration details
BASE_URL = "https://api.cognitedata.com"
TENANT_ID = "48d5043c-cf70-4c49-881c-c638f5796997"
CLIENT_ID = "1b90ede3-271e-401b-81a0-a4d52bea3273"
CLIENT_SECRET = "J_R8Q~ld5qF026iaGCbGi~R7FxQwFOje.rEnIa~r"
SCOPES = [f"{BASE_URL}/.default"]

# Create the OAuth2 credentials object
oauth_credentials = OAuthClientCredentials(
    token_url=f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token",
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    scopes=SCOPES
)

# Initialize the Cognite client
cognite_client = CogniteClient(
    client_name="my-azure-function",
    base_url=BASE_URL,
    credentials=oauth_credentials
)

app = func.FunctionApp()

@app.function_name(name="mycognite")
@app.timer_trigger(schedule="0 */1 * * * *", 
                   arg_name="mytimer",
                   run_on_startup=True) 
def mycognite(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    
    if mytimer.past_due:
        logging.info('The timer is past due!')
    
    logging.info('Python timer trigger function ran at %s', utc_timestamp)
    
    # Example usage of the Cognite client
    try:
        # Fetch some data from Cognite Data Fusion (e.g., list assets)
        assets = cognite_client.assets.list(limit=5)
        logging.info('Fetched %d assets from Cognite Data Fusion', len(assets))
    except Exception as e:
        logging.error('Error fetching data from Cognite: %s', e)
