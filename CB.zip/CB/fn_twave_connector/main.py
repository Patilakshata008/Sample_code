import os
import json
import requests
import numpy as np
from struct import unpack
from base64 import b64decode
from zlib import decompress
import csv
import io
from azure.storage.blob import BlobServiceClient
from datetime import datetime, timezone
import logging
import azure.functions as func

# Constants from environment variables
DEVICE_IP = os.getenv('DEVICE_IP')
MACHINE = os.getenv('MACHINE')
USER = os.getenv('USER')
PASS = os.getenv('PASS')
FORMAT = os.getenv('FORMAT')
MACHINE_ID = os.getenv('MACHINE_ID')
PMODE = 'waveform_12800Hz'
connection_string = os.getenv('BLOB_CONNECTION_STRING')
container_name = os.getenv('CONTAINER_NAME')

# Points mapping
points = {
    'M1V': 'X',
    'M1Y': 'Y',
    'M1Z': 'Z'
}

# Decoding functions for each format
def zint_to_float(raw):
    d = decompress(b64decode(raw.encode()))
    return np.array([unpack('h', d[i * 2:(i + 1) * 2])[0] for i in range(int(len(d) / 2))], dtype='f')

def zlib_to_float(raw):
    d = decompress(b64decode(raw.encode()))
    return np.array([unpack('f', d[i * 4:(i + 1) * 4])[0] for i in range(int(len(d) / 4))], dtype='f')

def b64_to_float(raw):
    return np.frombuffer(b64decode(raw.encode()), dtype='f')

decode_format = {
    'zint': zint_to_float,
    'zlib': zlib_to_float,
    'b64': b64_to_float
}

def calculate_rms(data):
    return np.sqrt(np.mean(np.square(data))) if data.size > 0 else 0

def upload_to_blob(csv_data, filename):
    date_str = datetime.now().strftime('%Y-%m-%d')
    timestamp = int(datetime.now().timestamp())
    subfolder = f"{date_str}/Dataset-{timestamp}"
    
    # Create a BlobServiceClient using the connection string
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    
    # Blob client pointing to the location in Azure Blob Storage
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=f"{subfolder}/{filename}")

    # Upload the CSV data directly without saving it locally
    blob_client.upload_blob(csv_data, overwrite=True)

def collect_and_upload_waveform_data():
    logging.info("Starting data collection...")

    wave_data = {}
    time_axis, speed, t = None, None, None

    for POINT, alias in points.items():
        url = f'https://{DEVICE_IP}/rest/waves/{MACHINE}/{POINT}/{PMODE}/0?array_fmt={FORMAT}'

        try:
            r = requests.get(url, auth=(USER, PASS))
            r.raise_for_status()

            if not r.text.strip():
                logging.error(f"Empty response for point {POINT}.")
                continue

            ret = r.json()
            srate = float(ret['sample_rate'])
            factor = float(ret.get('factor', 1))
            raw = ret['data']
            speed = float(ret.get('speed', speed))
            t = float(ret.get('t', t))

            wave = decode_format[FORMAT](raw) * factor
            wave_data[alias] = wave

            if time_axis is None:
                time_axis = np.linspace(0, len(wave) / srate, len(wave))

        except requests.exceptions.RequestException as e:
            logging.error(f"Error fetching data for {POINT}: {e}")
            continue

    if not wave_data:
        logging.warning("No waveform data collected.")
        return

    rms_x = calculate_rms(wave_data.get('X', np.array([])))
    rms_y = calculate_rms(wave_data.get('Y', np.array([])))
    rms_z = calculate_rms(wave_data.get('Z', np.array([])))

    logging.info(f"RMS Values - X: {rms_x}, Y: {rms_y}, Z: {rms_z}")

    if rms_x >= 0 or rms_y >= 0 or rms_z >= 0:
        current_epoch_time = int(datetime.now().timestamp())
        
        # Create CSV content in memory
        csv_buffer = io.StringIO()
        csvwriter = csv.writer(csv_buffer)
        csvwriter.writerow(['x', 'y', 'z', 'sampling_time', 'speed', 'timestamp'])

        for i in range(len(time_axis)):
            row = [time_axis[i]]
            row += [wave_data.get(alias, [None])[i] for alias in ['X', 'Y', 'Z']]
            row.extend([speed, t])
            csvwriter.writerow(row)

        # Create the CSV filename
        csv_filename = f"{MACHINE_ID}-{current_epoch_time}.csv"
        
        # Upload the CSV data to Azure Blob Storage
        upload_to_blob(csv_buffer.getvalue(), csv_filename)

# Azure Functions main entry (time-triggered function)
def main(mytimer: func.TimerRequest) -> None:
    # Log the current time in UTC and check if the timer is past due
    utc_timestamp = datetime.utcnow().replace(tzinfo=timezone.utc).isoformat()
    
    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)
    
    # Run data collection and upload function
    collect_and_upload_waveform_data()
    logging.info("Function ran successfully.")
